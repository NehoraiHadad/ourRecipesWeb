"""Training-only assertion contrasts and historical recipe-disjoint calibration."""
from pathlib import Path
import random

from broad_text_data_v28 import DATA as V28
from fresh_pairs_data_v15 import canonical
from fresh_pairs_v15 import read, write
from report_prompt_data_v29 import DATA as V29
from report_scope_v21 import known
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'runs/report-verifier-data-v30-20261119.json'
RECIPES = (
    ('לחם חלב ואגוזי מקדמיה', ('ללוש את הבצק', 'לקצוץ אגוזי מקדמיה', 'למרוח חלב', 'לאפות את הכיכר'),
     ('לשתי את הבצק', 'אלוש את הבצק'), 'קצצתי את אגוזי המקדמיה', 'מרחתי חלב', 'אפיתי את הכיכר'),
    ('קרם סויה עם קליפת לימון', ('למדוד משקה סויה', 'לגרר קליפת לימון', 'להקציף את התערובת', 'לצקת את הקרם'),
     ('מדדתי את משקה הסויה', 'אמדוד את משקה הסויה'), 'גיררתי את קליפת הלימון',
     'הקצפתי את התערובת', 'יצקתי את הקרם'),
    ('לביבות ארטישוק ירושלמי', ('לקלף ארטישוק ירושלמי', 'לשקול קמח חומוס', 'לתבל בשמיר', 'לטגן את הלביבות'),
     ('קילפתי את הארטישוק', 'אקלף את הארטישוק'), 'שקלתי קמח חומוס', 'תיבלתי בשמיר', 'טיגנתי את הלביבות'),
    ('טרין כרוב וערמונים', ('לחלוט עלי כרוב', 'לקצוץ ערמונים', 'לסדר את השכבות', 'לקרר את הטרין'),
     ('חלטתי את עלי הכרוב', 'אחלוט את עלי הכרוב'), 'קצצתי את הערמונים', 'סידרתי את השכבות', 'קיררתי את הטרין'),
    ('סלט פול וקלמנטינה', ('לקלף את הקלמנטינה', 'לבשל גרגרי פול', 'לחתוך סלרי', 'לערבב את התיבול'),
     ('קילפתי את הקלמנטינה', 'אקלף את הקלמנטינה'), 'בישלתי את גרגרי הפול', 'חתכתי סלרי', 'ערבבתי את התיבול'),
    ('קינוח לימון ובננה', ('לסחוט לימון', 'לחתוך בננה', 'להוסיף פתיתי שוקולד', 'לקרר את הקינוח'),
     ('סחטתי לימון', 'אסחט לימון'), 'חתכתי בננה', 'הוספתי פתיתי שוקולד', 'קיררתי את הקינוח'),
)


def added_assertions():
    rng = random.Random(301119)
    rows = []
    for i, (name, actions, (past, future), take, contrast, finish) in enumerate(RECIPES):
        (a, b, c, d), ctx = fixture(rng, name, actions, i, 'verifier-train-v30')
        plans = (
            f'אני באמצע השיחה, {future} רק אחר כך. מה הצעד הנוכחי?',
            f'כשיגיע הרגע אני {future}. מה אעשה בינתיים?',
            f'אני אומרת מראש ש{future} בהזדמנות הבאה. לאן מתקדמים כרגע?',
        )
        pair(rows, ctx, 'plan_0', (plans[i % 3], f'רק מעדכן ש{past} כמו שכתוב. מה הצעד הנוכחי?'),
             (response('next'), response('next', [(a, 'done')])))
        quotations = (
            f'קראתי בקול ״{take}״ מתוך ההדגמה, זה כל מה שעשיתי.',
            f'מישהו אחר אמר לי ״{take}״, אני רק חוזרת על המילים שלו.',
            f'״{take}״ זו לא הודעה עליי. זה המשפט שהם נתנו בתור דוגמה.',
        )
        pair(rows, ctx, 'quote_0', (quotations[i % 3], f'עליי אפשר באמת להגיד ש{take}.'),
             (response('other'), response('report', [(b, 'done')])))
        scenario = (
            f'נגיד לרגע ש{contrast}. מה הייתי עושה בהמשך?',
            f'בעולם דמיוני שבו כבר {contrast}, מה היה בא עכשיו?',
            f'אילו הייתי מדווחת ש{contrast}, מה היה הצעד שאחרי?',
        )
        pair(rows, ctx, 'scenario_0', (scenario[i % 3], f'זה באמת קרה: {contrast}. ומה עושים עכשיו?'),
             (response('explain'), response('next', [(c, 'done')])))
        pair(rows, ctx, 'doubt_0', (f'יש מצב ש{finish}, אבל אין לי ביטחון בזיכרון הזה.',
                                   f'יש לי ודאות, {finish} רק באופן חלקי.'),
             (response('clarify', clarify=[d]), response('report', [(d, 'partial')])))
        pair(rows, ctx, 'contrast_0', (f'עוד לא {past}.', f'אני שוקל מתי {future} בעתיד.'),
             (response('report', [(a, 'pending')]), response('other')))
        pair(rows, ctx, 'mixed_0', (f'אצטט ״{take}״ כדי שתדע על איזו פעולה מדובר. מה הלאה?',
                                   f'רק ציטטתי ״{take}״, אך דבר אחד באמת עשיתי: {contrast}.'),
             (response('next'), response('report', [(c, 'done')])))
    audit_new(rows, 72)
    return rows


def build():
    training = list(read_native()['train']) + train_new() + added_assertions()
    calibration = next(rows for name, rows, _, _ in known() if name == 'regression')
    evaluation = read(V28) + read(V29)
    partitions = [training, calibration, evaluation]
    names = [{r['input']['recipe']['name'] for r in part} for part in partitions]
    texts = [{canonical(r['input']['utterance']) for r in part} for part in partitions]
    for a, b in ((0, 1), (0, 2), (1, 2)):
        if names[a] & names[b] or texts[a] & texts[b]:
            raise ValueError('Verifier splits overlap in recipes or utterances')
    assert len(training) == 528 and len(calibration) == 120
    return {'training': training, 'calibration': calibration}


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
