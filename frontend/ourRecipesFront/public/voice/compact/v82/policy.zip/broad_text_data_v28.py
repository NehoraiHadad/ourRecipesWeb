"""Manual synthetic utterance pairs for a wider Hebrew cooking text evaluation."""
from pathlib import Path
import random

from explicit_nonstart_data_v24 import DATA as V24
from fresh_pairs_data_v15 import DATA as V15, canonical
from fresh_pairs_v15 import read, write
from grounded_followup_data_v26 import DATA as V26
from grounded_progress_data_v25 import DATA as V25
from grounded_recipe_source_data_v27 import DATA as V27
from grounded_scope_data_v18 import DATA as V18
from preserve_reports_data_v20 import DATA as V20
from report_scope_data_v21 import DATA as V21
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/broad-text-data-v28-20261119.json'
FAMILIES = ('status', 'mixed', 'correction', 'reference', 'nonreport', 'navigation', 'lookup', 'noise')


def case(utterance, intent, *facts, clarify=()):
    return utterance, intent, facts, clarify


RECIPES = (
    ('ריזוטו אורז עגול ופטריות', ('לטגן את הבצל שלוש דקות.', 'להוסיף כוס אורז עגול.',
                                 'למזוג שתי כוסות ציר פטריות.', 'לערבב את הריזוטו.'),
     'עכשיו אנחנו מדברים על הוספת האורז העגול.',
     (case('עשיתי לבצל טיגון ממש קצר, עוד לא גמרתי איתו.', 'report', (0, 'partial')),
      case('הבצל גמור לגמרי מבחינת הטיגון.', 'report', (0, 'done'))),
     (case('אורז עוד לא הכנסתי, ציר פטריות כבר מזגתי. מה הלאה מפה?', 'next', (1, 'pending'), (2, 'done')),
      case('נראה לי שהכנסתי את האורז, אבל את הציר אני בטוח שמזגתי.', 'report', (2, 'done'), clarify=(1,))),
     (case('רגע, טעיתי לגבי הציר. עדיין לא מזגתי אותו.', 'report', (2, 'pending')),
      case('רגע, טעיתי לגבי הציר. מזגתי רק חצי ממנו.', 'report', (2, 'partial'))),
     (case('זה כבר בפנים, אפשר לסמן שביצעתי.', 'report', (1, 'done')),
      case('בזה עוד לא התחלתי בכלל.', 'report', (1, 'pending'))),
     (case('תכף אמזוג את ציר הפטריות. מה עוד צריך לעשות עכשיו?', 'next'),
      case('אם הייתי כבר מוזגת את הציר, מה היה צריך לעשות אחרי זה?', 'explain')),
     (case('איך להתקדם מפה עם הריזוטו?', 'next'),
      case('איזו משימה מהשלבים הקודמים עוד פתוחה אצלי?', 'missed')),
     (case('אני לא זוכר כמה ציר פטריות כתוב במתכון.', 'quantity'),
      case('איך כתוב לטגן את הבצל?', 'explain')),
     (case('הוספתי תאורז כברר', 'report', (1, 'done')),
      case('עוד לא הוספתי תאורז בכללל', 'report', (1, 'pending')))),
    ('סלט מלפפון ריחן ושומשום', ('לשטוף את המלפפונים.', 'לחתוך את המלפפונים.',
                                 'לקלות כף שומשום.', 'לערבב את הרוטב.'),
     'שטיפה וחיתוך של המלפפונים הן שתי פעולות שונות. על איזו מהן רצית לספר?',
     (case('נתתי לשומשום טיפה קלייה, לא סיימתי עד הסוף.', 'report', (2, 'partial')),
      case('השומשום לא ראה מחבת, עדיין לא קליתי בכלל.', 'report', (2, 'pending'))),
     (case('מלפפונים שטופים וחתוכים, את הרוטב עוד לא ערבבתי.', 'report',
           (0, 'done'), (1, 'done'), (3, 'pending')),
      case('שטפתי את המלפפונים, לא סגורה אם חתכתי אותם.', 'report', (0, 'done'), clarify=(1,))),
     (case('קודם אמרתי ששטפתי את המלפפונים. בדקתי ואני מתקנת: לא שטפתי אותם.', 'report', (0, 'pending')),
      case('קודם אמרתי שלא שטפתי אותם. בדקתי, המלפפונים כן שטופים.', 'report', (0, 'done'))),
     (case('הפעולה שעליה שאלת כבר מאחוריי.', 'clarify', clarify=(None,)),
      case('את החיתוך שלהם כבר סיימתי.', 'report', (1, 'done'))),
     (case('״קליתי שומשום״ זה מה שהמתכון נותן כדוגמה. איפה ממשיכים עכשיו?', 'next'),
      case('אני מתכוונת לערבב רוטב כשאסיים לדבר.', 'other')),
     (case('יאללה איך ממשיכים עם הסלט מכאן?', 'next'),
      case('יש משהו מלפני השלב הזה שלא עשיתי עדיין?', 'missed')),
     (case('להשתמש בכף שומשום או בכפית? מה כתוב?', 'quantity'),
      case('איך השלב של קליית השומשום אמור להתבצע לפי ההוראות?', 'explain')),
     (case('שומשום קליתי רק חצי מימנו', 'report', (2, 'partial')),
      case('שומשום קליתי כולו מוכן', 'report', (2, 'done')))),
    ('מרק כרישה וגריסי שיפון', ('לשטוף גריסי שיפון.', 'לקצוץ את הכרישה.',
                              'לבשל את המרק עשרים דקות.', 'להוסיף שלוש כפות שמנת חמוצה.'),
     'הגענו למשימה לקצוץ את הכרישה.',
     (case('מבחינת בישול המרק כרגע באמצע, בערך עשר דקות בפנים.', 'report', (2, 'partial')),
      case('המרק התבשל את כל העשרים דקות.', 'report', (2, 'done'))),
     (case('שטפתי גריסים קצצתי כרישה חצי ממנה, איך ממשיכים?', 'next', (0, 'done'), (1, 'partial')),
      case('לא זוכרת אם שטפתי את הגריסים, כרישה בוודאות קצצתי.', 'report', (1, 'done'), clarify=(0,))),
     (case('אופס, התבלבלתי. את השמנת החמוצה טרם שמתי במרק.', 'report', (3, 'pending')),
      case('אופס, התבלבלתי. השמנת החמוצה כבר נכנסה והוספתי את כולה.', 'report', (3, 'done'))),
     (case('את הדבר שאמרת עשיתי רק בחלקו.', 'report', (1, 'partial')),
      case('זה שהזכרת, גמרתי איתו.', 'report', (1, 'done'))),
     (case('אם המרק היה מתבשל כבר עשרים דקות, הייתי מוסיפה שמנת?', 'explain'),
      case('בישלתי עשרים דקות זו רק דוגמה שנתתי. מה עכשיו?', 'next')),
     (case('טוב אז מה הצעד שאנחנו צריכים לעשות כרגע?', 'next'),
      case('תבדוק אם נשאר משהו פתוח מאחורי השלב הנוכחי.', 'missed')),
     (case('כמה זמן לפי המתכון המרק אמור להתבשל?', 'quantity'),
      case('איך בדיוק מכינים את הכרישה בשלב שלה?', 'explain')),
     (case('קצצתיי תכרישה כבר', 'report', (1, 'done')),
      case('כרישה עוד לא קצצתי אפלו קצת', 'report', (1, 'pending')))),
    ('מאפינס גזר ופקאן', ('לגרר שני גזרים.', 'לקצוץ אגוזי פקאן.',
                         'להוסיף חצי כוס שמן קנולה.', 'לאפות את המאפינס במשך 18 דקות.'),
     'הפעולה שדיברנו עליה היא להוסיף את שמן הקנולה.',
     (case('גיררתי גזר אחד מתוך השניים.', 'report', (0, 'partial')),
      case('סיימתי לגרר את שני הגזרים.', 'report', (0, 'done'))),
     (case('גזר מגורר, פקאן עוד לא קצוץ, איזה שלב עכשיו?', 'next', (0, 'done'), (1, 'pending')),
      case('קצצתי רק קצת מהפקאן והשמן כבר בפנים.', 'report', (1, 'partial'), (2, 'done'))),
     (case('סליחה אמרתי אפוי אבל התכוונתי שרק התחילה האפייה.', 'report', (3, 'partial')),
      case('אני חוזרת בי, המאפינס עוד בכלל לא נכנסו לאפייה.', 'report', (3, 'pending'))),
     (case('את זה כבר שמתי פנימה.', 'report', (2, 'done')),
      case('אני כבר לא זוכר אם באמת שמתי את זה.', 'clarify', clarify=(2,))),
     (case('נגיד שכבר גיררתי, מה הייתי עושה אחרי הגירור?', 'explain'),
      case('אני אסיים את הגירור אחר כך. מה השלב כרגע?', 'next')),
     (case('תגיד לי מה אני עושה לאחר מכן.', 'next'),
      case('תגיד לי מה שכחתי לעשות לפני השלב שאני בו.', 'missed')),
     (case('מה הכמות הרשומה של שמן קנולה?', 'quantity'),
      case('תסביר לי איך אמורים לקצוץ את הפקאן לפי המתכון.', 'explain')),
     (case('אפיתי תמאפינס הכווול', 'report', (3, 'done')),
      case('רק התחלתיי לאפות תמאפינס', 'report', (3, 'partial')))),
    ('דג בקארי ובזיליקום', ('לשטוף את הבזיליקום.', 'לחתוך פילה דג.',
                           'להוסיף שתי כפיות אבקת קארי.', 'לבשל את הדג שמונה דקות.'),
     'שאלתי על הפעולה לשטוף את הבזיליקום, לפני שעוברים לדג.',
     (case('עוד לא חתכתי אף חתיכה מהפילה.', 'report', (1, 'pending')),
      case('הפילה חצוי ואני עוד עובד על החיתוך.', 'report', (1, 'partial'))),
     (case('שטפתי בזיליקום אבל קארי בכלל לא הוספתי. מה ממשיכים לעשות?', 'next', (0, 'done'), (2, 'pending')),
      case('קארי הוספתי בוודאות, לגבי שטיפה של הבזיליקום יש לי ספק.', 'report', (2, 'done'), clarify=(0,))),
     (case('עצרו רגע, בעצם הדג עוד לא התבשל בכלל.', 'report', (3, 'pending')),
      case('עדכון למה שאמרתי, כבר בישלתי את הדג עד הסוף.', 'report', (3, 'done'))),
     (case('כן, עשיתי את הפעולה ההיא עד הסוף.', 'report', (0, 'done')),
      case('לא, את מה ששאלת לא התחלתי.', 'report', (0, 'pending'))),
     (case('בעוד כמה דקות אוסיף קארי. מה כדאי לעשות בינתיים?', 'next'),
      case('סתם שאלה תיאורטית: אם הייתי מבשלת את הדג כבר, מה היה הצעד הבא?', 'explain')),
     (case('אפשר להזכיר מה עושים תכף?', 'next'),
      case('אפשר להזכיר מה נשאר פתוח מאחור?', 'missed')),
     (case('כמה כפיות של קארי רשומות?', 'quantity'),
      case('מה ההוראה לגבי חיתוך הפילה?', 'explain')),
     (case('בזילקום שטוףף כבר', 'report', (0, 'done')),
      case('בזילקום עוד לא שטפתי בכלל', 'report', (0, 'pending')))),
    ('תבשיל חומוס במנגולד', ('להשרות את גרגירי החומוס.', 'לקצוץ את עלי המנגולד.',
                            'להוסיף כף מחית פלפלים.', 'לכסות את הסיר.'),
     'עוד לא בחרנו אם לדבר על השריית החומוס או על הכיסוי של הסיר.',
     (case('גרגירי החומוס כבר שכבו במים וההשריה הסתיימה.', 'report', (0, 'done')),
      case('גרגירי החומוס עוד יבשים, לא השריתי אותם בכלל.', 'report', (0, 'pending'))),
     (case('חומוס השריתי. מנגולד רק חצי קצצתי והמחית לא בפנים.', 'report',
           (0, 'done'), (1, 'partial'), (2, 'pending')),
      case('את המחית הוספתי וסגרתי את הסיר במכסה. לאן ממשיכים?', 'next', (2, 'done'), (3, 'done'))),
     (case('חוזר בי מכיסוי הסיר, המכסה נשאר בצד ועוד לא כיסיתי.', 'report', (3, 'pending')),
      case('חוזר בי מהדיווח שהסיר פתוח. כיסיתי אותו כבר.', 'report', (3, 'done'))),
     (case('הדבר שדיברנו עליו בוצע מבחינתי.', 'clarify', clarify=(None,)),
      case('התכוונתי לכיסוי של הסיר והוא כוסה.', 'report', (3, 'done'))),
     (case('את החומוס אשים להשריה רק בערב.', 'other'),
      case('תאר לך שהסיר מכוסה. מה הייתי עושה משם?', 'explain')),
     (case('מה אני צריך לעשות מכאן לפי הסדר?', 'next'),
      case('מה פספסתי עד הנקודה הזו?', 'missed')),
     (case('תזכיר כמה מחית פלפלים לשים במתכון.', 'quantity'),
      case('מה הכוונה בהוראה להשרות את החומוס כאן?', 'explain')),
     (case('מנגול קצצתי חצי ממנו לא גמרתי', 'report', (1, 'partial')),
      case('מנגול לא קצצתי עדיין שנייה', 'report', (1, 'pending')))),
)


def build():
    rows = []
    rng = random.Random(281119)
    for i, (name, actions, antecedent, *pairs) in enumerate(RECIPES):
        ids, fixture_input = fixture(rng, name, actions, i, 'fresh-v28')
        fixture_input['progress'] = dict(zip(ids, ('pending', 'partial', 'done', 'pending'), strict=True))
        fixture_input['currentStep'] = 2
        for family, variants in zip(FAMILIES, pairs, strict=True):
            utterances, expected = [], []
            for text, intent, facts, clarify in variants:
                utterances.append(text)
                expected.append(response(intent, [(ids[idx], status) for idx, status in facts],
                                         [None if idx is None else ids[idx] for idx in clarify]))
            history = [{'role': 'assistant', 'content': antecedent}] if family == 'reference' else []
            pair(rows, fixture_input, f'{family}_0', utterances, expected, (history, history))

    audit_new(rows, 96)
    prior = [r for split in read_native().values() for r in split] + train_new()
    for path in (V15, V16, V18, V20, V21, V24, V25, V26, V27):
        prior.extend(read(path))
    recipes = {r['input']['recipe']['name'] for r in prior}
    utterances = {canonical(r['input']['utterance']) for r in prior}
    new_texts = [canonical(r['input']['utterance']) for r in rows]
    if len(set(new_texts)) != len(rows) or set(new_texts) & utterances or any(
            r['input']['recipe']['name'] in recipes for r in rows):
        raise ValueError('V28 duplicates a known utterance or recipe')
    return rows


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
