"""Resolve observed cooking outcomes by predicate, subject and the recipe's available actions."""
import json
import re
from functools import lru_cache
from pathlib import Path

from colloquial_evidence_v60 import decision
from cooking_outcome_v77 import COOK, END_CONDITION, features
from coordinated_claims_v62 import action_slots
from outcome_clauses_v78 import mentions, process as previous
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

SOFT = ('לבשל', 'לאפות', 'לאדות', 'לצלות', 'לטגן', 'לרכך')
# Match an actual result, retaining the predicate span for subject resolution.
PRED = re.compile(
    r'(?P<bake>(?:לא|בקושי) (?:מספיק )?(?:נאפ[התוי]+|אפוי[היםות]*))|'
    r'(?P<rise>לא (?:תפח[הו]?|תופח[תיםות]*))|'
    r'(?P<melt>לא (?:נמס[וה]?|הומס[וה]?))|'
    r'(?P<cook>(?:לא|בקושי) (?:מספיק )?(?:התבשל[הו]?|מבושל[תיםות]*))|'
    r'(?P<soft>(?:לא|בקושי) התרכ[ךכ][הו]?|(?:מסרב[תיות]*|סי?רב[וה]?) להתרכך)|'
    r'(?P<texture>(?:נשאר[הו]?|נותר[הו]?|עדיין|עדין|עוד|יצא[הו]?) '
    r'(?:(?:לי|קצת|די|מאוד|ממש|היו|היה|היתה|עדיין|נותר|כמו) )*'
    r'(?:קש(?:ה|ים|ות)|חי(?:ה|ים|ות)?|נא(?:ה|ים|ות)?|בצקי(?:ת|ים|ות)?)(?![א-ת]))')
VERBS = {'bake':('לאפות',), 'rise':('להתפיח',), 'melt':('להמיס',),
         'soft':SOFT, 'cook':COOK, 'texture':SOFT + ('להמיס','להתפיח','לחמם')}
PARTS = re.compile(r'\s*(?:[,;…]|(?<!\d)\.(?!\d)|!|\s+אבל\s+|\s+אולם\s+)\s*')
ASK = re.compile(r'(?:\s|^)(?:מה (?:ניתן|אפשר|עשיתי|הסיבה|עושים)|למה+[ה]*|איפה טעיתי|מה יכולה להיות הסיבה|'
                 r'יש (?:משהו|דרך|מה) לעשות|מישהו יודע|איך מתקנים|האם (?:יש|צריך))\b')
HYPOTHESIS = re.compile(r'\b(?:ו?אם|אילו|נניח|כאילו|לו|אמור[היםות]*|תמיד|בעתיד|מחר|כשאבשל|'
                        r'חשבתי|נגיד|אומרים|אמרה|אמרו|נאמר|לדבריו|למשל|אולי)\b|'
                        r'לא אמרתי|פעם שעברה|בפעם הקודמת|בשבוע שעבר|שבוע שעבר|במתכון הקודם|'
                        r'עוד לא התחלתי|עדיין לא (?:הכנסתי|התחלתי)|לפני (?:האפייה|הבישול|שהכנסתי)|'
                        r'לא (?:ניסיתי|הכנסתי|הפעלתי|הדלקתי|בישלתי|אפיתי)|הייתי (?:מבשל|אופה)|צריך (?:לבשל|לאפות)')
ATTEMPT = re.compile(r'ב[יי]?שלתי|אפיתי|הכנתי|עשיתי|הכנסתי|ניסיתי|חיממתי|אידיתי|התפחתי|שמתי|'
                     r'בסיר|בתנור|על האש|בישול|אפייה|אפיה|חימום|'
                     r'דקות|שעות|שעתיים|שעה|שניות|יצא[הו]?|נשאר[הו]?|נותר[הו]?|למרות|לגמרי|עד הסוף|'
                     r'השחימ[הו]?|נשרפ[הו]?|הבעיה ש|התוצאה')
GENERIC = re.compile(r'^(?:(?:ו?היי|לי|הם|הן|היא|הוא|זה|באמצע|האמצע|המרכז|במרכז|בפנים|מבפנים|'
                     r'מפנים|מבחוץ|למטה|למעלה|התחתית|החלק|התחתון|הפנימי|שלי|ממש|פשוט|כנראה|'
                     r'והם|והן|אבל|כולם|כולן|דווקא|ובכלל|עדיין|כמעט|גם|לי|הכל|הכול|ובסוף|בסוף)\s*)*$')
SUCCESS = re.compile(r'(?:עכשיו|ועכשיו|בסוף|ואז|בסופו של דבר|כבר|אחרי זה).{0,35}'
                     r'(?:התרכ[ךכ]|הצליח|מוכ[ןנהיםות]+|רך|רכ[היםות]+|נאפה כמו שצריך)|'
                     r'לא (?:נשאר|נותר)[הו]? (?:קשה|נא|חי)|יצא בדיוק כמו שרציתי')
ALIAS = {'תפו"א':'תפוחי אדמה','תפו״א':'תפוחי אדמה','תפוא':'תפוחי אדמה'}
END = re.compile(r' (?:בתנור|במים|על אש [א-ת ]+|בחום .+)$')


@lru_cache(maxsize=1)
def coefficients():
    return json.loads(Path(__file__).with_name('outcome_weights_v79.json').read_text())


def report_segments(text):
    # A standalone confirmation question has no write. A separate question for
    # help after an affirmative observation does not undo the observation.
    results = []
    for sentence in re.findall(r'[^.!?…]+(?:[.!?…]+|$)', text):
        if '?' in sentence:
            why = ASK.search(sentence)
            if not why or not why.start():
                continue
            sentence = sentence[:why.start()]
        results.extend(p.strip(' .!?…') for p in PARTS.split(sentence) if p.strip(' .!?…'))
    return results


def subjects(slots, kind, clause, prefix, earlier):
    allowed = [s for s in slots if s.verb in VERBS[kind]]
    named = [s for s in allowed if mentions(s.obj, prefix)]
    if not named and not prefix.strip():
        # Hebrew permits the subject after the verb.
        named = [s for s in allowed if mentions(s.obj, clause)]
    if not named and GENERIC.fullmatch(prefix.strip()):
        for part in reversed(earlier[-2:]):
            named = [s for s in allowed if mentions(s.obj, part)]
            if named:
                break
        if not named and (kind in ('bake','rise','melt','cook') or earlier and ATTEMPT.search(' '.join(earlier))):
            named = allowed if len(allowed) == 1 else []
    if not named:
        return []
    by_obj = {}
    for slot in named:
        by_obj.setdefault(slot.obj, []).append(slot)
    targets = []
    for group in by_obj.values():
        if len(group) > 1:
            context = ' '.join([*earlier[-2:], clause])
            method = 'לאפות' if 'תנור' in context else 'לבשל' if re.search('בסיר|בישלתי', context) else None
            group = [s for s in group if s.verb == method]
        if len(group) != 1:
            return []
        targets.append(group[0].key)
    return targets


def outcome(req):
    text = req['utterance']
    for short, full in ALIAS.items():
        text = text.replace(short, full)
    if (not PRED.search(text) or SUCCESS.search(text) or MENTION.search(text)
            or PRIOR_CONTEXT.search(text) or re.search('[״"“”]', text)):
        return {}
    # Do not detach the consequence of a proposed or quoted scenario.
    parts = report_segments(text)
    if HYPOTHESIS.search(' '.join(parts)):
        return {}
    slots = action_slots([{**a, 'source':END.sub('', END_CONDITION.sub('', a['source']))}
                          for a in req['recipe']['actions']])
    facts = {}
    for index, part in enumerate(parts):
        prior_end = 0
        for pred in PRED.finditer(part):
            kind = pred.lastgroup
            prefix = part[prior_end:pred.start()].strip()
            prior_end = pred.end()
            if DOUBT.search(prefix) or re.search(r'איך |האם |יכול להיות|רצוי|מומלץ|נראה לי ש', prefix):
                continue
            burnt = re.search(r'נשר(?:ף|פ[הו]) ו(?=[א-ת])', prefix)
            burnt_keys = []
            if burnt:
                burnt_keys = subjects(slots, 'bake', part, prefix[:burnt.start()], parts[:index])
                prefix = prefix[burnt.end():]
            if prefix == 'ו':
                prefix = part[:pred.start()].split(' יצא')[0]
            attempted = bool(ATTEMPT.search(' '.join(parts[max(0,index-2):index+1])))
            if kind == 'texture' and not attempted:
                continue
            if not attempted and re.search(r'(?:עוד|עדיין)\s*$', prefix):
                continue
            # A passive past failure is itself a report. A present-state
            # adjective ("uncooked") requires separate evidence of an attempt.
            if not attempted and re.search('מבושל|אפוי',pred[0]):
                continue
            if kind == 'texture':
                model = coefficients()
                score = max(sum(model.get(k, 0) * v for k, v in features(span).items())
                            for span in (pred[0], part))
                if score < 0.07:
                    continue
            ids = subjects(slots, kind, part, prefix, parts[:index])
            if ids and len(burnt_keys) == 1 and burnt_keys[0] not in ids:
                facts[burnt_keys[0]] = 'done'
            facts.update(dict.fromkeys(ids, 'partial'))
    return facts


def process(payload, raw):
    row = json.loads(payload)
    facts = outcome(row['input'])
    result = previous(payload, raw)
    if not facts:
        return result
    old = json.loads(json.loads(result)['accepted_text'])
    changes = {f['action']:f['status'] for f in old['facts']}
    changes.update(facts)
    encoded = json.dumps(decision(changes.items(), doubts=[k for k in old['clarify'] if k and k not in facts]),
                         ensure_ascii=False)
    return json.dumps({**simulate(row, encoded), 'accepted_text':encoded, 'route':'grounded_result_clause'},
                      ensure_ascii=False)
