"""Authored synthetic minimal contrasts for a prospective diagnostic."""
from collections import Counter
import json
from pathlib import Path
import random
import unicodedata

from semantic_supervision_data_v12 import read_native
from sparse_recipe_v3 import validate

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/fresh-pairs-data-v15-20261118.json'
KINDS = ('uncertainty', 'status', 'clause_scope', 'nonreport', 'history')
# Each fixture includes four actions and five minimal pairs.
# The utterances are written individually to avoid cloning a single wording across recipes.
RECIPES = (
    ('סלט כרוב סגול', ('לפרוס את הכרוב הסגול לרצועות', 'לגרר את הגזר', 'לסחוט את הלימון', 'לתבל את הסלט במלח'),
     ('את הכרוב הסגול כבר פרסתי לרצועות, זה סגור.', 'אין לי מושג אם בסוף פרסתי את הכרוב הסגול לרצועות.'),
     ('גיררתי את כל הגזר.', 'הגזר כבר על הפומפייה, גיררתי בינתיים בערך חצי ממנו.', 'partial'),
     ('פרסתי את הכרוב הסגול ואת הלימון כבר סחטתי.', 'לגבי הכרוב הסגול אני לא זוכר אם פרסתי אותו, ואת הלימון כבר סחטתי.'),
     ('סחטתי את הלימון על הסלט, מה השלב הבא?', 'עוד מעט אסחט את הלימון על הסלט, מה השלב הבא כרגע?'),
     'טוב, עם זה כבר סיימתי.'),
    ('קוסקוס עם ירקות', ('לשטוף את גרגירי החומוס', 'לקלף את הדלעת', 'לחתוך את הקישוא לקוביות', 'לערבב את הקוסקוס במזלג'),
     ('החומוס שטוף, בדקתי עכשיו במסננת.', 'החומוס במסננת, אבל אני לא מצליח להיזכר אם באמת שטפתי אותו.'),
     ('קילפתי את הדלעת כולה, אפשר לסמן שסיימתי.', 'אפשר לסמן שאת הדלעת עוד לא קילפתי.', 'pending'),
     ('את החומוס שטפתי; לחתוך את הקישוא לקוביות כבר סיימתי.', 'אולי שטפתי את החומוס, אין לי דרך לבדוק כרגע; לחתוך את הקישוא לקוביות כבר סיימתי.'),
     ('חתכתי את הקישוא לקוביות. מה עכשיו?', 'מישהו הציע: ״תחתוך את הקישוא לקוביות״. מה עכשיו?'),
     'את ההיא כבר עשיתי.'),
    ('לביבות קישוא', ('לסחוט את הקישואים המגוררים', 'לטרוף את הביצים', 'לערבב את הקמח עם הקישואים', 'לחמם שמן במחבת'),
     ('סחטתי את הקישואים, כבר לא נשאר מהם נוזל.', 'אני לא קולטת אם בכלל סחטתי את הקישואים.'),
     ('טרפתי את כל הביצים עד שהן אחידות.', 'טרפתי כמה ערבובים בביצים ועצרתי באמצע.', 'partial'),
     ('הקישואים נסחטו, וגם ערבבתי איתם את הקמח.', 'לא ברור לי אם הקישואים נסחטו, אבל את הקמח ערבבתי איתם.'),
     ('ערבבתי את הקמח עם הקישואים, מה לעשות אחר כך?', 'כשאתפנה אערבב את הקמח עם הקישואים. מה לעשות עכשיו?'),
     'כן, זה כבר מאחוריי.'),
    ('טוסט פטריות', ('לנגב את הפטריות', 'לפרוס את הלחם', 'למרוח חמאה על הלחם', 'לצלות את הטוסט'),
     ('את הפטריות ניגבתי אחת־אחת.', 'נדמה לי שנגעתי בפטריות אבל אני לא בטוחה שניגבתי אותן.'),
     ('הלחם כבר פרוס, חתכתי את כל הפרוסות.', 'הלחם עדיין שלם. עוד לא פרסתי אותו.', 'pending'),
     ('ניגבתי את הפטריות, ועל הלחם כבר מרחתי חמאה.', 'אני מתלבט אם הפטריות נוגבו, ועל הלחם כבר מרחתי חמאה.'),
     ('מרחתי חמאה על הלחם. מה בא אחר כך?', '״למרוח חמאה על הלחם״ זו רק הוראה שאני קורא בקול. מה בא אחר כך?'),
     'זאת כבר בוצעה אצלי.'),
    ('עוגת תפוחים', ('לקלף את התפוחים', 'לחתוך את התפוחים לפלחים', 'לרפד את התבנית בנייר אפייה', 'למדוד כפית קינמון'),
     ('קילפתי את התפוחים עד האחרון.', 'אני לא יודעת אם קילפתי את התפוחים בסוף או שרק תכננתי.'),
     ('חתכתי את כל התפוחים לפלחים.', 'חתכתי כמה מהתפוחים לפלחים, היתר מחכים לחיתוך.', 'partial'),
     ('את התפוחים קילפתי, וגם ריפדתי את התבנית בנייר אפייה.', 'יכול להיות שקילפתי את התפוחים אבל אני לא בטוח; את התבנית ריפדתי בנייר אפייה בוודאות.'),
     ('ריפדתי את התבנית בנייר אפייה. מה לעשות עכשיו?', 'עוד לא דיברתי על ביצוע, רק אמרתי שאצטרך לרפד את התבנית בנייר אפייה. מה לעשות עכשיו?'),
     'גמרתי כבר את הפעולה הזאת.'),
    ('שעועית ירוקה בשומשום', ('להסיר את קצות השעועית', 'לקלות את השומשום', 'לכתוש את השום', 'להקפיץ את השעועית במחבת'),
     ('הסרתי את הקצוות מכל השעועית.', 'אני לא סגורה אם הסרתי את הקצוות של השעועית.'),
     ('קליתי את השומשום כבר, הורדתי מהאש.', 'עוד לא התחלתי לקלות את השומשום.', 'pending'),
     ('הסרתי את קצות השעועית, והשום כבר כתוש כי כתשתי אותו.', 'אולי הסרתי את קצות השעועית ואולי לא; את השום כתשתי בוודאות.'),
     ('כתשתי את השום. מה השלב הבא מכאן?', 'השורה ״לכתוש את השום״ היא חלק מההוראות, אני רק מקריאה. מה השלב הבא מכאן?'),
     'את זאת סגרתי כבר.'),
)


def answer(intent, reports=(), clarify=()):
    return {'intent': intent, 'facts': [{'action': i, 'status': s} for i, s in reports], 'clarify': list(clarify)}


def build():
    rng = random.Random(1518)
    rows = []
    for n,(name, sources, doubt, change, scoped, nonreport, anaphora) in enumerate(RECIPES):
        a,b,c,_ = identifiers = rng.sample([f'a{i}' for i in range(10)], 4)
        recipe = {'id': f'fresh-v15-recipe-{n+1}', 'version': 'source-1', 'name': name,
                  'actions': [{'id': i, 'source': source, 'step': j}
                              for j,(i,source) in enumerate(zip(identifiers,sources,strict=True))]}
        progress = {i: rng.choice(['done', 'partial', 'pending']) for i in identifiers}
        done_a, done_b, done_c = (a,'done'), (b,'done'), (c,'done')
        fixed_history = [[], [], [], [], [
            [{'role':'assistant','content': f'הפעולה ששאלת עליה היא {sources[1]}.'}],
            [{'role':'assistant','content': f'דיברנו על שתי אפשרויות, {sources[1]} או {sources[3]}. לא סיכמנו איזו.'}],
        ]]
        contrasts = [
            (doubt, (answer('report',[done_a]), answer('clarify',clarify=[a]))),
            (change[:2], (answer('report',[done_b]), answer('report',[(b,change[2])]))),
            (scoped, (answer('report',[done_a,done_c]), answer('report',[done_c],[a]))),
            (nonreport, (answer('next',[done_c]), answer('next'))),
            ((anaphora,anaphora), (answer('report',[done_b]),answer('clarify',clarify=[None]))),
        ]
        for group,(texts,outputs) in enumerate(contrasts):
            kind = KINDS[group]
            pair = f'v15-{n+1}-{kind}'
            for side in (0,1):
                history = fixed_history[group][side] if group == 4 else []
                request = {'recipe':recipe, 'progress':progress, 'currentStep':3, 'history':history, 'utterance':texts[side]}
                target=validate(outputs[side],request)
                rows.append({'id':f'{pair}-{side}', 'pair':pair, 'variant':side, 'family':kind, 'input':request,
                             'expected':target, 'critical_no_facts': not target['facts']})
    return rows


def canonical(text):
    return ' '.join(unicodedata.normalize('NFKC', text).casefold().split())


def audit(rows):
    old = [row for group in read_native().values() for row in group]
    old_names = {r['input']['recipe']['name'] for r in old}
    old_texts = {canonical(r['input']['utterance']) for r in old}
    pairs = {}
    for row in rows:
        request = row['input']
        if request['recipe']['name'] in old_names or canonical(request['utterance']) in old_texts:
            raise ValueError('Fresh benchmark overlaps the exposed native material')
        if validate(row['expected'],request) != row['expected']:
            raise ValueError('Contract check disagrees with the authored label')
        pairs.setdefault(row['pair'],[]).append(row)
    if len(pairs)!=30 or len({r['id'] for r in rows})!=60:
        raise ValueError('Expected 60 records in 30 pairs')
    for group in pairs.values():
        left,right = group
        changed = [k for k in left['input'] if left['input'][k]!=right['input'][k]]
        axis = 'history' if left['family']=='history' else 'utterance'
        if changed != [axis] or left['expected']==right['expected'] or [left['variant'],right['variant']] != [0,1]:
            raise ValueError('Pair must alter only one request field and change its expected response')
    return {'rows':len(rows), 'pairs':len(pairs), 'recipes':len({r['input']['recipe']['name'] for r in rows}),
            'pairs_by_kind':dict(sorted(Counter(group[0]['family'] for group in pairs.values()).items())),
            'expected_no_facts_cases':sum(r['critical_no_facts'] for r in rows),
            'recipe_name_or_exact_normalized_text_overlap_with_v13':0}


if __name__=='__main__':
    rows=build()
    result=audit(rows)
    with DATA.open('x') as f:
        f.write(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
