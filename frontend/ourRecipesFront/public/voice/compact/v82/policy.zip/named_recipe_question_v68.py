"""Answer explicit questions about a recipe instruction from its original wording."""
import json
import re

from colloquial_evidence_v60 import decision
from portion_scope_v67 import process as previous
from recipe_text_responder_v52 import simulate

HOW=re.compile(r'^(?:(?:רגע|שאלה)[, ]+)?(?:איך (?:בדיוק )?(?:מבצעים|לבצע|מכינים|לעשות|עושים)|'
               r'מה (?:בדיוק )?כתוב (?:במתכון|בהוראות) (?:על|לגבי)|'
               r'(?:תזכיר[י]? לי|אפשר להסביר) איך)\s+')
# A new assertion after a lookup still belongs to the normal multi-event policy.
ASSERTION=re.compile(r'\b[וא-ת]*תי\b|\b(?:בוצע|סיימנו|השלמנו)\b')


def process(payload,raw):
    row=json.loads(payload)
    req=row['input']
    text=req['utterance'].strip().rstrip('?').strip()
    target=HOW.match(text)
    if target and not re.search(r'[.!?;]',text):
        question=text[target.end():]
        named=[a for a in req['recipe']['actions'] if a['source'].strip().rstrip('.') in question]
        if named and not ASSERTION.search(question):
            accepted=json.dumps(decision(intent='explain'),ensure_ascii=False)
            return json.dumps({**simulate(row,accepted),'route':'named_recipe_question',
                               'accepted_text':accepted},ensure_ascii=False)
    return previous(payload,raw)
