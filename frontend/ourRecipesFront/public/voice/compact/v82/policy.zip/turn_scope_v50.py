"""Keep state writes within the recipe and action that the user actually reports."""

import re

from explicit_nonstart_v24 import WORD
from grounded_progress_v25 import object_word
from grounded_recipe_source_v27 import EXTRA, apply as grounded_report
from scoped_decode_v17 import ANAPHOR, COMPLETED, UNRESOLVED, compact, literal_ids, safe_parse
from scoped_doubt_v48 import DOUBT, PARTS, guard_doubt, targets
from scoped_reports_v47 import REVISION

PREVIOUS_RECIPE = re.compile(
    r'\b(?:במתכון (?:הקודם|שסגרנו|שהחלפנו|הישן)|'
    r'(?:על|של|מ) ?המתכון הקודם|לפני (?:שהחלפתי|שעברתי) (?:את ה)?מתכון|'
    r'כשבישלתי (?:במתכון|את המתכון) הקודם)\b'
)
CURRENT_RECIPE = re.compile(r'^(?:ועכשיו |כעת |עכשיו )?(?:עברתי ל|החלפתי ל|אני ב|אנחנו ב|נמשיך ב)')
CURRENT_REPORT = re.compile(r'^(?:(?:ו?במתכון (?:הזה|הנוכחי|החדש)|ו?עכשיו|כעת|כאן|הפעם)\s*[:,]?\s+)')
NO_UPDATE = re.compile(r'\b(?:עוד לא קבעתי שבוצע כלום|לא סימנתי שום פעולה|עדיין לא דיווחתי על ביצוע)\b')
FOLLOW_UP = re.compile(
    r'^(?:מה (?:הצעד|השלב|הדבר|עוד נשאר|בא|עושים|נשאר|עכשיו|הלאה)|'
    r'איך (?:מתקדמים|אני מתקדמ[ת]?|ממשיכים|להמשיך|נמשיך)|'
    r'סדר(?:י)? לי את ההמשך|לאן (?:מכאן|להתקדם))\b'
)
EARLIER = re.compile(r'\b(?:פספסתי|דילגתי|מאחור|בשלבים הקודמים|השלב הקודם)\b')
REFERENCE = re.compile(r'\b(?:ההיא|ההוא|אותה|אותו|עליו|עליה|לזה|זה|זאת|הפעולה ששאלת)\b')
CLAIM = re.compile(r'\b(?:נגמר[הת]?|מוכנ[הת]?|גמור[הת]?|לסגור|סימנתי וי|לעדכן שסיימתי)\b')

NAMED_DOUBT = re.compile(
    r'\b(?:אני )?(?:עדיין )?(?:מתלבט(?:ת)?|לא סגור(?:ה)?|'
    r'לא יכול(?:ה)? לתת עדכון סופי|לא בטוח(?:ה)? שזה בוצע|עוד אין לי אישור)\b'
)
ASSURANCE_PREFIX = re.compile(
    r'^(?:אני יכול(?:ה)? לחתום על זה ש|מה שברור זה ש|'
    r'יש לי אישור ברור ש|אני בטוח(?:ה)? ש|לגבי מה שבטוח\s*:\s*)'
)
CERTAINTY_SUFFIX = re.compile(r'\s+(?:בוודאות(?: גמורה)?|בלי שום ספק)$')
META = re.compile(
    r'^(?:אין לי ודאות|צריך עוד לברר את זה|'
    r'לגבי החלק השני יש לי אישור ברור|לגבי הפעולה האחרת זה ודאי|'
    r'פה אני בטוח(?:ה)?)$'
)
ADDITIONAL_PAST = {'לנפות':'ניפיתי', 'לכתוש':'כתשתי', 'לפורר':'פוררתי'}


def explicit_report(row, clause):
    """Recognize a complete standalone report, without borrowing a history target."""
    clause = CURRENT_REPORT.sub('',clause)
    text = CERTAINTY_SUFFIX.sub('', ASSURANCE_PREFIX.sub('', clause)).strip()
    request = row['input']
    probe = {**row, 'input':{**request,'history':[],'utterance':text}}
    result, identified = grounded_report(probe,'{}')
    parsed = safe_parse(result,probe) if identified else None
    if parsed and parsed['intent']=='report' and len(parsed['facts'])==1 and not parsed['clarify']:
        return parsed['facts'][0]

    # Extends only the exact first-person pattern when the recipe verb is not in V27.
    unique = []
    for action in request['recipe']['actions']:
        verb, _, tail = action['source'].strip().rstrip('.').partition(' ')
        past = ADDITIONAL_PAST.get(verb)
        objects = [word for word in tail.split() if word!='את']
        if not past or not objects or not all(WORD.fullmatch(w) for w in objects):
            continue
        noun = ' '.join(object_word(w) for w in objects)
        if re.fullmatch(rf'(?:כבר )?{past} (?:את )?{noun}',text):
            unique.append({'action':action['id'],'status':'done'})
    return unique[0] if len(unique)==1 else None


def unresolved_choice(request):
    history = request['history']
    if not history or history[-1]['role']!='assistant':
        return False
    last = history[-1]['content']
    return bool(UNRESOLVED.search(last)) and len(literal_ids(last,request))>=2


def ambiguous_report(request, clauses):
    if not unresolved_choice(request):
        return False
    text = request['utterance']
    if not (ANAPHOR.search(text) or REFERENCE.search(text)):
        return False
    if not (COMPLETED.search(text) or CLAIM.search(text)):
        return False
    # Explicit naming or selecting one of the alternatives is stronger than the old ambiguity.
    if re.search(r'\b(?:הראשונ[הן]|השני(?:יה)?|התכוונתי ל|אני מדבר(?:ת)? על)\b',text):
        return False
    return not any(targets(clause,request)[0] for clause in clauses)


def classify(row, clause):
    request = row['input']
    if PREVIOUS_RECIPE.search(clause) and not REVISION.search(clause):
        return 'previous',None
    if FOLLOW_UP.match(clause):
        return 'follow_up','missed' if EARLIER.search(clause) else 'next'
    name = request['recipe'].get('name')
    if name and name in clause and (CURRENT_RECIPE.match(clause) or NO_UPDATE.search(clause)):
        return 'switch',None
    if META.fullmatch(clause):
        return 'qualifier',None
    if (DOUBT.match(clause) or NAMED_DOUBT.search(clause)) and not REVISION.search(clause):
        named, witnessed = targets(clause,request)
        if len(named)==1 and witnessed:
            return 'doubt',next(iter(named))
    report = explicit_report(row,clause)
    return ('report',report) if report else ('unknown',None)


def interpret(row, raw):
    accepted,path = guard_doubt(row,raw)
    current = safe_parse(accepted,row)
    request = row['input']
    clauses = [m.group().strip() for m in PARTS.finditer(request['utterance']) if m.group().strip()]
    if current and (current['facts'] or current['intent'] in ('report','clarify','other')) and ambiguous_report(request,clauses):
        return compact({'intent':'clarify','facts':[],'clarify':[None]},row),'unresolved_history_choice'

    kinds = [classify(row,clause) for clause in clauses]
    labels = {kind for kind,_ in kinds}
    anchored = ('previous' in labels and 'follow_up' in labels) or {'doubt','report'}<=labels
    if anchored and 'unknown' not in labels:
        reports = [value for label,value in kinds if label=='report']
        doubts = {value for label,value in kinds if label=='doubt'}
        navigation = {value for label,value in kinds if label=='follow_up'}
        ids = [fact['action'] for fact in reports]
        if len(navigation)<=1 and len(ids)==len(set(ids)) and not doubts.intersection(ids):
            intent = next(iter(navigation)) if navigation else 'report' if reports else 'clarify'
            result = {'intent':intent,'facts':reports,'clarify':sorted(doubts)}
            if result != current:
                return compact(result,row),'bound_recipe_and_action'
    if current and current['intent']=='missed' and not current['facts'] and not current['clarify']:
        if clauses and clauses[0].startswith(('סדר לי את ההמשך','סדרי לי את ההמשך')) and not EARLIER.search(request['utterance']):
            return compact({**current,'intent':'next'},row),'explicit_next_step'
    return accepted,path
