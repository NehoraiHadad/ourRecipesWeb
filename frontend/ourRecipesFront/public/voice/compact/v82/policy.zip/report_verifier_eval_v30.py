"""Test V30 as a selective veto on the frozen V27 interpretation pipeline."""
import argparse
import json
from pathlib import Path

from broad_text_data_v28 import DATA as BROAD
from fresh_pairs_v15 import digest, read, write
from report_prompt_data_v29 import DATA as FRESH
from report_prompt_study_v29 import assess
from report_verifier_v30 import LABELS, calibrate, prepare, probabilities, verify
from sparse_recipe_v3 import parse
from scoped_decode_v17 import compact

ROOT = Path(__file__).resolve().parent
V28_RAW = ROOT / 'verification/broad-text-raw-v28-20261119.jsonl'


def veto(row, text, vector, threshold):
    if threshold is None or 1 - vector[0] < threshold:
        return text, False
    try:
        reply = parse(text, row['input'])
    except (ValueError, KeyError, TypeError):
        return text, False
    if not reply['facts']:
        return text, False
    targets = reply['clarify']
    intent = reply['intent']
    if intent == 'report':
        intent = 'clarify' if targets else LABELS[max(range(1, len(LABELS)), key=lambda i: vector[i])]
    if intent == 'clarify' and not targets:
        targets = [None]
    return compact({'intent': intent, 'facts': [], 'clarify': targets}, row), True


def compare(rows, controls, vectors, calibration):
    if [r['id'] for r in rows] != [p['id'] for p in controls]:
        raise ValueError('Verifier lane identity mismatch')
    threshold = calibration['threshold'] if calibration else None
    outputs = []
    for row, prior, probs in zip(rows, controls, vectors, strict=True):
        text, filtered = veto(row, prior['text'], probs, threshold)
        outputs.append({'id': row['id'], 'control': prior['text'], 'text': text,
                        'veto': filtered, 'probabilities': probs})
    return {'control': assess(rows, controls), 'verifier': assess(rows, outputs),
            'suppressed': sum(record['veto'] for record in outputs),
            'suppressed_real_reports': sum(p['veto'] and bool(r['expected']['facts'])
                                           for r, p in zip(rows, outputs, strict=True))}, outputs


def decide(groups, calibration):
    first, after = (groups['fresh'][arm]['overall'] for arm in ('control', 'verifier'))
    old, current = (groups['broad'][arm]['overall'] for arm in ('control', 'verifier'))
    before, end = first['critical_wrong_fact_cases'], after['critical_wrong_fact_cases']
    checks = {'calibrated': calibration is not None,
              'fresh_false_update_reduction': before - end >= 2 and 3 * end <= 2 * before,
              'broad_no_more_false_updates': current['critical_wrong_fact_cases'] <= old['critical_wrong_fact_cases'],
              'all_exact_retained': after['exact'] >= first['exact'] and current['exact'] >= old['exact'],
              'real_reports_not_suppressed': all(g['suppressed_real_reports'] == 0 for g in groups.values())}
    return {'checks': checks, 'passed': all(checks.values())}


def run(fitted, fresh_reference, output):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    config, splits = verify()
    proof = read(fitted / 'fit.json')
    calibration_records = read(fitted / 'calibration-raw.json')
    calibration_rows = splits['calibration']
    if [r['id'] for r in calibration_rows] != [r['id'] for r in calibration_records]:
        raise ValueError('Calibration row identity mismatch')
    if calibrate(calibration_rows, [r['probabilities'] for r in calibration_records], config) != proof['calibration']:
        raise ValueError('Calibration could not be reproduced')
    folder = fitted / 'checkpoint'
    for name, sha in proof['checkpoint_sha256'].items():
        if digest(folder / name) != sha:
            raise ValueError(f'Changed verifier checkpoint: {name}')
    torch.set_num_threads(config['threads'])
    model = AutoModelForSequenceClassification.from_pretrained(folder, local_files_only=True, trust_remote_code=False)
    tokenizer = AutoTokenizer.from_pretrained(folder, local_files_only=True, trust_remote_code=False)
    output.mkdir(parents=True, exist_ok=False)
    with V28_RAW.open() as stream:
        broad_controls = [{'id': r['id'], 'text': r['v27']} for line in stream
                          if (r := json.loads(line))['kind'] == 'comparison']
    fresh_controls = [{'id': r['id'], 'text': r['control_v27']} for r in read(fresh_reference)]
    groups, result = {}, {}
    chosen = proof['calibration']['chosen']
    for name, rows, prior in (('broad', read(BROAD), broad_controls), ('fresh', read(FRESH), fresh_controls)):
        vectors = probabilities(model, tokenizer, prepare(tokenizer, rows, config), config)
        groups[name], result[name] = compare(rows, prior, vectors, chosen)
    write(output / 'raw.json', result)
    write(output / 'study.json', {'groups': groups, 'fit': proof, 'decision': decide(groups, chosen)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fitted', type=Path)
    parser.add_argument('fresh_reference', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.fitted, args.fresh_reference, args.output)
