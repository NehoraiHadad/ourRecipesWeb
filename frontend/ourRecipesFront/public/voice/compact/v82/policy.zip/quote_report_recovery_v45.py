"""Recover an independently grounded report when a separate quote hid it."""
import re

from clause_report_verifier_v40 import CLAUSES
from grounded_recipe_source_v27 import apply as grounded
from grounded_scope_v18 import grounded_actions
from grounded_updates_v44 import accept
from scoped_decode_v17 import compact, literal_ids, safe_parse

QUOTED = re.compile(r'״[^״]+״|"[^"]+"')
ATTRIBUTION = re.compile(r'ציטוט|מצטט|ציטטתי|דוגמ[אה]|הדגמה|מקריא|הקראתי|משפט לתרגול|לא דיווח')
CERTAINTY = re.compile(r',\s*(?:בזה אין ספק|זה בטוח|בוודאות גמורה)\s*$')


def recover(row, raw):
    accepted, path = accept(row,raw)
    proposal = safe_parse(accepted,row)
    if not proposal or proposal['facts'] or proposal['intent'] not in ('next','missed'):
        return accepted,path
    request = row['input']
    clauses = [m.group().strip() for m in CLAUSES.finditer(request['utterance'])]
    if not any(QUOTED.search(clause) and ATTRIBUTION.search(QUOTED.sub('',clause)) for clause in clauses):
        return accepted,path
    anchored = [literal_ids(clause,request) or grounded_actions(clause,request) for clause in clauses]
    candidates = []
    for i,clause in enumerate(clauses):
        if QUOTED.search(clause):
            continue
        one = {**row,'input':{**request,'utterance':CERTAINTY.sub('',clause)}}
        answer, identified = grounded(one,'{}')
        parsed = safe_parse(answer,one) if identified else None
        if not parsed or parsed['intent']!='report' or len(parsed['facts'])!=1 or parsed['clarify']:
            continue
        fact = parsed['facts'][0]
        action = fact['action']
        other_mentions = any(action in targets for j,targets in enumerate(anchored) if j!=i)
        if (action in anchored[i] and action not in proposal['clarify']
                and None not in proposal['clarify'] and not other_mentions):
            candidates.append(fact)
    if len(candidates)!=1:
        return accepted,path
    return compact({**proposal,'facts':candidates},row),'independent_report_recovered'
