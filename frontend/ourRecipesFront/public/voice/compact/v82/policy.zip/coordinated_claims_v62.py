"""Resolve each asserted cooking event against the recipe before combining its effects."""
import json
import re
from dataclasses import dataclass

from colloquial_evidence_v60 import BLOCK, decision, pack
from destination_evidence_v61 import (DEST, ORIGIN, PREFACE, SOURCE_VERB, VERB, VESSEL,
                                      ingredient, interpret as previous)
from turn_evidence_v58 import DOUBT, MENTION, NOMINAL, PAST, PRIOR_CONTEXT, simulate

QUALIFIER = r'ה?(?:משומנ(?:ת|ות)?|גדול(?:ה)?|קטנ(?:ה)?|עמוק(?:ה)?|רחב(?:ה)?|חמ(?:ה)?|קר(?:ה)?)'
PLACE = re.compile(DEST.pattern + r'(?:\s+(' + QUALIFIER + r'))?')
MOVES = set(re.findall(r'[א-ת]+', VERB)) | {'יצקתי','יצקנו','הנחתי','הנחנו'}
PRONOUN = {'אותו','אותה','אותם','אותן','זה','הכמות','הכמות הזאת','ממנו','ממנה','מהם','מהן'}
PART = re.compile(r'^(?:רק )?(?:חצי|שליש|רבע|חלק) (?:מ(?=\S)|מן )?')
COORD = re.compile(r'\s+(?:ואז|ואחר כך|ואחרי זה|ומיד אחר כך|אחר כך|ואילו|וגם|אבל)\s+|\s+ו(?=[א-ת])')
UNCERTAIN = re.compile(r'^(?:אולי |ייתכן ש|נדמה לי ש|אני לא (?:בטוח|בטוחה) ש)')
REPORTED = re.compile(r'^(?:נניח ש|נגיד ש|כתוב ש|(?:הוא אמר|היא אמרה) ש)')
WAIT = re.compile(r'(?:את )?ה?([א-ת]+) (?:אשאיר|השארתי|דחיתי) (?:ל(?:אחר כך|מחר)|להמשך)')
FOLLOWUP = re.compile(r'(?:רק )?(?:מה השלב הבא|מה עכשיו|מה הלאה|איך ממשיכים)')

@dataclass(frozen=True)
class Action:
    key: str
    verb: str
    obj: tuple
    vessel: str
    qualifier: tuple
    origin: tuple


def action_slots(rows):
    slots=[]
    for row in rows:
        words=row['source'].split(maxsplit=1)
        if len(words)!=2:
            continue
        verb,body=words
        places=list(PLACE.finditer(body))
        if len(places)>1:
            continue
        dest=places[0] if places else None
        source=tuple(ORIGIN.findall(body))
        if dest:
            body=body[:dest.start()]+' '+body[dest.end():]
        body=re.sub(r' (?:במשך )?(?:[0-9]+|שתי|שלוש|ארבע|חמש|עשר|עשרים) (?:דקות|שעות)$','',body.rstrip('. '))
        obj=ingredient(ORIGIN.sub(' ',body))
        if obj:
            slots.append(Action(row['id'],verb,obj,dest[1] if dest else '',
                                ingredient(dest[2] or '') if dest else (),source))
    return slots


def select(slots,obj,verbs,vessel='',qualifier='',origin=()):
    pool=[a for a in slots if a.obj==obj and a.verb in verbs]
    if vessel:
        explicit=[a for a in pool if a.vessel]
        if explicit:
            pool=[a for a in explicit if a.vessel==vessel and
                  (not qualifier or not a.qualifier or a.qualifier==ingredient(qualifier))]
    if origin:
        pool=[a for a in pool if not a.origin or a.origin==origin]
    return pool[0].key if len(pool)==1 else None


def referent(text,last):
    body=re.sub(r'^(?:את |כל )+', '',text.strip())
    return last if body in PRONOUN else ingredient(body)


def clause(text,slots,last):
    """Return one grounded fact, an unresolved target, or None for another language form."""
    # The empty vessel alone does not identify which ingredient was withheld.
    if re.fullmatch(r'ה?'+VESSEL+r' (?:עדיין ריק[ה]?|נשאר[ה]? ריק[ה]?)',text):
        return '',None,last
    waiting=WAIT.fullmatch(text)
    if waiting and last:
        names=[verb for verb,noun in NOMINAL.items() if noun==waiting[1]]
        if names:
            return select(slots,last,names),'pending',last
    shapes=re.fullmatch(r'(קוביות|פרוסות|חתיכות קטנות) של (.+?)(?: כבר)? יש (?:לי|לנו) (?:על ה(?:קרש|צלחת)|בקערה)',text)
    if shapes and any(a.obj==ingredient(shapes[2]) for a in slots):
        obj=ingredient(shapes[2])
        verbs=('לפרוס',) if shapes[1]=='פרוסות' else ('לקצוץ','לחתוך')
        return select(slots,obj,verbs),'done',obj
    result=re.fullmatch(r'(.+?) (?:כבר )?(?:שבבים|קוביות|פרוסות|חתיכות)(?: קטנ(?:ים|ות))? אחרי ה([א-ת]+)',text)
    if result and any(a.obj==ingredient(result[1]) for a in slots):
        obj=ingredient(result[1])
        names=[verb for verb,noun in NOMINAL.items() if noun==result[2]]
        if names:
            return select(slots,obj,names),'done',obj
    untouched=re.fullmatch(r'(.+?) (?:עוד |עדיין )?לא פגש(?:ה|ו)? (?:שמן|מחבת)',text)
    if untouched:
        obj=last if untouched[1] in ('הוא','היא','הם','הן') else ingredient(untouched[1])
        if any(a.obj==obj for a in slots):
            return select(slots,obj,('לטגן',)),'pending',obj
    aside=re.fullmatch(r'(.+?) (?:עדיין |עוד )?נשאר(?:ה|ו)? (?:על השיש|בצד)(?: בינתיים)?',text)
    if aside:
        obj=ingredient(aside[1])
        if any(a.obj==obj for a in slots):
            return select(slots,obj,SOURCE_VERB),'pending',obj

    positions=list(PLACE.finditer(text))
    if len(positions)>1:
        return None
    dest=positions[0] if positions else None
    origins=tuple(ORIGIN.findall(text))
    if len(origins)>1:
        return None
    body=text if dest is None else text[:dest.start()]+' '+text[dest.end():]
    words=ORIGIN.sub(' ',body).split()
    past={}
    partial_verb=None
    for a in slots:
        form=PAST.get(a.verb)
        if form:
            past[form]=a.verb
            if form.endswith('תי'):
                past[form[:-2]+'נו']=a.verb
        if a.verb in words and re.search(r'^(?:רק )?התחל(?:תי|נו) '+re.escape(a.verb)+r'\b',body.strip()):
            partial_verb=a.verb
    if partial_verb:
        words=[w for w in words if w not in ('רק','התחלתי','התחלנו')]
        past[partial_verb]=partial_verb
    predicates=[w for w in words if w in past or w in MOVES or w in ('הלך','הלכה','הלכו')]
    if len(predicates)>1:
        return None
    predicate=predicates[0] if predicates else None
    if not predicate and not dest:
        return None
    if predicate:
        words.remove(predicate)
    body=' '.join(words)
    negated=bool(re.search(r'(?:^| )(?:עוד לא|עדיין לא|טרם|לא)(?: |$)',body))
    body=re.sub(r'(?:^| )(?:עוד לא|עדיין לא|טרם|לא|כבר|כן)(?= |$)',' ',body).strip()
    body=re.sub(r' (?:עד הסוף|לגמרי)$','',body)
    body=re.sub(r'^את\s+','',body)
    fraction=PART.match(body)
    if fraction:
        body=body[fraction.end():]
    obj=referent(body,last)
    if not obj or not any(a.obj==obj for a in slots):
        return None
    verbs=SOURCE_VERB if predicate in MOVES or predicate not in past else (past[predicate],)
    if not predicate or predicate in ('הלך','הלכה','הלכו'):
        if not dest:
            return None
    key=select(slots,obj,verbs,dest[1] if dest else '',dest[2] if dest else '',origins)
    return key,'doubt' if fraction and negated else 'pending' if negated else 'partial' if fraction or partial_verb else 'done',obj


def interpret(row,raw):
    req=row['input']
    text=req['utterance'].strip()
    if PRIOR_CONTEXT.search(text) or any(mark in text for mark in ('״','"','“','”')):
        return previous(row,raw)
    slots=action_slots(req['recipe']['actions'])
    text=PREFACE.sub('',text)
    facts={}
    doubts={}
    last=None
    intent=None
    handled=False
    for sentence,mark in re.findall(r'([^.;!?]+)([.;!?]*)',text):
        sentence=sentence.strip()
        if FOLLOWUP.fullmatch(sentence) and '?' in mark:
            intent='next'
            continue
        unsure=UNCERTAIN.match(sentence)
        reported=REPORTED.match(sentence)
        prefix=unsure or reported
        if prefix:
            sentence=sentence[prefix.end():]
        if (DOUBT.search(sentence) or MENTION.search(sentence)
                or (BLOCK.search(sentence) and not WAIT.search(sentence))):
            return previous(row,raw)
        for phrase in re.split(r'\s*,\s*',sentence):
            # Prefer a complete event so that a vav inside a multi-word ingredient
            # does not split that ingredient into two reports.
            parsed=clause(phrase,slots,last)
            parts=[phrase] if parsed else COORD.split(phrase)
            for part in parts:
                event=parsed or clause(part,slots,last)
                if event is None:
                    return previous(row,raw)
                key,status,last=event
                handled=True
                if reported or status is None:
                    continue
                if '?' in mark or unsure or status=='doubt' or key is None:
                    facts.pop(key,None)
                    doubts[key]=True
                else:
                    doubts.pop(key,None)
                    facts[key]=status
    if handled:
        return pack(decision(facts.items(),doubts,intent),'coordinated_evidence')
    return previous(row,raw)


def process(payload,raw):
    row=json.loads(payload)
    accepted,route=interpret(row,raw)
    return json.dumps({**simulate(row,accepted),'route':route,'accepted_text':accepted},ensure_ascii=False)
