"""Train on the original JSON and contrast a single unsupported alternative at its first differing token."""
import argparse
from collections import Counter
import copy
import gc
from importlib.metadata import version
import json
from pathlib import Path
import time
from unittest.mock import patch

import adapter_scope_sft_v11 as engine
from semantic_supervision_data_v12 import LABELS, NATIVE, ROOT, audit, read_labels, read_native
import semantic_supervision_train_v12 as trainer
from semantic_supervision_v12 import compare_at_endpoint, exposure, load_tokenizer
from sparse_recipe_study_v4 import metrics_for
from sparse_recipe_v3 import facts, validate

ARMS = ('primary_only', 'fact_contrast')
PLAN = ROOT / 'verification/fact-contrast-plan-v13-20261118.json'
MANIFEST = ROOT / 'verification/fact-contrast-freeze-v13-20261118.json'
NEGATIVES = ROOT / 'verification/fact-contrast-targets-v13-20261118.jsonl'


def read_plan():
    return json.loads(PLAN.read_text())


def verify_freeze():
    for name, expected in json.loads(MANIFEST.read_text())['sha256'].items():
        if engine.digest(ROOT / name) != expected:
            raise ValueError(f'Frozen V13 source or data changed: {name}')


def negative(row, label):
    """Keep intent fixed, change one fact, and remove conflicting clarification."""
    request = row['input']
    gold = row['expected']
    value = copy.deepcopy(gold)
    attached = {fact['action'] for fact in gold['facts']}
    nonreports = {'uncertain', 'plan', 'quoted', 'hypothetical'}
    unsupported = next((c for c in label['target']['clauses']
                        if c['stance'] in nonreports and c['action'] not in attached), None)
    reason = None
    if unsupported:
        action = unsupported['action']
        reason = unsupported['stance']
    elif label['history'] and len(label['history']['candidates']) > 1:
        action = label['history']['candidates'][0]
        reason = 'ambiguous_reference'
    if reason:
        value['facts'].append({'action': action, 'status': 'done'})
        value['clarify'] = [target for target in value['clarify'] if target != action]
        if value['intent'] == 'clarify' and not value['clarify']:
            value['clarify'] = [None]
    elif value['facts']:
        first = value['facts'][0]
        first['status'] = 'pending' if first['status'] == 'done' else 'done'
        reason = 'status_flip'
    else:
        return None
    validate(value, request)
    if value['intent'] != gold['intent'] or len(set(facts(value)) - set(facts(gold))) != 1:
        raise ValueError('The contrast must preserve intent and introduce one wrong fact')
    return {'id': row['id'], 'reason': reason, 'rejected': value}


def build_targets(splits, labels):
    audit(splits, labels)
    by_id = {row['id']: row for row in splits['train']}
    return [target for label in labels if (target := negative(by_id[label['id']], label)) is not None]


def read_targets():
    return [json.loads(line) for line in NEGATIVES.read_text().splitlines()]


def encode(tokenizer, plan, rows, targets):
    limit = plan['max_sequence_tokens']
    main = [engine.encode(tokenizer, row, limit) for row in rows]
    by_id = {row['id']: i for i, row in enumerate(rows)}
    extra = {}
    for target in targets:
        index = by_id[target['id']]
        gold = main[index]
        bad = engine.encode(tokenizer, {**rows[index], 'expected': target['rejected']}, limit)
        gold_tokens, bad_tokens = gold['input_ids'], bad['input_ids']
        position = next(i for i, (a, b) in enumerate(zip(gold_tokens, bad_tokens)) if a != b)
        if gold['prompt_tokens'] != bad['prompt_tokens'] or position < gold['prompt_tokens']:
            raise ValueError('The candidate changed the prompt')
        good, reject = gold_tokens[position], bad_tokens[position]
        if gold['labels'][position] != good or bad['labels'][position] != reject:
            raise ValueError('The contrast is outside the unmasked answer')
        if tokenizer.eos_token_id in (good, reject):
            raise ValueError('A contrast resolved by termination rather than a fact token')
        extra[index] = (position, good, reject)
    return main, extra


def schedule_summary(main, extra, order):
    return {'primary_visits': len(order), 'primary_input_tokens': sum(len(main[i]['input_ids']) for i in order),
            'primary_target_tokens': sum(main[i]['target_tokens'] for i in order),
            'max_primary_context': max(len(main[i]['input_ids']) for i in order),
            'contrast_positions': sum(i in extra for i in order), 'additional_model_forwards_per_arm': 0}


def preflight(tokenizer, plan, splits, targets):
    if targets != build_targets(splits, read_labels()):
        raise ValueError('Frozen negatives differ from their reviewed TRAIN derivation')
    main, extra = encode(tokenizer, plan, splits['train'], targets)
    order = exposure(plan, len(main))
    return {'negatives': len(extra), 'reasons': dict(sorted(Counter(t['reason'] for t in targets).items())),
            'all_rejected_answers_contract_valid': True, 'all_intents_preserved': True,
            'shared_prefix_confirmed': True, 'prompt_and_eos_excluded_from_contrast': True,
            'scheduled_exposure': schedule_summary(main, extra, order)}


def loss_step(model, main, extra, indices, pad_id, device, *, backward, weight, margin):
    import torch
    from torch.nn import functional as F

    records = [main[i] for i in indices]
    batch = engine.collate(records, pad_id, device)
    labels = batch.pop('labels')
    first = min(record['prompt_tokens'] for record in records) - 1
    positions = torch.arange(first, labels.shape[1] - 1, device=device)
    with torch.autocast(device, dtype=torch.float16, enabled=device == 'cuda'):
        logits = model(**batch, logits_to_keep=positions, use_cache=False).logits
    targets = labels[:, first + 1:]
    active = targets != -100
    ce = F.cross_entropy(logits[active].float(), targets[active], reduction='none')
    main_loss = torch.stack([part.mean() for part in ce.split([r['target_tokens'] for r in records])]).mean()

    pairs = [(j, *extra[i]) for j, i in enumerate(indices) if i in extra]
    contrast = main_loss.new_zeros(())
    rank_correct = 0
    if pairs:
        rows, token_positions, gold, wrong = torch.tensor(pairs, device=device).T
        token_positions = token_positions - first - 1
        gap = logits[rows, token_positions, gold].float() - logits[rows, token_positions, wrong].float()
        contrast = F.softplus(margin - gap).sum() / len(indices)
        rank_correct = (gap > 0).sum().item()
    backward(main_loss + weight * contrast)
    return {'primary_mean': main_loss.detach().item(), 'contrast_mean_over_batch': contrast.detach().item(),
            'contrast_weight': weight, 'contrast_count': len(pairs), 'contrast_correct_before_update': rank_correct}


def run(output):
    import torch
    from huggingface_hub import snapshot_download

    verify_freeze()
    plan = read_plan()
    runtime = plan['runtime']
    if (not torch.cuda.is_available() or runtime['gpu'] not in torch.cuda.get_device_name(0)
            or torch.__version__.split('+')[0] != runtime['torch'] or torch.version.cuda != runtime['cuda']):
        raise RuntimeError('V13 requires a physical T4 and the pinned CUDA and PyTorch')
    for dependency in plan['dependencies']:
        package, expected = dependency.split('==')
        if version(package) != expected:
            raise RuntimeError(f'V13 requires {dependency}')
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    torch.set_num_threads(2)
    engine.dump(output / 'environment.json', {'torch': torch.__version__, 'cuda': torch.version.cuda,
                                             'gpu': torch.cuda.get_device_name(0)})
    settings = plan['model']
    snapshot = Path(snapshot_download(settings['repo'], revision=settings['revision'], token=False,
                    allow_patterns=['config.json', 'generation_config.json', 'tokenizer*.json', '*.jinja',
                                    'vocab.json', 'merges.txt', 'model.safetensors', 'LICENSE']))
    weights = snapshot / 'model.safetensors'
    if weights.stat().st_size != settings['weight_bytes'] or engine.digest(weights) != settings['weight_sha256']:
        raise ValueError('Base model integrity failure')
    for name, expected in settings['small_file_sha256'].items():
        if engine.digest(snapshot / name) != expected:
            raise ValueError(f'Model metadata integrity failure: {name}')
    tokenizer = load_tokenizer(snapshot, plan)
    data = read_native()
    targets = read_targets()
    if targets != build_targets(data, read_labels()):
        raise ValueError('Rejected answers differ from frozen TRAIN derivation')
    main, extra = encode(tokenizer, plan, data['train'], targets)
    order = exposure(plan, len(main))
    benchmark = json.loads((ROOT / plan['evaluation']['master_file']).read_text())['splits']
    anchor = None
    summaries = {}
    for arm in ARMS:
        print(f'Running {arm}', flush=True)
        path = output / arm
        weight = plan['contrast']['weights'][arm]

        def objective(model, main, extra, indices, pad_id, device, *, backward):
            return loss_step(model, main, extra, indices, pad_id, device, backward=backward,
                             weight=weight, margin=plan['contrast']['margin'])

        # Adapt two callbacks on the immutable V12 trainer. Checkpointing, evaluation,
        # initialization, exposure and runtime bounds are identical in both arms.
        with patch.object(trainer, 'microbatch', objective), patch.object(trainer, 'token_summary', schedule_summary):
            anchor = trainer.train_arm(path, snapshot, tokenizer, plan, data, main, extra, order, started, anchor)
        summaries[arm] = [metrics_for(path, step, benchmark) for step in (0, *plan['training']['evaluate_at'])]
        gc.collect()
        torch.cuda.empty_cache()
    decision = compare_at_endpoint(summaries[ARMS[0]][-1], summaries[ARMS[1]][-1], plan)
    engine.dump(output / 'result.json', {'training_performed': True, 'matching_fresh_baselines': True,
                                        'arms': summaries, 'decision': decision, 'scope': plan['scope']})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--preflight', type=Path)
    actions.add_argument('--train', type=Path)
    args = parser.parse_args()
    if args.train:
        run(args.train)
    else:
        verify_freeze()
        plan = read_plan()
        result = preflight(load_tokenizer(args.preflight, plan), plan, read_native(), read_targets())
        print(json.dumps(result, ensure_ascii=False, indent=2))
