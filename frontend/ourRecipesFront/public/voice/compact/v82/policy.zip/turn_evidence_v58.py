"""Ground local model proposals in asserted clauses, including shared objects and corrections."""
import json
import re
from scoped_decode_v17 import UNRESOLVED

from grounded_progress_v25 import VERBS, PASSIVE
from grounded_recipe_source_v27 import EXTRA
from grounded_scope_v18 import forms, WORDS
from scoped_doubt_v48 import ALIASES
from scoped_turn_claims_v52 import interpret as v52, PRIOR_CONTEXT
from scoped_decode_v17 import literal_ids
from turn_scope_v50 import ADDITIONAL_PAST
from recipe_text_responder_v52 import simulate

PAST = VERBS | EXTRA | ADDITIONAL_PAST | {
    'לצלות':'צליתי','לפצל':'פיצלתי','לטרוף':'טרפתי','לקפל':'קיפלתי','לגלען':'גילענתי','לרדד':'רידדתי',
    'לסגור':'סגרתי','למלא':'מילאתי','לקרוץ':'קרצתי','לחלוט':'חלטתי','להקפיץ':'הקפצתי',
}
NOMINAL = {'לחתוך':'חיתוך','לטגן':'טיגון','לשקול':'שקילה','לשטוף':'שטיפה','לטחון':'טחינה',
           'לקלות':'קלייה','לקלף':'קילוף','לפרוס':'פריסה','לבשל':'בישול','לאפות':'אפייה',
           'לסנן':'סינון','לקצוץ':'קיצוץ','להשרות':'השריה','לגרר':'גירור','לערבב':'ערבוב'}
PENDING = re.compile(r'(?:עוד|עדיין) לא|טרם|לא (?:נגעתי|ניגשתי|התחלתי|עשיתי|ביצעתי)|'
    r'לא (?:יצא|הספקתי) לי|אפילו ההתחלה עוד לא|מחכ(?:ה|ים|ות) (?:לי|ל)|עוד לפניי|לא הגעתי|אין שום התקדמות|לא שמתי|בלי להתחיל')
PARTIAL = re.compile(r'\b(?:חלקית|חלקי|בחלק[והם]|רק חלק|חלק מהכמות|עשיתי חלק|ה?חצי|שליש|רבע)\b|לאמצע|באמצע|עד האמצע|לא (?:עד הסוף|סיימתי|גמרתי|הכול|הכל)|'
    r'נשאר (?:עוד|להשלים|לי)|נותר (?:עוד|להשלים)|כמות מחכה|כמות (?:אחת|נוספת) מחכה|רק (?:אחד|שתיים|שניים|שני|קצת|מעט|חופן)|אחד מתוך|התחלתי')
DONE = re.compile(r'סיימתי|השלמתי|גמרתי|במלוא|לגמרי|עד הסוף|בוצע|הושלם|גמור|נגמר|מוכ[ןנה]|את כל הכמות|כמו שצריך|הכול|סימנתי וי')
DOUBT = re.compile(r'לא מצליח[ה]? להיזכר|יש לי ספק|יכול להיות|אין לי דרך לדעת|אין לי (?:ודאות|ביטחון)|לא יכול[ה]? לומר אם|מהסס|ספק אם|אולי|ייתכן|יתכן|נדמה לי|נראה לי|כמעט בטוח|יש (?:מצב|סיכוי|ספק)|לא (?:ממש )?(?:זוכר|זוכרת|בטוח|בטוחה|סגור|סגורה|יודע|יודעת)|'
                   r'אין לי מושג|לא ברור לי אם|מנסה להיזכר|לא יודע[ת]? לומר|מתלבט|בספק|קשה לי (?:לזכור|להיזכר)|סימן שאלה')
MENTION = re.compile(r'נגיד ש|נניח|נדמיין|לצורך (?:השאלה|הדיון|ההסבר)|כתב בספר|מתוך הספר|ציטטתי|טקסט לתרגול|ציטוט|מצטט|כתבו|הקרא|להקראה|מקריא|הדגמ|לדוגמ|כדוגמ|דוגמה|מדקל|היה כתוב|השפית|כתב לי|'
                     r'טקסט לעריכה|משחקים בכאילו|אילו |הייתי (?:אומר|מוסי)|לו הייתי|אם היינו|בתיאוריה')
PLAN = re.compile(r'\b(?:כשא|כשי|כשה)|יותר מאוחר|עוד מעט|בעתיד|אחר כך א|מיועד|בהמשך (?:הערב|היום)|מתכנ|ביצוע מתוכנן|לפי (?:הדף|המתכון) צריך')
REFER = re.compile(r'ההיא|ההוא|אות[הוםן]|עליו|עליה|שהזכרת|ששאלת|הדבר|לשאלה שלך|היא|הוא')
QUESTION = re.compile(r'^(?:ו?מה(?:ו|י)?\b|איך\b|האם\b|איפה\b|לאן\b|איז[הו]\b|כמה\b|אפשר לקבל|תזכיר|סדר[י]? לי|יש משהו מ)')
NEXT = re.compile(r'מה (?:הצעד|הדבר|השלב|בא|עושים|עכשיו|נשאר|הלאה)|איך (?:להמשיך|ממשיכים|להתקדם)|לאן (?:להתקדם|מכאן)|סדר[י]? לי את ההמשך|מה צריך לעשות')
SPLIT = re.compile(r'\s*[.;!?]+\s*|\s*,\s*|\s+(?:אבל|וגם|ואילו|ואחרי זה|ואחר כך|ומצד שני|ובנוסף)\s+')
NEG_PAST = re.compile(r'\b[וש]?לא (?:כבר )?[א-ת]+תי\b')
CERTAIN = re.compile(r'בוודאות|בטוח[ה]? ש|יודע[ת]? ש|זוכר[ת]? היטב|יכול[ה]? לאשר|באמת|דבר אחד שכן|בפועל')
CORRECTION = re.compile(r'טעיתי|התבלבלתי|תיקון|אמרתי|דיווחתי|הדיווח|הסימון הקודם|מה שרשמתי|תוריד|תקן|צריך לתקן')
VAGUE = re.compile(r'^(?:את )?(?:זה|אותה|אותו|עליה|עליו|בו|בה)\b')
FINAL = str.maketrans('ךםןףץ','כמנפצ')


def stem(w):
    return w.translate(FINAL).replace('י','').replace('ו','')


def describe(action):
    verb, *rest = WORDS.findall(action['source'])
    return verb, forms(' '.join(rest)), action['id']


def anchors(text, actions, previous):
    tokens = WORDS.findall(text)
    roots = forms(text)
    ranks = []
    for verb,obj,key in actions:
        exact = {verb, PAST.get(verb,''), *ALIASES.get(verb,()), NOMINAL.get(verb,'')}
        exact.discard('')
        passive = PASSIVE.get(verb)
        hits = []
        for token in tokens:
            variants = {token, re.sub(r'^[ושלבהמ]','',token),re.sub(r'^[וש]{1,2}(?:כבר)?','',token)}
            if exact & variants or passive and any(re.fullmatch(passive,x) for x in variants):
                hits.append(token)
            elif any(w.endswith('תי') and len(stem(verb[1:]))>=3 and stem(w[:-2])==stem(verb[1:]) for w in variants):
                hits.append(token)
        overlap=len(obj & roots)
        inherited = int(previous is not None and bool(obj & previous[1]))
        ranks.append(((bool(hits),overlap,inherited),key,hits))
    with_verbs = [r for r in ranks if r[0][0]]
    pool = with_verbs or [r for r in ranks if r[0][1]]
    if not pool:return None,[]
    high=max(x[0] for x in pool)
    winners=[r for r in pool if r[0]==high]
    if len(winners)!=1:return None,[]
    _,key,hits=winners[0]
    return key,hits


def classify(text, hits):
    if MENTION.search(text) or PLAN.search(text) and not CERTAIN.search(text):
        return 'skip'
    if DOUBT.search(text) and not re.search(r'אין ספק|בלי ספק',text):
        return 'doubt'
    if PENDING.search(text) and not re.search(r'לא (?:סיימתי|גמרתי)|לא עד הסוף',text):
        return 'pending'
    if NEG_PAST.search(text) and not re.search(r'לא (?:גמרתי|סיימתי|זכרתי)',text):
        return 'pending'
    if PARTIAL.search(text):
        return 'partial'
    if any(re.fullmatch(pattern, token) for token in hits for pattern in PASSIVE.values()):
        return 'done'
    if DONE.search(text) or re.search(r'השתמשתי',text) or any(w.endswith('תי') for w in hits):
        return 'done'
    if any(re.search(r'(?:עבר[וה]?|כבר)\s+'+re.escape(w),text) for w in hits):
        return 'done'
    return None


def nav(text, default):
    if re.search(r'כמה|כמות|מידה|מינון',text) and ('?' in text or QUESTION.search(text)):
        return 'quantity'
    if re.search(r'פספסתי|דילגתי|מלפני|שלבים (?:ה)?קודמים|חסר.*קודם',text):return 'missed'
    if NEXT.search(text):return 'next'
    return default


def interpret(row, raw):
    accepted, route = v52(row,raw)
    if route not in ('raw','future_action_ignored','explicit_named_doubt'):
        return accepted,route
    base=json.loads(accepted)
    req=row['input']
    text=req['utterance'].strip()
    if PRIOR_CONTEXT.search(text):
        return accepted,route
    actions=[describe(a) for a in req['recipe']['actions']]
    by_id={a[2]:a for a in actions}
    if req['history'] and REFER.search(text) and DONE.search(text) and not (DOUBT.search(text) or PENDING.search(text) or PARTIAL.search(text)):
        last=req['history'][-1]
        ids=literal_ids(last['content'],req)
        if last['role']=='assistant' and not UNRESOLVED.search(last['content']) and len(ids)==1 and not literal_ids(text,req) and not anchors(text,actions,None)[1]:
            result={'intent':'report','facts':[{'action':next(iter(ids)),'status':'done'}],'clarify':[]}
            return json.dumps(result,ensure_ascii=False),'history_target'
    # Quoted first-person speech is a mention, including when attribution follows it.
    spoken_quote = re.compile(r'[״"]([^״"]+)[״"]')
    def remove_quotation(match):
        phrase = match[1]
        return ' ציטוט ' if re.search(r'[א-ת]+תי\b',phrase) else phrase
    direct = spoken_quote.sub(remove_quotation, text)
    if '?' in text and re.search(r'מה המידה|כמה |המידה המדויקת',text) and not re.search(r'[א-ת]+תי\b',direct):
        return json.dumps({'intent':'quantity','facts':[],'clarify':[]}), 'quantity_query'
    statements = []
    # Split a coordinating vav directly attached to another known action verb.
    joined = {w for v,_,_ in actions for w in (v,PAST.get(v,'')) if w}
    for part in SPLIT.split(direct):
        statements.extend(re.split(r'\s+ו(?=(?:'+'|'.join(map(re.escape,joined))+r')\b)',part) if joined else [part])
    results={}
    previous=None
    guarded=False
    query=None
    unresolved=False
    for clause in statements:
        clause=clause.strip()
        if not clause: continue
        query_like=QUESTION.search(clause)
        if clause.startswith(('רק תזכיר','תזכירי','תזכיר לי')) and '?' in text and not re.search(r'[א-ת]+תי\b',text):
            return json.dumps({'intent':'explain','facts':[],'clarify':[]}), 'recipe_question'
        if query_like and not re.search(r'^מה ש(?:כן|אני|אמרתי|באמת|ברור|בטוח|קרה|עשיתי)',clause):
            if clause.startswith('האם '):
                mentioned,_=anchors(clause,actions,previous)
                if mentioned:previous=by_id[mentioned]
            query=nav(clause,base['intent'])
            if query in ('report','clarify'):query='explain'
            guarded=True
            continue
        if MENTION.search(clause) or PLAN.search(clause) and not CERTAIN.search(clause):
            guarded=True
            continue
        key,hits=anchors(clause,actions,previous)
        status=classify(clause,hits)
        if not hits and re.search(r'לא הגעתי לסוף|עצרתי לפני הסוף',clause):
            status='partial'
        if not hits and previous and previous[2] in results:
            earlier=results[previous[2]]
            if earlier=='pending' and re.search(r'לא חלק|שום חלק',clause):
                status='pending'
            if earlier=='partial' and re.search(r'הרוב עוד לא|עוד לא הגעתי לסוף',clause):
                status='partial'
        if key is None and previous and status:
            key=previous[2]
        if clause.startswith('התכוונתי ל') and previous:
            # A corrected object retains the original verb and assertion.
            referents=[a for a in actions if a[0]==previous[0] and a[1] & forms(clause)]
            if len(referents)==1 and previous[2] in results:
                results[referents[0][2]]=results.pop(previous[2])
                previous=referents[0]
                continue
        if key and status and status!='skip':
            results[key]=status
        elif not key and status and not CORRECTION.search(clause) and previous is None:
            unresolved=True
        if key:previous=by_id[key]
    if not results and not guarded:
        return accepted,route
    if unresolved and not results:
        return accepted,route
    facts=[{'action':k,'status':s} for k,s in results.items() if s!='doubt']
    doubts=[k for k,s in results.items() if s=='doubt']
    intent=query or (('next' if NEXT.search(text) else 'report') if facts else 'clarify' if doubts else nav(text,base['intent']))
    if not facts and intent=='report':intent='other'
    if intent=='clarify' and not doubts:doubts=[None]
    result={'intent':intent,'facts':facts,'clarify':doubts}
    return json.dumps(result,ensure_ascii=False),'clause_evidence'


def process(payload,raw):
    row=json.loads(payload)
    result,route=interpret(row,raw)
    return json.dumps({**simulate(row,result),'accepted_text':result,'route':route},ensure_ascii=False)
