"""Compare the exact V21 pipeline on native llama.cpp F16 and GGUF quantization."""
import argparse
from contextlib import contextmanager
import json
from pathlib import Path
import socket
from statistics import median
import subprocess
import time
from unittest.mock import patch
import urllib.error
import urllib.request

from fresh_pairs_v15 import digest,measurements,read,write
import preserve_reports_v20 as preservation
from report_scope_v21 import DATA,ROOT,measure as apply_report_scope,verify as verify_v21
import scoped_decode_v17 as decomposition
from sparse_recipe_data_v4 import messages
from sparse_recipe_v3 import score

PLAN=ROOT/'verification/llama-parity-plan-v22-20261119.json'
MANIFEST=ROOT/'verification/llama-parity-freeze-v22-20261119.json'


def verify():
    for name,sha in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name)!=sha:
            raise ValueError('Frozen V22 inputs changed: '+name)


class Native:
    def __init__(self,url,ctx,max_new):
        self.url=url
        self.ctx=ctx
        self.max_new=max_new
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.calls=[]

    def request(self,path,value=None,timeout=90):
        body=None if value is None else json.dumps(value).encode()
        req=urllib.request.Request(self.url+path,data=body,headers={'Content-Type':'application/json'})
        return self.opener.open(req,timeout=timeout)

    def json(self,path,value=None,timeout=90):
        with self.request(path,value,timeout) as r:
            return json.load(r)

    def decode(self,model,tokenizer,rows,plan,deadline):
        outputs=[]
        for row in rows:
            if time.monotonic()>deadline:
                raise TimeoutError('Native candidate exceeded its frozen time limit')
            prompt=tokenizer.apply_chat_template(messages(row),tokenize=False,add_generation_prompt=True,
                                                 enable_thinking=False)
            expected=tokenizer(prompt,add_special_tokens=False)['input_ids']
            actual=self.json('/tokenize',{'content':prompt,'add_special':False,'parse_special':True})['tokens']
            if actual!=expected:
                i=next((i for i,(a,b) in enumerate(zip(actual,expected)) if a!=b),min(len(actual),len(expected)))
                raise ValueError(f'Prompt tokenization mismatch {row["id"]}: at {i}, {len(actual)} vs {len(expected)} tokens')
            if len(actual)+self.max_new>self.ctx:
                raise ValueError('Native context limit exceeded')
            options={'prompt':actual,'n_predict':self.max_new,'temperature':0.0,'top_k':1,'top_p':1.0,
                     'min_p':0.0,'repeat_penalty':1.0,'seed':42,'cache_prompt':False,'stream':True,
                     'stop':['<|im_end|>'],'return_tokens':True}
            segments,tokens=[],[]
            began=time.monotonic()
            first=None
            final={}
            with self.request('/completion',options) as stream:
                for line in stream:
                    if not line.startswith(b'data:'):
                        continue
                    payload=line[5:].strip()
                    if payload==b'[DONE]':
                        break
                    chunk=json.loads(payload)
                    if chunk.get('error'):
                        raise RuntimeError(f'Backend completion failed: {chunk["error"]}')
                    text=chunk.get('content','')
                    if text:
                        if first is None:
                            first=time.monotonic()-began
                        segments.append(text)
                    tokens.extend(chunk.get('tokens',[]))
                    if chunk.get('stop'):
                        final=chunk
            if not final:
                raise RuntimeError('Backend stream ended without a completion record')
            elapsed=time.monotonic()-began
            self.calls.append({'id':row['id'],'prompt_tokens':len(actual),'tokens_verified':True,'seconds':elapsed,
                               'first_visible_text_seconds':first,'backend_timings':final.get('timings',{})})
            outputs.append({'id':row['id'],'text':''.join(segments),'tokens':tokens})
        print(f'Native {len(rows)} calls complete',flush=True)
        return outputs


def peak_rss(pid):
    status=Path(f'/proc/{pid}/status').read_text()
    mark=next((line for line in status.splitlines() if line.startswith('VmHWM:')),None)
    return int(mark.split()[1])*1024 if mark else None


@contextmanager
def launch(binary,model,log,plan):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0))
        port=sock.getsockname()[1]
    began=time.monotonic()
    with log.open('x') as stderr:
        process=subprocess.Popen([str(binary),'-m',str(model),'--host','127.0.0.1','--port',str(port),
                                 '-c',str(plan['context']),'-t',str(plan['threads']),'-tb',str(plan['threads']),
                                 '--parallel','1','-ngl','0','--no-webui'],stdin=subprocess.DEVNULL,
                                 stdout=stderr,stderr=subprocess.STDOUT,start_new_session=True)
        native=Native(f'http://127.0.0.1:{port}',plan['context'],plan['max_new_tokens'])
        try:
            deadline=time.monotonic()+90
            while time.monotonic()<deadline:
                if process.poll() is not None:
                    raise RuntimeError(f'llama-server stopped before readiness; see {log}')
                try:
                    if native.json('/health',timeout=1).get('status')=='ok':
                        break
                except (OSError,urllib.error.URLError,TimeoutError):
                    pass
                time.sleep(.5)
            else:
                raise TimeoutError('Local native runtime did not become ready')
            yield native,process.pid,time.monotonic()-began
        finally:
            process.terminate()
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def compare(rows,prior,current,cfg):
    if not ([r['id'] for r in rows]==[r['id'] for r in prior]==[r['id'] for r in current]):
        raise ValueError('Comparison output IDs differ')
    a,b=measurements(rows,prior),measurements(rows,current)
    aa,bb=a['overall'],b['overall']
    new_false=[row['id'] for row,x,y in zip(rows,prior,current,strict=True)
               if row['critical_no_facts'] and not score(row,x['text'])['wrong_facts'] and score(row,y['text'])['wrong_facts']]
    checks={'exact_retained':bb['exact']>=aa['exact']-cfg['max_exact_loss'],
            'valid_retained':bb['valid']>=aa['valid']-cfg['max_exact_loss'],
            'no_new_false_no_report':not new_false}
    return {'reference':a,'candidate':b,'new_false_no_report':new_false,
            'same_raw_text':sum(x['text']==y['text'] for x,y in zip(prior,current,strict=True)),
            'checks':checks,'passes':all(checks.values())}


def run(assets,bin_dir,baseline,output):
    from transformers import AutoTokenizer

    verify()
    verify_v21()
    plan=read(PLAN)
    tokenizer_base=ROOT/plan['tokenizer_base']
    decoder=read(ROOT/'verification/fresh-pairs-plan-v15-20261118.json')
    for filename in ('tokenizer.json','tokenizer_config.json'):
        if digest(tokenizer_base/filename)!=decoder['model_sha256'][filename]:
            raise ValueError('Shared decoder tokenizer integrity mismatch')
    tokenizer=AutoTokenizer.from_pretrained(tokenizer_base,local_files_only=True,trust_remote_code=False)
    output.mkdir(parents=True,exist_ok=False)
    binary=(bin_dir/'llama-server').resolve()
    version=subprocess.check_output([str(binary),'--version'],stderr=subprocess.STDOUT,text=True)
    if plan['llama_commit'][:9] not in version:
        raise ValueError('Incorrect llama.cpp build')
    rows=read(DATA)
    prior=read(baseline/'raw.json')['fresh']
    manifest=read(assets/'gguf.json')
    if manifest!=read(ROOT/plan['export_manifest'])['models']:
        raise ValueError('Export file hashes differ from the V22 freeze')
    outputs={}
    results={}
    for name,filename in plan['formats'].items():
        gguf=(assets/filename).resolve()
        expected=manifest[filename]
        if gguf.stat().st_size!=expected['bytes'] or digest(gguf)!=expected['sha256']:
            raise ValueError('GGUF file mismatch')
        leaf=output/name
        leaf.mkdir()
        print(f'Running native {name}',flush=True)
        with launch(binary,gguf,leaf/'runtime.log',plan) as (native,pid,load_seconds):
            with patch.object(preservation,'model_for',lambda *args,**kwargs:(native,tokenizer)), \
                 patch.object(preservation,'decode',native.decode), \
                 patch.object(decomposition,'decode',native.decode):
                pre,work=preservation.new_inputs(rows,tokenizer_base,leaf,read(ROOT/'verification/report-scope-plan-v21-20261119.json'))
            _,v20=preservation.measure(rows,pre,True)
            metrics,final=apply_report_scope(rows,v20,True)
            visible=[c['first_visible_text_seconds'] for c in native.calls if c['first_visible_text_seconds'] is not None]
            results[name]={'format':expected,'load_seconds':load_seconds,'peak_process_rss_bytes':peak_rss(pid),
                           'median_first_visible_text_seconds':median(visible) if visible else None,
                           'total_generation_seconds':sum(c['seconds'] for c in native.calls),
                           'generated_calls':len(native.calls),'matched_prompt_token_ids':len(native.calls),
                           'pipeline_metrics':metrics['v21'],'work':work}
            write(leaf/'calls.json',native.calls)
            write(leaf/'final.json',final)
            outputs[name]=final
    f16=compare(rows,prior,outputs['f16'],plan)
    q4=compare(rows,outputs['f16'],outputs['q4_k_m'],plan)
    below_budget=results['q4_k_m']['format']['bytes']<=plan['max_download_bytes']
    write(output/'study.json',{'study':plan['study'],'runtime':version.strip(),'binaries':results,
                               'transformers_bf16_to_native_f16':f16,'native_f16_to_q4':q4,
                               'within_download_budget':below_budget,
                               'native_quantization_gate':f16['passes'] and q4['passes'] and below_budget})


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('artifacts',type=Path)
    parser.add_argument('bin_dir',type=Path)
    parser.add_argument('v21_run',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    run(args.artifacts,args.bin_dir,args.v21_run,args.output)
