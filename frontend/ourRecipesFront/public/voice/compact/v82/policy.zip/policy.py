"""Expose the frozen V52 prompt and state simulation to the browser Worker."""
import json

from sparse_recipe_data_v4 import messages
from scoped_turn_claims_v52 import interpret
from recipe_text_responder_v52 import simulate


def prompt(row):
    system, user = messages(row)
    return (f'<|im_start|>system\n{system["content"].rstrip()}<|im_end|>\n'
            f'<|im_start|>user\n{user["content"]}<|im_end|>\n<|im_start|>assistant\n')


def process(payload, raw):
    row = json.loads(payload)
    accepted, route = interpret(row, raw)
    result = simulate(row, accepted)
    return json.dumps({**result, 'proposal_text':raw, 'accepted_text':accepted, 'route':route},
                      ensure_ascii=False)


def render_prompt(payload):
    return prompt(json.loads(payload))


def quick(payload):
    from fast_path import run

    outcome = run(json.loads(payload))
    if outcome is None:
        return 'null'
    result, accepted, route = outcome
    return json.dumps({**result, 'proposal_text':None, 'accepted_text':accepted, 'route':route},
                      ensure_ascii=False)
