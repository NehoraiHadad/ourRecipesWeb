"""Score raw Q4, V21, and V27 on the same broad-text inference run."""
import argparse
from collections import defaultdict
from pathlib import Path

from broad_text_data_v28 import DATA, ROOT, build
from fresh_pairs_v15 import digest, measurements, read, write
from grounded_progress_study_v25 import generate_q4
from grounded_recipe_source_study_v27 import verify as verify_prior
from grounded_recipe_source_v27 import apply
from sparse_recipe_v3 import aggregate, score

FREEZE = ROOT / 'verification/broad-text-freeze-v28-20261119.json'
ARMS = ('raw_q4', 'v21', 'v27')


def verify():
    verify_prior()
    for name, sha in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != sha:
            raise ValueError(f'Changed V28 input: {name}')
    if read(DATA) != build():
        raise ValueError('V28 data differs from its authored specification')


def compare(rows, full, baseline):
    ids = [row['id'] for row in rows]
    if ids != [record['id'] for record in full] or ids != [record['id'] for record in baseline]:
        raise ValueError('Response and request identity mismatch')
    output = []
    for row, raw, earlier in zip(rows, full, baseline, strict=True):
        text, grounded = apply(row, earlier['text'])
        output.append({'id': row['id'], 'raw_q4': raw['text'], 'v21': earlier['text'],
                       'v27': text, 'grounded_path': grounded})
    return summarize(rows, output), output


def summarize(rows, output):
    if [row['id'] for row in rows] != [record['id'] for record in output]:
        raise ValueError('Summary output identity mismatch')
    metrics = {}
    for arm in ARMS:
        values = [r[arm] for r in output]
        results = measurements(rows, [{'id': r['id'], 'text': r[arm]} for r in output])
        grouped = defaultdict(list)
        for row, value in zip(rows, values, strict=True):
            grouped[row['expected']['intent']].append((row, value))
        results['by_expected_intent'] = {}
        for intent, examples in sorted(grouped.items()):
            subset, texts = zip(*examples, strict=True)
            results['by_expected_intent'][intent] = aggregate(subset, texts)[0]
        metrics[arm] = results
    differences = {'fixed_exact': [], 'broke_exact': [], 'new_wrong_fact': [],
                   'new_wrong_state': []}
    for row, case in zip(rows, output, strict=True):
        before, after = (score(row, case[arm]) for arm in ('v21', 'v27'))
        if after['exact'] and not before['exact']:
            differences['fixed_exact'].append(row['id'])
        if before['exact'] and not after['exact']:
            differences['broke_exact'].append(row['id'])
        for metric, target in (('wrong_facts', 'new_wrong_fact'), ('wrong_state', 'new_wrong_state')):
            if any(item not in before[metric] for item in after[metric]):
                differences[target].append(row['id'])
    return {'arms': metrics, 'v21_to_v27': differences,
            'grounded_path_cases': sum(record['grounded_path'] for record in output)}


def run(assets, bin_dir, output):
    verify()
    output.mkdir(parents=True, exist_ok=False)
    rows = read(DATA)
    assembled, runtime = generate_q4(rows, assets, bin_dir, output)
    results, predictions = compare(rows, read(output / 'full-turn.json'), assembled)
    write(output / 'raw.json', predictions)
    write(output / 'study.json', {**runtime, **results})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.output)
