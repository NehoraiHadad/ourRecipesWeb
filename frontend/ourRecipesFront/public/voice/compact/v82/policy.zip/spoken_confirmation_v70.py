"""Treat a spoken confirmation prompt as a question and preserve coordinated reports."""
import json
import re

from conversational_scope_v69 import process as previous, resolve
from colloquial_evidence_v60 import decision
from turn_evidence_v58 import PRIOR_CONTEXT, simulate

# A pause before an explicit conjunction does not end the previous event's subject.
PAUSED_CHAIN = re.compile(r'\s*,\s*(?=(?:ואז|ואחר כך|ואחרי זה|ולאחר מכן|ורק אחר כך)\s)')
PROMPT = re.compile(
    r'^(?:(?:בוא|בואי|בואו) (?:נוודא|נברר|נבדוק)(?: רגע)?|'
    r'רק (?:רציתי )?(?:לוודא|לברר|לשאול)|רק שאלה|שאלה קטנה)(?:\s*[:,–]\s*|\s+)')
LOOKUP = re.compile(r'^(?:כמה|למה|איך|מתי|איפה|מה|היכן|צריך|כדאי)\b')


def process(payload, raw):
    row = json.loads(payload)
    req = row['input']
    original = req['utterance'].strip()
    opener = PROMPT.match(original)
    if opener and not PRIOR_CONTEXT.search(original):
        body = original[opener.end():].strip().rstrip('?!').strip()
        if body and not LOOKUP.match(body) and not re.search(r'[.!?;,״"“”]', body):
            question = resolve(row, body + '?')
            if question and question['clarify'] and not question['facts']:
                targets = question['clarify']
            else:
                statement = resolve(row, body)
                targets = [f['action'] for f in statement['facts']] if statement else []
            accepted = json.dumps(decision(doubts=targets or [None]), ensure_ascii=False)
            return json.dumps({**simulate(row, accepted), 'accepted_text': accepted,
                               'route': 'spoken_confirmation'}, ensure_ascii=False)
    normalized = PAUSED_CHAIN.sub(' ', original)
    if normalized != original:
        payload = json.dumps({**row, 'input': {**req, 'utterance': normalized}}, ensure_ascii=False)
    return previous(payload, raw)
