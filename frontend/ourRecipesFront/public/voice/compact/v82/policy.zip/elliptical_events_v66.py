"""Recover omitted arguments only from an adjacent, established recipe action."""
import json
import re

from coordinated_claims_v62 import MOVES, PLACE, action_slots
from confirmed_events_v65 import EVIDENCE, NEUTRAL, interpret as previous
from destination_evidence_v61 import SOURCE_VERB, VESSEL, ingredient
from turn_evidence_v58 import DOUBT, MENTION, PAST, PRIOR_CONTEXT, simulate
from colloquial_evidence_v60 import decision, pack

# Some first-person plural forms fuse the stem's final nun with the suffix.
PLURAL={form[:-3]+'נו':form for form in PAST.values() if form.endswith('נתי')}
PLURAL_WORD=re.compile(r'(?<![א-ת])(ו?)('+'|'.join(map(re.escape,PLURAL))+r')(?![א-ת])')
VERBS=set(PAST.values())|MOVES
EMPHASIS=re.compile(r'(^|[.,;]\s*| אבל )רק ([א-ת]+)\b')
LOCATION_ONLY=re.compile(r'((?:\s+ואחר כך|\s+ואז|\s+ולאחר מכן)\s+)(ל[^,.!?;]+)(?=[.?!;]|$)')
REJECT_VESSEL=re.compile(r'^(?:ה?'+VESSEL+r')\?\s*(?:עוד |עדיין )?לא[.!]\s*(.+)$')
POSTPOSED_OBJECT=re.compile(r'^(?:הוא|היא|הם|הן|זה) (?:כבר )?(.+?)\?\s*(?:אני )?(?:מתכוונ[ת]?|התכוונתי) ל(.+?)[.!]?$')


def interpret(row,raw):
    req=row['input']
    text=req['utterance'].strip()
    actions=req['recipe']['actions']
    if not text or PRIOR_CONTEXT.search(text) or MENTION.search(text) or any(c in text for c in '"״“”'):
        return previous(row,raw)
    explicit=POSTPOSED_OBJECT.fullmatch(text)
    dismissed=REJECT_VESSEL.fullmatch(text)
    if explicit and PLACE.fullmatch(explicit[1]):
        obj=ingredient(explicit[2])
        if any(a.obj==obj for a in action_slots(actions)):
            text=explicit[2]+' '+explicit[1]+'?'
    elif dismissed:
        # The answer to a bare vessel name says nothing about earlier transfers.
        # Require independent grounding of the actual statement that follows.
        own={**row,'input':{**req,'utterance':dismissed[1]}}
        val,route=previous(own,NEUTRAL)
        if route in EVIDENCE and json.loads(val)['facts']:
            return val,route
        # "עוד בקערה" and "עדיין בקערה" are positive location reports.
        main=re.sub(r' (?:עוד|עדיין) (?=ב)',' ',dismissed[1])
        own['input']['utterance']=main
        val,route=previous(own,NEUTRAL)
        if route in EVIDENCE and json.loads(val)['facts']:
            return val,route
    text=EMPHASIS.sub(lambda m:m[1]+m[2] if m[2] in VERBS else m[0],text)
    text=PLURAL_WORD.sub(lambda m:m[1]+PLURAL[m[2]],text)
    # A second bare destination can inherit an explicitly asserted transfer
    # within the same sentence, including the object resolved in the previous sentence.
    connector=LOCATION_ONLY.search(text)
    if connector and PLACE.fullmatch(connector[2]) and not DOUBT.search(text):
        prefix=text[:connector.start()]
        lead={**row,'input':{**req,'utterance':prefix}}
        val,route=previous(lead,NEUTRAL)
        facts=json.loads(val)['facts']
        if route in EVIDENCE and facts and facts[-1]['status']=='done':
            slots=action_slots(actions)
            source=next((a for a in slots if a.key==facts[-1]['action']),None)
            if source and source.verb in SOURCE_VERB:
                text=prefix+connector[1]+'העברתי את '+' '.join(source.obj)+' '+text[connector.start(2):]
    local={**row,'input':{**req,'utterance':text}}
    return previous(local,raw)


def process(payload,raw):
    row=json.loads(payload)
    outside=raw=='null'
    accepted,route=interpret(row,NEUTRAL if outside else raw)
    if outside and route not in EVIDENCE:
        accepted,route=pack(decision(doubts=[None]),'context_clarification')
    result=simulate(row,accepted)
    if route=='context_clarification':
        result['reply']='כדי לדייק בעדכון המתכון, אפשר לכתוב במשפט קצר מה בוצע ובאיזה מרכיב?'
    return json.dumps({**result,'route':route,'accepted_text':accepted},ensure_ascii=False)
