"""Measure the frozen V13 adapters on the new synthetic pairs via local CPU."""
import argparse
from collections import defaultdict
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import time
import zipfile

from fresh_pairs_data_v15 import DATA, ROOT, audit, build
from semantic_supervision_data_v12 import read_native
from sparse_recipe_data_v4 import messages
from sparse_recipe_v3 import aggregate, facts, parse

PLAN = ROOT / 'verification/fresh-pairs-plan-v15-20261118.json'
MANIFEST = ROOT / 'verification/fresh-pairs-freeze-v15-20261118.json'
ARMS = ('primary_only','fact_contrast')


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    temp = path.with_suffix('.partial')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
    temp.replace(path)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def verify():
    for name, checksum in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name) != checksum:
            raise ValueError(f'Changed V15 frozen input: {name}')
    rows = read(DATA)
    if rows != build():
        raise ValueError('Fresh data no longer matches the authored specification')
    return rows, audit(rows), read(PLAN)


def restore(output, plan):
    source = plan['archive']
    path = ROOT / source['path']
    if path.stat().st_size != source['bytes'] or digest(path) != source['sha256']:
        raise ValueError('V13 archive does not match audited provenance')
    checkpoints = {}
    history = {}
    with zipfile.ZipFile(path) as archive:
        inventory = json.loads(archive.read('MANIFEST.json'))
        for arm in ARMS:
            folder = output / f'adapter-{arm}'
            folder.mkdir()
            for filename in ('adapter_config.json','adapter_model.safetensors'):
                entry = f'study/{arm}/checkpoint-160/{filename}'
                raw = archive.read(entry)
                checksum = hashlib.sha256(raw).hexdigest()
                if len(raw) != inventory[entry]['bytes'] or checksum != inventory[entry]['sha256']:
                    raise ValueError('Adapter differs from archive member SHA')
                if filename.endswith('.safetensors') and checksum != source['adapter_sha256'][arm]:
                    raise ValueError('Adapter differs from audited V13 weights')
                (folder / filename).write_bytes(raw)
            checkpoints[arm] = folder
            record = json.loads(archive.read(f'study/{arm}/validation-step-160.json'))['records']
            history[arm] = [record[i] for i in plan['known_replay_indices']]
    return checkpoints, history


def decode(model, tokenizer, rows, plan, deadline):
    import torch

    records = []
    for start in range(0, len(rows), plan['batch_size']):
        if time.monotonic() > deadline:
            raise TimeoutError('V15 CPU benchmark exceeded the frozen time budget')
        group = rows[start:start+plan['batch_size']]
        text = [tokenizer.apply_chat_template(messages(r), tokenize=False, add_generation_prompt=True,
                                              enable_thinking=False) for r in group]
        data = tokenizer(text, return_tensors='pt', padding=True, add_special_tokens=False)
        prefix = data['input_ids'].shape[1]
        if prefix + plan['max_new_tokens'] > plan['context_limit']:
            raise ValueError('Context exceeds frozen generation budget')
        with torch.inference_mode():
            generated = model.generate(**data, max_new_tokens=plan['max_new_tokens'], do_sample=False,
                                       pad_token_id=tokenizer.pad_token_id,eos_token_id=tokenizer.eos_token_id,
                                       temperature=None, top_p=None, top_k=None)
        for row, tokens in zip(group, generated[:,prefix:].tolist(), strict=True):
            end = tokens.index(tokenizer.eos_token_id)+1 if tokenizer.eos_token_id in tokens else len(tokens)
            tokens = tokens[:end]
            raw = tokenizer.decode(tokens, skip_special_tokens=True)
            records.append({'id':row['id'], 'tokens':tokens, 'text':raw})
        print(f'  {len(records)}/{len(rows)}',flush=True)
    return records


def normalized(text, request):
    try:
        answer = parse(text,request)
    except (ValueError, TypeError, KeyError):
        return None
    targets = sorted('GLOBAL' if x is None else x for x in answer['clarify'])
    return answer['intent'], facts(answer), targets


def measurements(rows, outputs):
    if [x['id'] for x in outputs] != [r['id'] for r in rows]:
        raise ValueError('Response ordering differs from frozen requests')
    metric, detail = aggregate(rows,[r['text'] for r in outputs])
    pairs = defaultdict(list)
    for r, result, raw in zip(rows,detail,outputs,strict=True):
        pairs[r['pair']].append((r['family'],result,normalized(raw['text'],r['input'])))
    family = defaultdict(lambda: {'rows':0,'pairs':0,'exact':0,'facts_exact':0,'both_exact':0,'same_valid_answer':0,
                                  'wrong_fact_without_report':0,'no_report_cases':0})
    for left,right in pairs.values():
        fn = family[left[0]]
        fn['pairs']+=1
        fn['rows']+=2
        fn['exact']+=sum(c[1]['exact'] for c in [left,right])
        fn['facts_exact']+=sum(c[1]['facts_exact'] for c in [left,right])
        fn['both_exact']+=left[1]['exact'] and right[1]['exact']
        fn['same_valid_answer']+=left[2] is not None and left[2]==right[2]
    for row, result in zip(rows,detail,strict=True):
        if row['critical_no_facts']:
            fn = family[row['family']]
            fn['no_report_cases']+=1
            fn['wrong_fact_without_report']+=bool(result['wrong_facts'])
    return {'overall':metric,'families':dict(family),
            'both_exact_pairs':sum(v['both_exact'] for v in family.values()),
            'same_valid_answer_pairs':sum(v['same_valid_answer'] for v in family.values())}


def run(model_dir, output):
    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    rows, diagnostics, plan = verify()
    if torch.__version__ != '2.6.0+cpu':
        raise RuntimeError('V15 requires the frozen CPU PyTorch build')
    for dep, expected in plan['versions'].items():
        if version(dep)!=expected:
            raise RuntimeError(f'Unexpected library version: {dep}')
    for name, checksum in plan['model_sha256'].items():
        if digest(model_dir/name)!=checksum:
            raise ValueError(f'Unexpected local public model file: {name}')
    torch.set_num_threads(plan['threads'])
    torch.set_num_interop_threads(1)
    output.mkdir(parents=True, exist_ok=False)
    checkpoints, prior = restore(output,plan)
    tokenizer=AutoTokenizer.from_pretrained(model_dir,local_files_only=True,trust_remote_code=False)
    tokenizer.pad_token = tokenizer.pad_token or tokenizer.eos_token
    tokenizer.padding_side='left'
    base=AutoModelForCausalLM.from_pretrained(model_dir,local_files_only=True,trust_remote_code=False,
                                             dtype=torch.bfloat16,attn_implementation='sdpa').eval()
    model = PeftModel.from_pretrained(base, checkpoints[ARMS[0]], adapter_name=ARMS[0], is_trainable=False)
    model.load_adapter(checkpoints[ARMS[1]], adapter_name=ARMS[1], is_trainable=False)
    same = read_native()['validation']
    known = [same[i] for i in plan['known_replay_indices']]
    elapsed = time.monotonic()
    deadline = elapsed + plan['cpu_budget_seconds']
    report = {'study':plan['study'],'scope':plan['scope'],'dataset':diagnostics,'backend':{
        'device':'CPU','body_dtype':'bfloat16','torch':torch.__version__,'cpu_threads':plan['threads']},'arms':{}}
    for arm in ARMS:
        model.set_adapter(arm)
        model.eval()
        print(f'{arm}: CPU provenance replay',flush=True)
        seen=decode(model,tokenizer,known,plan,deadline)
        remembered=prior[arm]
        if [r['id'] for r in seen]!=[r['id'] for r in remembered]:
            raise ValueError('Known replay ordering differs from V13')
        parity={'rows':len(seen),'same_raw_text':sum(a['text']==b['text'] for a,b in zip(seen,remembered,strict=True)),
                'same_valid_answer':sum(
                    normalized(a['text'],row['input']) is not None
                    and normalized(a['text'],row['input'])==normalized(b['text'],row['input'])
                    for a,b,row in zip(seen,remembered,known,strict=True))}
        write(output/f'{arm}-known.json',seen)
        print(f'{arm}: fresh pairs',flush=True)
        raw=decode(model,tokenizer,rows,plan,deadline)
        raw_path=output/f'{arm}-fresh.json'
        write(raw_path,raw)
        report['arms'][arm]={'known_cpu_vs_v13_gpu':parity,
                             'fresh':measurements(rows,raw),'raw_output_sha256':digest(raw_path)}
        write(output/'progress.json',report)
    report['seconds']=time.monotonic()-elapsed
    write(output/'report.json',report)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('model_dir',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    run(args.model_dir,args.output)
