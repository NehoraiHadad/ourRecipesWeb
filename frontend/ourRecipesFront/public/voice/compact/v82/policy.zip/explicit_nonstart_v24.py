"""Lock a reported status to pending only when the complete sentence is an explicit non-start."""
import re

from scoped_decode_v17 import compact, safe_parse

PAST = {
    'לאפות': 'אפיתי', 'לבשל': 'בישלתי', 'להוסיף': 'הוספתי',
    'לטגן': 'טיגנתי', 'לטחון': 'טחנתי', 'לחתוך': 'חתכתי',
    'למדוד': 'מדדתי', 'לסחוט': 'סחטתי', 'לערבב': 'ערבבתי',
    'לפרוס': 'פרסתי', 'לקלף': 'קילפתי', 'לקצוץ': 'קצצתי',
    'לשטוף': 'שטפתי', 'לשקול': 'שקלתי',
}
TIME = r'(?:עד (?:עכשיו|כה|היום|לרגע זה|לרגע הזה|הרגע הזה)|עוד|עדיין)'
NEGATIVE = rf'(?:(?:{TIME} )?(?:בכלל )?לא|טרם) '
ENDING = rf'(?: {TIME}| בכלל| למתכון)?'
WORD = re.compile(r"[א-ת]+(?:[׳'][א-ת]+)?")


def action_pattern(source):
    verb, _, objects_in_source = source.partition(" ")
    if verb not in PAST:
        return None
    nouns = [word for word in objects_in_source.split() if word != 'את']
    if not nouns or not all(WORD.fullmatch(word) for word in nouns):
        return None
    # Match the object as a sequence, optionally with Hebrew definite articles.
    objects = ' '.join(f'ה?{re.escape(part.removeprefix("ה"))}' if len(part) >= 4 else re.escape(part)
                       for part in nouns)
    predicate = rf'(?:{PAST[verb]}|התחלתי {verb})'
    return (
        rf'(?:אני )?{NEGATIVE}{predicate}(?: בכלל)? (?:את )?{objects}{ENDING}'
        rf'|(?:את )?{objects} (?:אני )?{NEGATIVE}{predicate}{ENDING}'
    )


def apply(row, raw):
    parsed = safe_parse(raw, row)
    if not parsed or parsed['intent'] != 'report' or parsed['clarify'] or len(parsed['facts']) != 1:
        return raw, False
    claim = ' '.join(row['input']['utterance'].strip().removesuffix('.').split())
    matches = []
    for action in row['input']['recipe']['actions']:
        pattern = action_pattern(action['source'])
        if pattern and re.fullmatch(pattern, claim):
            matches.append(action['id'])
    fact = parsed['facts'][0]
    if matches != [fact['action']] or fact['status'] == 'pending':
        return raw, False
    fixed = {'action': fact['action'], 'status': 'pending'}
    return compact({**parsed, 'facts': [fixed]}, row), True
