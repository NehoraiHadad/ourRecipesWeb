"""Fresh non-report/report contrasts for the V29 prompt-only experiment."""
from pathlib import Path
import random

from broad_text_data_v28 import DATA as V28
from explicit_nonstart_data_v24 import DATA as V24
from fresh_pairs_data_v15 import DATA as V15, canonical
from fresh_pairs_v15 import read, write
from grounded_followup_data_v26 import DATA as V26
from grounded_progress_data_v25 import DATA as V25
from grounded_recipe_source_data_v27 import DATA as V27
from grounded_scope_data_v18 import DATA as V18
from preserve_reports_data_v20 import DATA as V20
from report_scope_data_v21 import DATA as V21
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/report-prompt-data-v29-20261119.json'

RECIPES = (
    ('לחמניות קוטג׳ ועירית', ('ללוש את הבצק.', 'לקצוץ עירית.', 'להבריש את הלחמניות.', 'לאפות את הלחמניות.'),
     ('כשאסיים פה אלוש את הבצק. איך להתקדם כרגע?', 'הבצק כבר לוש. איך להתקדם כרגע?'),
     ('״קצצתי עירית״ זה משפט לדוגמה בלבד. מה הצעד הבא?', 'אפשר לעדכן שקצצתי עירית. מה הצעד הבא?'),
     ('אילו כבר הייתי מברישה את הלחמניות, מה היה מגיע אחר כך?', 'כבר הברשתי את הלחמניות, מה מגיע אחר כך?'),
     ('לא סגורה אם הכנסתי את הלחמניות לאפייה בכלל.', 'בטוחה שעוד לא הכנסתי את הלחמניות לאפייה בכלל.')),
    ('סלט סלק קלוי וגרעיני דלעת', ('לקלף סלק.', 'לקלות גרעיני דלעת.', 'לפרוס את הסלק.', 'לערבב את הסלט.'),
     ('בתכנון שלי לקלף את הסלק בעוד רגע. מה השלב הנוכחי?', 'אפשר לדעת מה השלב הנוכחי? קילפתי כבר את הסלק.'),
     ('אני מקריא בקול את המשפט ״קליתי את הגרעינים״ מתוך הדוגמה. מה עושים בינתיים?',
      'הגרעינים כבר נקלו אצלי. מה עושים עכשיו?'),
     ('בדמיון הסלק כבר פרוס. איך הייתי ממשיך משם?', 'הסלק כבר פרוס אצלי. איך ממשיכים משם?'),
     ('אני מתלבט אם כבר ערבבתי את הסלט או רק חשבתי על זה.', 'בדקתי, ויש אישור שהסלט עורבב אצלי.')),
    ('מרק קוקוס ותירס מתוק', ('להרתיח מי קוקוס.', 'לשטוף גרגירי תירס.', 'לסנן את המרק.', 'לתבל את המרק.'),
     ('אחרי מה שתענה ארתיח את מי הקוקוס. מה עליי לעשות עכשיו?', 'מי הקוקוס כבר רתחו. מה עליי לעשות עכשיו?'),
     ('המשפט "שטפתי את התירס" מופיע בדוגמה. איך ממשיכים במתכון?',
      'שטפתי בפועל את התירס, איך ממשיכים במתכון?'),
     ('אם הייתי מסננת את המרק כבר, מה היה השלב שלאחר הסינון?',
      'סיננתי את המרק כבר, מהו השלב שלאחר הסינון?'),
     ('יכול להיות שהתחלתי לתבל, הזיכרון שלי מעורפל.', 'תיבלתי את המרק רק קצת, אני צריכה עוד להמשיך.')),
    ('מאפה מנגולד וגבינת עיזים', ('לשטוף את המנגולד.', 'לפורר גבינת עיזים.', 'למלא את הבצק.', 'לקרר את המאפה.'),
     ('הכוונה שלי היא לשטוף את המנגולד רק בהמשך. איך נמשיך בינתיים?',
      'לגבי המנגולד, את השטיפה כבר עשיתי. איך ממשיכים מכאן?'),
     ('כתוב פה "פוררתי את הגבינה" כחלק מדוגמה בלבד. מה עושים הלאה?',
      'פוררתי את הגבינה בפועל והיא מוכנה. מה עושים הלאה?'),
     ('בהנחה שהבצק היה כבר ממולא, מה הייתי אמורה לעשות אחר כך?',
      'אצלי הבצק כבר ממולא. מה אני אמורה לעשות אחר כך?'),
     ('אולי הקירור כבר היה, אני לא מצליחה להיזכר.', 'המאפה עדיין מחכה לקירור, אפילו לא התחלתי לקרר אותו.')),
    ('קציצות קינואה ובטטה סגולה', ('לבשל קינואה.', 'למעוך את הבטטה.', 'לטגן את הקציצות.', 'לכסות את המחבת.'),
     ('כשאגמור להכין את השאר אבשל קינואה. מה צריך לעשות לפני כן?',
      'את הקינואה כבר בישלתי. מה צריך לעשות עכשיו?'),
     ('מישהו אמר "מעכתי את הבטטה"; אני רק מצטט אותו. מה הצעד הנוכחי?',
      'אני עצמי מעכתי את הבטטה. מה הצעד הנוכחי?'),
     ('נניח לשם דוגמה שכבר טיגנתי את הקציצות. מה היה בא אחר כך?',
      'טיגנתי עד הסוף את הקציצות. מה בא אחר כך?'),
     ('אין לי דרך לאשר שכיסיתי את המחבת, אני לא זוכרת.', 'אני מאשרת שכיסיתי את המחבת והכיסוי במקום.')),
    ('פאי אגסים וג׳ינג׳ר', ('לפרוס את האגסים.', 'לגרר ג׳ינג׳ר.', 'למזוג את המילוי.', 'לאפות את הפאי.'),
     ('בעוד מעט אני אפרוס את האגסים. מה בא לפני הפעולה הזאת עכשיו?',
      'פרסתי את האגסים כבר. מה בא אחרי הפעולה הזאת עכשיו?'),
     ('״גיררתי ג׳ינג׳ר״ זה רק ציטוט מספר הבישול. לאן להמשיך?',
      'את הג׳ינג׳ר גיררתי עד הסוף, לאן להמשיך?'),
     ('במקרה דמיוני שכבר מזגתי את המילוי, מה אמור היה להיות הצעד הבא?',
      'המילוי כבר נמזג בפועל. מה אמור להיות הצעד הבא?'),
     ('מצטער, אני לא זוכר אם הפאי בכלל התחיל להיאפות.', 'הפאי נכנס לאפייה והיא עדיין בעיצומה.')),
)


def build():
    rows = []
    rng = random.Random(291119)
    final_status = ('pending', 'done', 'partial', 'pending', 'done', 'partial')
    for i, (name, sources, future, quote, scenario, doubt) in enumerate(RECIPES):
        (a, b, c, d), context = fixture(rng, name, sources, i, 'fresh-v29')
        context['progress'].update({a: 'pending', b: 'pending', c: 'partial',
                                    d: 'done' if final_status[i] != 'done' else 'partial'})
        pair(rows, context, 'future_0', future, [response('next'), response('next', [(a, 'done')])])
        pair(rows, context, 'quote_0', quote, [response('next'), response('next', [(b, 'done')])])
        pair(rows, context, 'scenario_0', scenario, [response('explain'), response('next', [(c, 'done')])])
        pair(rows, context, 'doubt_0', doubt,
             [response('clarify', clarify=[d]), response('report', [(d, final_status[i])])])
    audit_new(rows, 48)
    prior = [r for split in read_native().values() for r in split] + train_new()
    for path in (V15, V16, V18, V20, V21, V24, V25, V26, V27, V28):
        prior.extend(read(path))
    names = {r['input']['recipe']['name'] for r in prior}
    utterances = {canonical(r['input']['utterance']) for r in prior}
    if any(r['input']['recipe']['name'] in names or canonical(r['input']['utterance']) in utterances for r in rows):
        raise ValueError('V29 overlaps earlier recipe names or exact utterances')
    return rows


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
