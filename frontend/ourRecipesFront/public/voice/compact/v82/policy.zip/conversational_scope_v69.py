"""Distinguish a cook's current assertion from a near miss, a question or a retraction."""
import json
import re

from coordinated_claims_v62 import PLACE, action_slots
from named_recipe_question_v68 import process as previous_process
from portion_scope_v67 import EVIDENCE, NEUTRAL, interpret
from turn_evidence_v58 import DOUBT, PAST, PRIOR_CONTEXT, simulate
from colloquial_evidence_v60 import decision

GROUNDED = EVIDENCE | {'portion_scope'}
CHECK = re.compile(r'^(?:רק (?:רציתי )?(?:לוודא|לברר|לשאול)|רק שאלה|שאלה קטנה)[, :]+')
UNASSERTED = re.compile(
    r'^(?:אל (?:תסמ(?:ן|ני)|תרש(?:ום|מי)|תעדכ(?:ן|ני)) (?:לי )?ש|'
    r'לא אמרתי ש|חשבתי ש(?:כבר )?|(?:היא|הוא) ביקש(?:ה)? ש|'
    r'עוד (?:שנייה|רגע|מעט) אני )')
PIVOT = re.compile(r'\s*(?:[.;!]\s*|,\s*(?=(?:אבל |רק |בעצם |בפועל |אמרתי ש|ואני ))|\s+אבל\s+)')
OWN = re.compile(r'^(?:אבל |ואני |בפועל |בעצם |אמרתי ש|רק (?=[א-ת]+תי\b))+')
PRONOUN = re.compile(r'(?<![א-ת])אות(?:ו|ה|ם|ן)\b')
DEST_FIX = re.compile(r'^(.+?)\s*[,;–]\s*(?:סליחה|כלומר|התכוונתי|בעצם)[ ,:]+(.+)$')
NEAR_AMOUNT = re.compile(r'(?<![א-ת])כמעט (?:את )?כל (?:ה)?(?=[א-ת])')
NO_START = re.compile(r'^(.+?)[,;.]?\s+אבל ([^.!?]*\bלפני שהתחל(?:תי|נו))$')


def resolve(row, text):
    local = {**row, 'input': {**row['input'], 'utterance': text}}
    val, route = interpret(local, NEUTRAL)
    return json.loads(val) if route in GROUNDED else None


def scoped_decision(row):
    req = row['input']
    text = req['utterance'].strip().rstrip('.!').strip()
    if not text or PRIOR_CONTEXT.search(text) or any(c in text for c in '״"“”'):
        return None
    prefix = UNASSERTED.match(text)
    if prefix:
        before, *after = PIVOT.split(text[prefix.end():], maxsplit=1)
        if not after or not after[0].strip():
            if text.endswith('?'):
                return None
            return decision(), 'nonreport'
        own = OWN.sub('', after[0]).strip()
        if DOUBT.search(own) and re.search(r'(?:עשיתי את זה|ביצעתי (?:את זה|אותה))\b', own):
            return None  # The existing doubt resolver uses the named action in the lead.
        if PRONOUN.search(own):
            earlier = resolve(row, before)
            facts = earlier['facts'] if earlier else []
            if len(facts) == 1:
                slot = next((a for a in action_slots(req['recipe']['actions'])
                             if a.key == facts[0]['action']), None)
                if slot:
                    own = PRONOUN.sub('את ' + ' '.join(slot.obj), own, count=1)
        return resolve(row, own) or decision(doubts=[None]), 'asserted_suffix'

    check = CHECK.match(text)
    if check and text.endswith('?'):
        answer = resolve(row, text[check.end():])
        if answer and answer['clarify'] and not answer['facts']:
            return answer, 'confirmation_question'

    if text.endswith('?') or DOUBT.search(text) or re.search(r'\b(?:אם|נניח|אילו)\b', text):
        return None
    repair = DEST_FIX.fullmatch(text)
    if repair and PLACE.fullmatch(repair[2]):
        places = list(PLACE.finditer(repair[1]))
        before = resolve(row, repair[1])
        if len(places) == 1 and before and len(before['facts']) == 1:
            place = places[0]
            revised = repair[1][:place.start()] + ' ' + repair[2] + repair[1][place.end():]
            target = resolve(row, revised)
            if target:
                return target, 'corrected_destination'

    if NEAR_AMOUNT.search(text) and not re.search(r'\b(?:לא|טרם|בלי)\b', text[:NEAR_AMOUNT.search(text).start()]):
        # Use the existing partial-portion parser, including its treatment of a later remainder.
        revised = NEAR_AMOUNT.sub('חלק מה', text)
        partial = resolve(row, revised)
        if partial:
            return partial, 'near_total_quantity'

    stopped = NO_START.fullmatch(text)
    if stopped:
        phrase = stopped[1].strip().rstrip(',')
        if phrase.startswith('כמעט '):
            phrase = phrase[len('כמעט '):]
        elif phrase.startswith(('באתי ', 'עמדתי ')):
            infinitive, sep, obj = phrase.split(' ', 1)[1].partition(' ')
            if not sep or infinitive not in PAST:
                return None
            phrase = PAST[infinitive] + ' ' + obj
        else:
            return None
        attempt = resolve(row, phrase)
        if attempt and len(attempt['facts']) == 1 and not attempt['clarify']:
            return decision([(attempt['facts'][0]['action'], 'pending')]), 'not_started'
    return None


def process(payload, raw):
    row = json.loads(payload)
    parsed = scoped_decision(row)
    if parsed is None:
        return previous_process(payload, raw)
    value, route = parsed
    accepted = json.dumps(value, ensure_ascii=False)
    out = simulate(row, accepted)
    if route == 'nonreport':
        out['reply'] = 'מצב המתכון נשאר כפי שהיה.'
    return json.dumps({**out, 'accepted_text': accepted, 'route': route}, ensure_ascii=False)
