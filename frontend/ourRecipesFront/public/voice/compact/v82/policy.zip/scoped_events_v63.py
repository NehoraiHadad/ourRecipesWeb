"""Keep assertion, attribution, uncertainty and revision local to each cooking event."""
import json
import re

from coordinated_claims_v62 import (COORD, FOLLOWUP, REPORTED, UNCERTAIN, action_slots,
                                    clause, decision, ingredient, interpret as previous,
                                    pack, referent, select, simulate)
from colloquial_evidence_v60 import result_claim
from destination_evidence_v61 import PREFACE, SOURCE_VERB
from turn_evidence_v58 import MENTION, PRIOR_CONTEXT

FUTURE={'לקלות':'אקלה','לטגן':'אטגן','לחתוך':'אחתוך','לפרוס':'אפרוס','לערבב':'אערבב',
        'לגרר':'אגרר','לקצוץ':'אקצוץ','לשפוך':'אשפוך','לשטוף':'אשטוף','לקלף':'אקלף',
        'להעביר':'אעביר','להוסיף':'אוסיף','לסנן':'אסנן','לקרר':'אקרר','לטרוף':'אטרוף'}
UNCERTAIN_CLAUSE=re.compile(r'^(?:(?:עדיין |כבר )?לא (?:הצלחתי להיזכר|זוכר[ת]?|בטוח[ה]?|יודע[ת]?) אם |אני לא (?:זוכר[ת]?|יודע[ת]?) אם )')
LEADING=re.compile(r'^(?:(?:קודם|בהתחלה|בסוף|בפועל|אחר כך|רגע|עכשיו|בעצם|למעשה|אני|גם|רק אז)\s+)+')
CORRECT=re.compile(r'(?:רק )?(חצי|שליש|רבע|חלק) (?:ממנו|ממנה|מהכמות) (נכנס[ה]?|נמזג[ה]?|בוצע|הושלם)')
CONDITIONAL=re.compile(r'^אם (?:כן\b|(?:אני |אנחנו )?[אנ][א-ת]{2,}\b|הייתי\b)')
ATTRIBUTED=re.compile(r'^(?:ה(?:יא|וא) (?:אמר[ה]?|סיפר[ה]?|כתב[ה]?) ש|לפי מה ש(?:היא|הוא) (?:אמר[ה]?|כתב[ה]?) )')
CHOICE=re.compile(r'בחרתי ב([א-ת]+)')
COOL=re.compile(r'(?:הכנסתי|שמתי|העברתי) את (.+?) למקרר כדי לקרר (?:אותו|אותה|אותם|אותן)')
# A comma can introduce an independent statement. A coordinated verb remains
# under the same attribution, question or hypothetical until an explicit contrast.
BOUNDARY=re.compile(r'\s*[,;]\s*|\s+(?:אבל|ואילו)\s+')
CHAIN=re.compile(r'\s+(?:ולאחר מכן|ורק אחר כך|ולבסוף)\s+|'+COORD.pattern)


def event(phrase,slots,actions,last,last_key,chosen):
    phrase=LEADING.sub('',phrase).strip()
    if chosen and phrase.startswith('לשם '):
        phrase='ל'+chosen+' '+phrase[len('לשם '):]
    correction=CORRECT.fullmatch(phrase)
    if correction and last_key:
        if correction[2] in ('בוצע','הושלם') or any(a.key==last_key and a.verb in SOURCE_VERB for a in slots):
            return last_key,'partial',last
    cooling=COOL.fullmatch(phrase)
    if cooling and last:
        dest=next((a.vessel for a in slots if a.key==last_key),'')
        if ingredient(cooling[1]) in (last,ingredient(dest)):
            return select(slots,last,('לקרר',)),'partial',last
    future=re.fullmatch(r'(?:את )?(.+?) (?:אני )?([א-ת]+) רק (?:מחר|בהמשך|אחר כך)',phrase)
    if future:
        obj=referent(future[1],last)
        verbs=[v for v,word in FUTURE.items() if word==future[2]]
        if verbs and any(a.obj==obj and a.verb in verbs for a in slots):
            return select(slots,obj,verbs),'pending',obj
    parsed=clause(phrase,slots,last)
    if parsed:
        return parsed
    found=result_claim(phrase,actions,None)
    if found:
        noun,matches,status=found
        if matches:
            return matches[0]['id'] if len(matches)==1 else None,status,ingredient(noun)
    return None


def interpret(row,raw):
    req=row['input']
    text=PREFACE.sub('',req['utterance'].strip())
    if PRIOR_CONTEXT.search(text) or any(c in text for c in '"״“”'):
        return previous(row,raw)
    actions=req['recipe']['actions']
    slots=action_slots(actions)
    facts={}
    doubts={}
    last=last_key=chosen=intent=None
    specialized=False
    for sentence,mark in re.findall(r'([^.!?]+)([.!?]*)',text):
        sentence=sentence.strip()
        if ((ATTRIBUTED.match(sentence) or REPORTED.match(sentence))
                and not re.search(r'\b(?:אבל|בפועל|ואני|ואילו אני)\b',sentence)):
            specialized=True
            last=last_key=None
            continue
        if CONDITIONAL.match(sentence) and 'אבל' not in sentence:
            # The whole conditional, including its coordinated antecedents and consequent.
            specialized=True
            if '?' in mark and not facts and not doubts:
                intent='quantity' if re.search(r'כמה|מידה',sentence) else 'explain'
            continue
        for fragment in BOUNDARY.split(sentence):
            fragment=fragment.strip()
            if not fragment or fragment in ('רגע','שנייה'):
                continue
            if CONDITIONAL.match(fragment) or ATTRIBUTED.match(fragment) or REPORTED.match(fragment):
                specialized=True
                continue
            if MENTION.search(fragment):
                return previous(row,raw)
            if FOLLOWUP.fullmatch(fragment):
                intent='next'
                continue
            fragment=LEADING.sub('',fragment)
            choice=CHOICE.fullmatch(fragment)
            if choice:
                qual=ingredient(choice[1])
                vessels={(a.vessel,a.qualifier) for a in slots if a.qualifier==qual}
                if len(vessels)!=1:
                    return previous(row,raw)
                vessel,adjective=vessels.pop()
                chosen=vessel+' ה'+adjective[0]
                specialized=True
                continue
            doubt=UNCERTAIN_CLAUSE.match(fragment) or UNCERTAIN.match(fragment)
            question=re.match(r'^האם (?:גם )?',fragment)
            prefix=doubt or question
            if prefix:
                fragment=fragment[prefix.end():]
                specialized=True
            parsed=event(fragment,slots,actions,last,last_key,chosen)
            for part in [fragment] if parsed else CHAIN.split(fragment):
                item=parsed or event(part,slots,actions,last,last_key,chosen)
                if item is None:
                    return previous(row,raw)
                key,status,obj=item
                if obj:
                    last=obj
                if status is None:
                    continue
                last_key=key
                implicit_question='?' in mark and 'האם ' not in sentence
                if doubt or question or implicit_question or status in ('doubt','uncertain') or key is None:
                    facts.pop(key,None)
                    doubts[key]=True
                else:
                    doubts.pop(key,None)
                    facts[key]=status
                specialized=True
    if specialized:
        return pack(decision(facts.items(),doubts,intent),'scoped_events')
    return previous(row,raw)


def process(payload,raw):
    row=json.loads(payload)
    accepted,route=interpret(row,raw)
    return json.dumps({**simulate(row,accepted),'route':route,'accepted_text':accepted},ensure_ascii=False)
