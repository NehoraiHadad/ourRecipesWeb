"""Evaluate grounded progress recognition against the same native Q4 generations."""
import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
from unittest.mock import patch

from compare_llama_v22 import PLAN as RUNTIME_PLAN, launch
from explicit_nonstart_data_v24 import DATA as V24_DATA
from explicit_nonstart_study_v24 import historical as older, verify as verify_prior
from explicit_nonstart_v24 import apply as v24
from fresh_pairs_v15 import PLAN as TOKENIZER_PLAN, digest, measurements, read, write
from grounded_progress_data_v25 import DATA, ROOT, build
from grounded_progress_v25 import apply
import preserve_reports_v20 as preservation
from quantized_state_v23 import state_gate
import report_scope_v21 as v21
import scoped_decode_v17 as decomposition
from sparse_recipe_v3 import aggregate, score

FREEZE = ROOT / 'verification/grounded-progress-freeze-v25-20261119.json'
V24_RAW = ROOT / 'verification/explicit-nonstart-raw-v24-20261119.jsonl'


def verify():
    verify_prior()
    for name, expected in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != expected:
            raise ValueError(f'Changed V25 input: {name}')
    if read(DATA) != build():
        raise ValueError('V25 data differs from its specification')


def measure(rows, baseline, paired, candidate=apply):
    if [p['id'] for p in baseline] != [r['id'] for r in rows]:
        raise ValueError('Response and request identity mismatch')
    output, before = [], []
    revisions = Counter()
    for row, record in zip(rows, baseline, strict=True):
        raw = record['text']
        prior = v24(row, raw)[0]
        text, used = candidate(row, raw)
        a, b = score(row, prior), score(row, text)
        revisions.update(grounded=used, exact_fixed=not a['exact'] and b['exact'],
                         exact_broken=a['exact'] and not b['exact'])
        before.append({'id': row['id'], 'text': prior})
        output.append({'id': row['id'], 'v21': raw, 'v24': prior, 'text': text, 'grounded': used})
    def metrics(records):
        if paired:
            return measurements(rows, records)
        return {'overall': aggregate(rows, [p['text'] for p in records])[0]}
    return {'before': metrics(before), 'after': metrics(output), 'revisions': dict(revisions),
            'new_errors': state_gate(rows, before, output)}, output


def historical():
    yield from older()
    with V24_RAW.open() as source:
        records = [{'id': item['id'], 'text': item['v21']} for line in source
                   if (item := json.loads(line))['kind'] == 'comparison']
    yield 'v24_prospective_q4', read(V24_DATA), True, records


def generate_q4(rows, assets, bin_dir, output):
    from transformers import AutoTokenizer

    runtime = read(RUNTIME_PLAN)
    model = (assets / runtime['formats']['q4_k_m']).resolve()
    expected = read(ROOT / runtime['export_manifest'])['models'][model.name]
    if model.stat().st_size != expected['bytes'] or digest(model) != expected['sha256']:
        raise ValueError('Q4 must match the verified V22 export')
    tokenizer_path = ROOT / runtime['tokenizer_base']
    hashes = read(TOKENIZER_PLAN)['model_sha256']
    for name in ('tokenizer.json', 'tokenizer_config.json'):
        if digest(tokenizer_path / name) != hashes[name]:
            raise ValueError(f'Tokenizer integrity mismatch: {name}')
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True, trust_remote_code=False)
    binary = (bin_dir / 'llama-server').resolve()
    version = subprocess.check_output([str(binary), '--version'], stderr=subprocess.STDOUT, text=True).strip()
    if runtime['llama_commit'][:9] not in version:
        raise ValueError('Incorrect llama.cpp build')

    with launch(binary, model, output / 'runtime.log', runtime) as (decoder, _, _):
        with patch.object(preservation, 'model_for', lambda *a, **k: (decoder, tokenizer)), \
             patch.object(preservation, 'decode', decoder.decode), \
             patch.object(decomposition, 'decode', decoder.decode):
            inputs, work = preservation.new_inputs(rows, tokenizer_path, output, read(v21.PLAN))
        write(output / 'calls.json', decoder.calls)
    _, v20 = preservation.measure(rows, inputs, True)
    _, baseline = v21.measure(rows, v20, True)
    return baseline, {'runtime': version, 'q4': expected, 'work': work}


def decide(groups):
    fresh = groups['prospective_q4']['after']
    overall = fresh['overall']
    target = fresh['families']['open']
    old = groups['v24_prospective_q4']['after']['overall']
    checks = {
        'explicit_all_exact': overall['exact'] - target['exact'] == overall['cases'] - target['rows'],
        'open_form_all_exact': target['exact'] == target['rows'],
        'v24_all_exact': old['exact'] == old['cases'],
        'no_exact_breaks': all(g['revisions']['exact_broken'] == 0 for g in groups.values()),
        'no_new_wrong_state_or_fact': all(not any(g['new_errors'].values()) for g in groups.values()),
    }
    return {'checks': checks, 'all_pass': all(checks.values()), 'additional_model_calls': 0}


def run(assets, bin_dir, output):
    verify()
    output.mkdir(parents=True, exist_ok=False)
    groups, raw = {}, {}
    for name, cases, paired, records in historical():
        groups[name], raw[name] = measure(cases, records, paired)
    write(output / 'historical.json', groups)
    rows = read(DATA)
    baseline, runtime = generate_q4(rows, assets, bin_dir, output)
    groups['prospective_q4'], raw['prospective_q4'] = measure(rows, baseline, True)
    write(output / 'raw.json', raw)
    write(output / 'study.json', {**runtime, 'groups': groups, 'decision': decide(groups)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.output)
