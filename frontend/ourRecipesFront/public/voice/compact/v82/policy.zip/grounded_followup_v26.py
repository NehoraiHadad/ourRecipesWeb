"""Interpret explicit progress when followed by a separate navigation question."""
import re

from explicit_nonstart_v24 import NEGATIVE, WORD
from grounded_progress_v25 import action_patterns, evidence, object_word
from grounded_progress_v25 import apply as v25
from scoped_decode_v17 import compact

NEXT = (
    r'(?:מה (?:עכשיו|הלאה|לעשות עכשיו|כדאי לעשות|עליי לעשות עכשיו|הצעד הבא(?: שלי)?|השלב הבא)'
    r'|איך (?:ממשיכים|להמשיך)(?: מכאן| מפה)?)'
)
NAVIGATION = re.compile(rf'(?:(?P<report>.+?)[.,;!]\s*)?{NEXT}\?')
SCENARIO = re.compile(r'נניח ש(?P<report>.+?)[.,;]\s*(?:מה|איך) הייתי [א-ת]+(?: אחר כך| מכאן)?\?')
QUOTED = re.compile(r'(?:"[^"]+"|״[^״]+״) (?:זו |זאת |זה )?רק (?:דוגמה|ציטוט)')
SIDE = r'(?:מצד אחד|מצד אחד בלבד|בצד אחד)'
SIDES = r'(?:משני הצדדים|בשני הצדדים)'
PASSIVE = {
    'לקלות': 'קלוי(?:ה|ים|ות)?',
    'לטגן': 'מטוגנ(?:ת|ים|ות)|מטוגן',
    'לשטוף': 'שטו(?:ף|פה|פים|פות)',
    'למדוד': 'מדוד(?:ה|ים|ות)?',
    'לבשל': 'מבושל(?:ת|ים|ות)?',
}
PART = r'(?:חלק|מעט|קצת|חצי|שליש|רבע) מ(?:מנו|מנה|הם|הן)'
COMPLETION = r'(?:עד הסוף|באופן מלא)'
CORRECTION = re.compile(r'[.,;]\s*(?:בעצם|תיקון) ')
READINESS = r'(?:עוד |עדיין )?לא מוכנ(?:ה|ים|ות)? (?:למדידה|לשטיפה|לבישול)'


def empty(intent):
    return {'intent': intent, 'facts': [], 'clarify': []}


def fact(ident, status):
    return {'intent': 'report', 'facts': [{'action': ident, 'status': status}], 'clarify': []}


def with_utterance(row, text):
    return {**row, 'input': {**row['input'], 'utterance': text}}


def action_forms(row):
    for action in row['input']['recipe']['actions']:
        source = action['source']
        patterns = action_patterns(source)
        verb, _, tail = source.partition(' ')
        parts = [part for part in tail.split() if part != 'את']
        if patterns and parts and all(WORD.fullmatch(part) for part in parts):
            yield action['id'], verb, patterns[0], ' '.join(map(object_word, parts))


def report_piece(row, text):
    answer = evidence(with_utterance(row, text))
    if answer is not None:
        return answer
    matches = []
    for ident, verb, past, obj in action_forms(row):
        named = rf'(?:את )?{obj}'
        complete = rf'{past} {named} {COMPLETION}'
        limited = (
            rf'{past} {named}(?:,| אבל) רק {PART}'
            rf'|{NEGATIVE}{past} (?:את )?כל {obj}, רק {PART}'
        )
        unstarted = rf'{NEGATIVE}{past} {named}, אפילו לא {PART}'
        if verb in PASSIVE:
            state = rf'{obj} (?:כבר )?(?:{PASSIVE[verb]})'
            complete += rf'|{state}(?: {SIDES})?'
            limited += rf'|{state} (?:רק )?{SIDE}'
        if re.fullmatch(complete, text):
            matches.append(fact(ident, 'done'))
        if re.fullmatch(limited, text):
            matches.append(fact(ident, 'partial'))
        if re.fullmatch(unstarted, text):
            matches.append(fact(ident, 'pending'))
    return matches[0] if len(matches) == 1 else None


def combine_reports(row, text):
    single = report_piece(row, text)
    if single is not None:
        return single
    verbs = {past for _, _, past, _ in action_forms(row)}
    if verbs:
        attached = r'\s+ו(?=(?:' + '|'.join(sorted(verbs)) + r') )'
        parts = re.split(attached, text)
        if len(parts) == 2:
            reports = [report_piece(row, part) for part in parts]
            if all(r and r['intent'] == 'report' for r in reports):
                facts = reports[0]['facts'] + reports[1]['facts']
                clarify = reports[0]['clarify'] + reports[1]['clarify']
                actions = [f['action'] for f in facts] + clarify
                if len(set(actions)) == len(actions):
                    return {'intent': 'report', 'facts': facts, 'clarify': clarify}
    parts = CORRECTION.split(text)
    if len(parts) == 2:
        first, second = (report_piece(row, part) for part in parts)
        if first and second and not (first['clarify'] or second['clarify']):
            old_ids = [f['action'] for f in first['facts']]
            new_ids = [f['action'] for f in second['facts']]
            if len(old_ids) == 1 and old_ids == new_ids:
                return second
    return None


def apply(row, raw):
    text = ' '.join(row['input']['utterance'].strip().removesuffix('.').split())
    nav = NAVIGATION.fullmatch(text)
    if nav:
        report = nav['report']
        if report is None or QUOTED.fullmatch(report):
            return compact(empty('next'), row), True
        found = combine_reports(row, report)
        if found is not None:
            if found['facts'] or found['intent'] == 'other':
                return compact({**found, 'intent': 'next'}, row), True
        if any(re.fullmatch(rf'{obj} {READINESS}', report) for _, _, _, obj in action_forms(row)):
            return compact(empty('next'), row), True
    elif scenario := SCENARIO.fullmatch(text):
        hypothetical = report_piece(row, scenario['report'])
        if hypothetical and hypothetical['intent'] == 'report':
            return compact(empty('explain'), row), True
    else:
        # V25 owns the complete-sentence reading whenever it recognizes the source.
        if evidence(row) is None:
            found = combine_reports(row, text)
            if found is not None:
                return compact(found, row), True
    return v25(row, raw)
