"""Bounded comparison of matched SFT with original versus new TRAIN examples."""
import argparse
import gc
from importlib.metadata import version
import json
from pathlib import Path
import time
from unittest.mock import patch

import adapter_scope_sft_v11 as engine
from fact_contrast_v13 import loss_step,schedule_summary
from fresh_pairs_v15 import measurements
from semantic_supervision_data_v12 import read_native
import semantic_supervision_train_v12 as trainer
from semantic_supervision_v12 import exposure,load_tokenizer
from sparse_recipe_study_v4 import metrics_for
from targeted_corpus_v16 import DATA,FRESH,ROOT,build

ARMS=('frozen_control','targeted_train')
PLAN=ROOT/'verification/targeted-corpus-plan-v16-20261118.json'
MANIFEST=ROOT/'verification/targeted-corpus-freeze-v16-20261118.json'
PREFLIGHT=ROOT/'verification/targeted-corpus-preflight-v16-20261118.json'


def read(path):
    return json.loads(path.read_text())


def verify():
    for name,sha in read(MANIFEST)['sha256'].items():
        if engine.digest(ROOT/name)!=sha:
            raise ValueError(f'Frozen V16 artifact mismatch: {name}')


def material():
    stored,fresh=read(DATA),read(FRESH)
    if (stored,fresh)!=build():
        raise ValueError('V16 train or evaluation differs from authored material')
    return stored,fresh


def preflight(tokenizer,plan):
    native=read_native()
    data,fresh=material()
    limit=plan['max_sequence_tokens']
    order=exposure(plan,len(native['train']))
    out={}
    for name,rs in [('frozen_control',native['train']),('targeted_train',data['targeted_train']),('fresh',fresh),
                    ('validation',native['validation']),('diagnostic',native['diagnostic']),('regression',native['regression'])]:
        encoded=[engine.encode(tokenizer,row,limit) for row in rs]
        if name in ARMS:
            out[name]=schedule_summary(encoded,{},order)
        else:
            max_prompt=max(r['prompt_tokens'] for r in encoded)
            if max_prompt+plan['evaluation']['max_new_tokens']>limit:
                raise ValueError('Evaluation sequence exceeds context budget')
            out[name]={'cases':len(rs),'max_prompt_tokens':max_prompt}
    return {'encoding':out,'dataset':data['audit']}


def decide(a,b,plan):
    """Same prospective gate on complete, matched evaluation outputs."""
    ac,bc=a['fresh']['overall'],b['fresh']['overall']
    target=lambda r:sum(r['fresh']['families'][g]['both_exact'] for g in ('clause','history'))
    ar,br=a['known']['regression'],b['known']['regression']
    ad,bd=a['known']['all_development'],b['known']['all_development']
    g=plan['noticeable_gate']
    changes={'fresh_exact':bc['exact']-ac['exact'], 'fresh_wrong_without_report':bc['critical_wrong_fact_cases']-ac['critical_wrong_fact_cases'],
             'target_pairs_both_correct':target(b)-target(a),'regression_exact':br['exact']-ar['exact'],
             'known_development_exact':bd['exact']-ad['exact']}
    checks={'fresh_exact':changes['fresh_exact']>=g['fresh_exact_gain_min'],
            'fresh_wrong_without_report':bc['critical_wrong_fact_cases']<=g['wrong_without_report_max_ratio']*ac['critical_wrong_fact_cases'],
            'target_pairs_both_correct':changes['target_pairs_both_correct']>=g['target_pair_gain_min'],
            'regression_exact':changes['regression_exact']>=-g['max_regression_loss'],
            'regression_critical':br['critical_wrong_fact_cases']<=ar['critical_wrong_fact_cases'],
            'known_development':changes['known_development_exact']>=-g['max_old_development_loss']}
    return {'changes':changes,'checks':checks,'noticeable_research_improvement':all(checks.values()),
            'product_promotion':False}


def run(output):
    import torch
    from huggingface_hub import snapshot_download

    verify()
    plan=read(PLAN)
    runtime=plan['runtime']
    if (not torch.cuda.is_available() or 'T4' not in torch.cuda.get_device_name(0)
            or torch.__version__.split('+')[0]!=runtime['torch'] or torch.version.cuda!=runtime['cuda']):
        raise RuntimeError('V16 requires the pinned Colab T4 environment')
    for dep in plan['dependencies']:
        pkg,expected=dep.split('==')
        if version(pkg)!=expected:
            raise RuntimeError(f'Requires {dep}')
    output.mkdir(parents=True,exist_ok=False)
    began=time.monotonic()
    torch.set_num_threads(2)
    spec=plan['model']
    snapshot=Path(snapshot_download(spec['repo'],revision=spec['revision'],token=False,
                    allow_patterns=['config.json','generation_config.json','tokenizer*.json','*.jinja',
                                    'vocab.json','merges.txt','model.safetensors','LICENSE']))
    weights=snapshot/'model.safetensors'
    if weights.stat().st_size!=spec['weight_bytes'] or engine.digest(weights)!=spec['weight_sha256']:
        raise ValueError('Wrong frozen base weights')
    for name,expected in spec['small_file_sha256'].items():
        if engine.digest(snapshot/name)!=expected:
            raise ValueError(f'Base metadata integrity failure: {name}')
    tokenizer=load_tokenizer(snapshot,plan)
    native=read_native()
    data,fresh=material()
    if preflight(tokenizer,plan)!=read(PREFLIGHT):
        raise ValueError('VM token preflight differs from the frozen CPU report')
    benchmark=read(ROOT/plan['evaluation']['master_file'])['splits']
    order=exposure(plan,len(native['train']))
    anchors=None
    metric={}
    raw_evaluate=engine.evaluate

    def objective(model,main,extra,indices,pad,device,*,backward):
        return loss_step(model,main,extra,indices,pad,device,backward=backward,weight=0.0,margin=1.0)

    def evaluate(model,tokenizer,rows,output,step,plan):
        result=raw_evaluate(model,tokenizer,rows,output,step,plan)
        if step=='regression-160':
            raw_evaluate(model,tokenizer,fresh,output,'fresh-160',plan)
        return result

    for arm,rows in zip(ARMS,(native['train'],data['targeted_train']),strict=True):
        print(f'Running {arm}',flush=True)
        path=output/arm
        main=[engine.encode(tokenizer,row,plan['max_sequence_tokens']) for row in rows]
        with patch.object(trainer,'microbatch',objective),patch.object(trainer,'token_summary',schedule_summary),patch.object(engine,'evaluate',evaluate):
            anchors=trainer.train_arm(path,snapshot,tokenizer,plan,{**native,'train':rows},main,{},order,began,anchors)
        fresh_output=read(path/'validation-step-fresh-160.json')['records']
        metric[arm]={'known':metrics_for(path,160,benchmark),'fresh':measurements(fresh,fresh_output)}
        gc.collect()
        torch.cuda.empty_cache()
    engine.dump(output/'result.json',{'arms':metric,'decision':decide(*(metric[a] for a in ARMS),plan),
                                     'matching_known_step0_outputs_and_tokens':280})


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--train',type=Path)
    mode.add_argument('--preflight',type=Path)
    args=parser.parse_args()
    verify()
    if args.train:
        run(args.train)
    else:
        plan=read(PLAN)
        print(json.dumps(preflight(load_tokenizer(args.preflight,plan),plan),indent=2))
