"""Validate explicit progress plus navigation on new Q4 and prior replay data."""
import argparse
from collections import Counter
import json
from pathlib import Path

from fresh_pairs_v15 import digest, measurements, read, write
from grounded_followup_data_v26 import DATA, ROOT, build
from grounded_followup_v26 import apply
from grounded_progress_data_v25 import DATA as V25_DATA
from grounded_progress_study_v25 import generate_q4, historical as older, verify as verify_prior
from grounded_progress_v25 import apply as v25
from quantized_state_v23 import state_gate
from sparse_recipe_v3 import aggregate, score

FREEZE = ROOT / 'verification/grounded-followup-freeze-v26-20261119.json'
V25_RAW = ROOT / 'verification/grounded-progress-raw-v25-20261119.jsonl'


def verify():
    verify_prior()
    for name, sha in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != sha:
            raise ValueError(f'Changed V26 input: {name}')
    if read(DATA) != build():
        raise ValueError('V26 data differs from its specification')


def historical():
    yield from older()
    with V25_RAW.open() as source:
        records = [{'id': item['id'], 'text': item['v21']} for line in source
                   if (item := json.loads(line))['kind'] == 'comparison']
    yield 'v25_prospective_q4', read(V25_DATA), True, records


def measure(rows, baseline, paired):
    if [r['id'] for r in rows] != [p['id'] for p in baseline]:
        raise ValueError('Response and request identity mismatch')
    outputs, control = [], []
    changes = Counter()
    for row, record in zip(rows, baseline, strict=True):
        base = record['text']
        prior = v25(row, base)[0]
        text, grounded = apply(row, base)
        a, b = score(row, prior), score(row, text)
        changes.update(grounded=grounded, exact_fixed=not a['exact'] and b['exact'],
                       exact_broken=a['exact'] and not b['exact'])
        control.append({'id': row['id'], 'text': prior})
        outputs.append({'id': row['id'], 'v21': base, 'v25': prior, 'text': text, 'grounded': grounded})
    def stats(records):
        if paired:
            return measurements(rows, records)
        return {'overall': aggregate(rows, [p['text'] for p in records])[0]}
    return {'before': stats(control), 'after': stats(outputs), 'changes': dict(changes),
            'new_errors': state_gate(rows, control, outputs)}, outputs


def decide(groups):
    def complete(label):
        values = groups[label]['after']['overall']
        return values['exact'] == values['cases']
    checks = {
        'prospective_all_exact': complete('prospective_q4'),
        'v25_all_exact': complete('v25_prospective_q4'),
        'v24_all_exact': complete('v24_prospective_q4'),
        'no_exact_breaks': all(g['changes']['exact_broken'] == 0 for g in groups.values()),
        'no_new_wrong_facts_or_state': all(not any(g['new_errors'].values()) for g in groups.values()),
    }
    return {'checks': checks, 'all_pass': all(checks.values()), 'additional_model_calls': 0}


def run(assets, bin_dir, output):
    verify()
    output.mkdir(parents=True, exist_ok=False)
    groups, raw = {}, {}
    for name, rows, paired, records in historical():
        groups[name], raw[name] = measure(rows, records, paired)
    write(output / 'historical.json', groups)
    rows = read(DATA)
    baseline, runtime = generate_q4(rows, assets, bin_dir, output)
    groups['prospective_q4'], raw['prospective_q4'] = measure(rows, baseline, True)
    write(output / 'raw.json', raw)
    write(output / 'study.json', {**runtime, 'groups': groups, 'decision': decide(groups)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.output)
