"""New recipe-source quantity, duration, ambiguity and non-report contrasts."""
from pathlib import Path
import random

from explicit_nonstart_data_v24 import DATA as V24
from fresh_pairs_data_v15 import DATA as V15, canonical
from fresh_pairs_v15 import read, write
from grounded_followup_data_v26 import DATA as V26
from grounded_progress_data_v25 import DATA as V25
from grounded_scope_data_v18 import DATA as V18
from preserve_reports_data_v20 import DATA as V20
from report_scope_data_v21 import DATA as V21
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/grounded-recipe-source-data-v27-20261119.json'

RECIPES = (
    ('מרק שורש פטרוזיליה', ('לחמם ארבע כוסות ציר שורשים.', 'לקצוץ שורש פטרוזיליה אחד.',
                            'לבשל את המרק במשך שמונה דקות.', 'להוסיף פטרוזיליה קצוצה.'),
     ('ליתר ביטחון, טרם חיממתי את ציר השורשים.', 'הספקתי רק להתחיל לחמם את ציר השורשים, נותר להשלים.'),
     ('בישלתי את המרק; לעומת זאת טרם קצצתי את שורש הפטרוזיליה.',
      'טרם בישלתי את המרק; לעומת זאת קצצתי את שורש הפטרוזיליה.'),
     ('אני רק מצטטת מישהו שאמר ״בישלתי את המרק״; לא אמרתי שביצעתי את זה.', 'בישלתי את המרק.')),
    ('קרם תירס ופלפל קלוי', ('להפשיר שלוש כוסות גרגירי תירס.', 'להוסיף שני פלפלים מרוסקים.',
                             'לערבב את הקרם.', 'לטחון את התערובת.'),
     ('למען הסר ספק, עוד לא הפשרתי את גרגירי התירס.', 'הספקתי רק להתחיל להפשיר את גרגירי התירס, נשאר להשלים.'),
     ('ערבבתי את הקרם; לעומת זאת עוד לא הוספתי את הפלפלים.',
      'טרם ערבבתי את הקרם; לעומת זאת הוספתי את הפלפלים.'),
     ('בעוד חצי שעה אטחן את זה. מה השלב הבא?', 'ערבבתי את הקרם. מה השלב הבא?')),
    ('מאפה קישואים ומוצרלה', ('לגרר שני קישואים.', 'לשקול ארבע כפות קמח תירס.',
                               'לאפות את המאפה עשרים דקות.', 'לקרר את המאפה.'),
     ('אצלי טרם גיררתי את הקישואים.', 'הספקתי רק להתחיל לגרר את הקישואים, נשאר להשלים.'),
     ('אפיתי את המאפה; לעומת זאת טרם שקלתי את קמח התירס.',
      'טרם אפיתי את המאפה; לעומת זאת שקלתי את קמח התירס.'),
     ('במתכון מאפה קישואים ומוצרלה, מה עושים מכאן?', 'אפיתי את המאפה. מה עושים מכאן?')),
    ('שוקו הל ותמרים', ('למזוג שתי כוסות משקה שיבולת שועל.', 'להמיס שלוש כפות שוקולד.',
                       'להרתיח את המשקה במשך דקה.', 'לצקת את השוקו.'),
     ('אצלי עוד לא מזגתי את משקה שיבולת השועל.', 'הספקתי רק להתחיל למזוג את משקה שיבולת השועל, נותר להשלים.'),
     ('הרתחתי את המשקה; לעומת זאת עוד לא המסתי את השוקולד.',
      'עוד לא הרתחתי את המשקה; לעומת זאת המסתי את השוקולד.'),
     ('בעוד שעה אמזוג את זה. מה עכשיו?', 'הרתחתי את המשקה. מה עכשיו?')),
    ('סלט שעועית צהובה', ('לחמם את השעועית במשך שתי דקות.', 'לפרוס צנונית אחת.',
                          'לפתוח את הצנצנת.', 'לתבל את הסלט.'),
     ('ליתר ביטחון, לא חיממתי בכלל את השעועית.', 'אני חוזרת בי ממה שאמרתי, הספקתי רק להתחיל לחמם את השעועית, נותר להשלים.'),
     ('פתחתי את הצנצנת; לעומת זאת טרם פרסתי את הצנונית.',
      'טרם פתחתי את הצנצנת; לעומת זאת פרסתי את הצנונית.'),
     ('אני מצטט מישהו שאמר ״פתחתי את הצנצנת״; לא אמרתי שביצעתי זאת.', 'מבחינתי זה גמור: פתחתי את הצנצנת.')),
    ('רפרפת וניל וסוכר דמררה', ('להוסיף שתי כפות סוכר דמררה.', 'להוסיף כף סוכר דמררה.',
                                 'לבשל את הרפרפת במשך שש דקות.', 'לכסות את הרפרפת.'),
     ('עוד לא הוספתי את סוכר הדמררה.', 'עוד לא הוספתי שתי כפות סוכר דמררה.'),
     ('בישלתי את הרפרפת וגם כיסיתי את הרפרפת.', 'טרם בישלתי את הרפרפת וגם כיסיתי את הרפרפת.'),
     ('עוד לא הוספתי כף סוכר דמררה.', 'הוספתי כף סוכר דמררה.')),
)


def build():
    rows = []
    rng = random.Random(271119)
    for i, (name, sources, amount, mixed, contrast) in enumerate(RECIPES):
        (a, b, c, d), ctx = fixture(rng, name, sources, i, 'fresh-v27')
        ctx['progress'].update({a: 'done', b: 'partial', c: 'pending', d: 'pending'})
        first = (response('report', [(a, 'pending')]), response('report', [(a, 'partial')]))
        both = (response('report', [(c, 'done'), (b, 'pending')]),
                response('report', [(c, 'pending'), (b, 'done')]))
        scope = (
            ('other', 'report'), ('next', 'next'), ('next', 'next'),
            ('next', 'next'), ('other', 'report'),
        )
        if i == 5:
            first = (response('clarify', clarify=[None]), response('report', [(a, 'pending')]))
            both = (response('report', [(c, 'done'), (d, 'done')]),
                    response('report', [(c, 'pending'), (d, 'done')]))
            last = (response('report', [(b, 'pending')]), response('report', [(b, 'done')]))
        else:
            left, right = scope[i]
            last = (response(left), response(right, [(c, 'done')]))
        pair(rows, ctx, 'amount_0', amount, first)
        pair(rows, ctx, 'mixed_0', mixed, both)
        pair(rows, ctx, 'contrast_0', contrast, last)

    audit_new(rows, 36)
    prior = [r for split in read_native().values() for r in split] + train_new()
    for path in (V15, V16, V18, V20, V21, V24, V25, V26):
        prior.extend(read(path))
    names = {r['input']['recipe']['name'] for r in prior}
    utterances = {canonical(r['input']['utterance']) for r in prior}
    if any(r['input']['recipe']['name'] in names or canonical(r['input']['utterance']) in utterances for r in rows):
        raise ValueError('V27 overlaps a known exact utterance or recipe name')
    return rows


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
