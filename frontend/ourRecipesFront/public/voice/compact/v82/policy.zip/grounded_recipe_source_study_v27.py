"""Verify broader regression recovery and fresh recipe-grounded reasoning."""
import argparse
from collections import Counter
import json
from pathlib import Path

from fresh_pairs_v15 import digest, measurements, read, write
from grounded_followup_data_v26 import DATA as V26_DATA
from grounded_followup_study_v26 import historical as older, measure as measure_prior, verify as verify_prior
from grounded_progress_study_v25 import generate_q4
from grounded_recipe_source_data_v27 import DATA, ROOT, build
from grounded_recipe_source_v27 import apply
from quantized_state_v23 import state_gate
from sparse_recipe_v3 import aggregate, score

FREEZE = ROOT / 'verification/grounded-recipe-source-freeze-v27-20261119.json'
V26_RAW = ROOT / 'verification/grounded-followup-raw-v26-20261119.jsonl'


def verify():
    verify_prior()
    for name, sha in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != sha:
            raise ValueError(f'Changed V27 input: {name}')
    if read(DATA) != build():
        raise ValueError('V27 data differs from its specification')


def historical():
    yield from older()
    with V26_RAW.open() as source:
        records = [{'id': item['id'], 'text': item['v21']} for line in source
                   if (item := json.loads(line))['kind'] == 'comparison']
    yield 'v26_prospective_q4', read(V26_DATA), True, records


def measure(rows, baseline, paired):
    before, prior = measure_prior(rows, baseline, paired)
    outputs = []
    changes = Counter()
    for row, record in zip(rows, prior, strict=True):
        text, grounded = apply(row, record['v21'])
        a, b = score(row, record['text']), score(row, text)
        changes.update(grounded=grounded, exact_fixed=not a['exact'] and b['exact'],
                       exact_broken=a['exact'] and not b['exact'])
        outputs.append({'id': row['id'], 'v21': record['v21'],
                        'v26': record['text'], 'text': text, 'grounded': grounded})
    if paired:
        after = measurements(rows, outputs)
    else:
        after = {'overall': aggregate(rows, [p['text'] for p in outputs])[0]}
    return {'before': before['after'], 'after': after, 'changes': dict(changes),
            'new_errors': state_gate(rows, prior, outputs)}, outputs


def decide(groups):
    def complete(label):
        values = groups[label]['after']['overall']
        return values['exact'] == values['cases']
    checks = {
        'prospective_all_exact': complete('prospective_q4'),
        'regression_all_exact': complete('regression'),
        'v24_v25_v26_all_exact': all(complete(f'v{version}_prospective_q4') for version in (24,25,26)),
        'no_exact_breaks': all(g['changes']['exact_broken'] == 0 for g in groups.values()),
        'no_new_wrong_facts_or_state': all(not any(g['new_errors'].values()) for g in groups.values()),
    }
    return {'checks': checks, 'all_pass': all(checks.values()), 'additional_model_calls': 0}


def run(assets, bin_dir, output):
    verify()
    output.mkdir(parents=True, exist_ok=False)
    groups, raw = {}, {}
    for name, rows, paired, records in historical():
        groups[name], raw[name] = measure(rows, records, paired)
    write(output / 'historical.json', groups)
    rows = read(DATA)
    baseline, runtime = generate_q4(rows, assets, bin_dir, output)
    groups['prospective_q4'], raw['prospective_q4'] = measure(rows, baseline, True)
    write(output / 'raw.json', raw)
    write(output / 'study.json', {**runtime, 'groups': groups, 'decision': decide(groups)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.output)
