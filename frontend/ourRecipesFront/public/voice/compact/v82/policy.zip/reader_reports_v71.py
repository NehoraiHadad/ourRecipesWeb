"""Resolve explicit ingredient lists and omissions, and local references in follow-up reports."""
import json
import re

from colloquial_evidence_v60 import decision
from conversational_scope_v69 import resolve
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import ingredient
from spoken_confirmation_v70 import process as previous
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

ADD = re.compile(r'^(?:ו?(?:הוספתי|הוספנו|שמתי|שמנו)|ו?שי?דרגתי עם) (.+)$')
OMIT = re.compile(r'^שכח(?:תי|נו) (?:להוסיף|לשים) (.+)$')
PRAISE = re.compile(r'^(?:מושל[םמת]+|ליגה|מנה (?:מצוינת|מעולה)(?: ופשוטה)?|תודה(?: רבה)?|'
                    r'יצא (?:טעים|מעולה|נהדר)(?: מאוד)?|(?:רכ(?:ות|ים)|פריכ(?:ות|ים)) אבל לא (?:מאד|מאוד) מתפרק(?:ות|ים))$')
SPLIT = re.compile(r'\s*[,.;!]+\s*')
AMOUNT = r'(?:שתי|שני|שלוש|ארבע|חצי|רבע) (?:ה)?(?:כוסות|כפות|כפיות|כוס|כף|כפית)'
LOCATION = re.compile(r'^(?:רגע )?איפה (?:שמתי את )?ה(?:פומפייה|מסננת|קרש|מחבת|סכין|קולפן)\??$')


def unique_add(slots, words):
    ids = [a.key for a in slots if a.verb in ('להוסיף','לשים') and a.obj==ingredient(words)]
    return ids[0] if len(ids)==1 else None


def additions(body, slots):
    body = re.sub(r'^בטעות ', '', body).strip()
    if ' במקום ' in body:
        actual, omitted = body.split(' במקום ',1)
        a,b = unique_add(slots,actual),unique_add(slots,omitted)
        if a and b and a!=b:
            return [(a,'done'),(b,'pending')]
        return None
    # A compound ingredient named in the recipe takes precedence over list splitting.
    single = unique_add(slots,body)
    if single:
        return [(single,'done')]
    items = re.split(r'\s+ו(?=\S)',body)
    keys = [unique_add(slots,item) for item in items]
    if len(keys)>1 and all(keys) and len(set(keys))==len(keys):
        return [(k,'done') for k in keys]
    return None


def authored_report(row,text):
    req=row['input']
    slots=action_slots(req['recipe']['actions'])
    parts=[p for p in SPLIT.split(text) if p]
    facts={}
    specialized=False
    for part in parts:
        if PRAISE.fullmatch(part):
            continue
        add=ADD.fullmatch(part)
        omit=OMIT.fullmatch(part)
        if add:
            found=additions(add[1],slots)
            if found:
                facts.update(found)
                specialized |= len(found)>1 or 'שדרגתי' in part
                continue
        if omit:
            # Only detach an outcome aside from an otherwise complete ingredient name.
            name=re.sub(r'(?: בטעות)?(?: ועדיין יצא (?:מעולה|טעים)(?: באופן מפתיע)?)?$','',omit[1])
            key=unique_add(slots,name)
            if key:
                facts[key]='pending'
                specialized=True
                continue
        if facts and re.fullmatch(r'(?:יש )?איך (?:אפשר )?להציל את (?:הבלילה|הבצק|המנה)\?',part):
            continue
        known=resolve(row,part)
        if not known or not known['facts'] or known['clarify'] or '?' in part:
            return None
        facts.update((f['action'],f['status']) for f in known['facts'])
    if facts and specialized:
        return decision(facts.items())


def followup(req,text):
    actions=req['recipe']['actions']
    history=req['history']
    remainder=re.fullmatch(r'(?:אה |רגע |שנייה )*(?:לא הכול|לא הכל|לא סיימתי)[, ]+נשאר (?:לי )?(?:איזה |עוד )?(?:חצי|רבע|שליש)(?: על הקרש| בצלחת| בקערה)?',text)
    if remainder and history and history[-1]['role']=='assistant':
        ack=re.match(r'עדכנתי: ([^.!?]+?) — בוצע\.',history[-1]['content'])
        matches=[a['id'] for a in actions if ack and a['source'].rstrip('.')==ack[1]]
        if len(matches)==1 and req['progress'].get(matches[0])=='done':
            return decision([(matches[0],'partial')])
    partial=re.fullmatch(r'(?:אוף |טוב )?נמאס לי (ל[א-ת]+)[, ]+(?:אני )?(?:רק |עוד )?(?:בחצי|באמצע)',text)
    if partial:
        keys=[a['id'] for a in actions if a['source'].split()[0]==partial[1]]
        if len(keys)==1:
            return decision([(keys[0],'partial')])
    measure=re.fullmatch(r'(?:שמתי|הוספתי|מזגתי) (?:את )?('+AMOUNT+r')(?:[.!]\s*אפשר להמשיך)?',text)
    if measure and len(history)>=2 and history[-2]['role']=='user':
        quantity=ingredient(measure[1])
        candidates=[a.key for a in action_slots(actions) if a.verb in ('להוסיף','לשים','למזוג')
                    and a.obj[:len(quantity)]==quantity and a.obj[len(quantity):]
                    and set(a.obj[len(quantity):]).issubset(ingredient(history[-2]['content']))]
        if len(candidates)==1:
            return decision([(candidates[0],'done')])
    return None


def process(payload,raw):
    row=json.loads(payload)
    req=row['input']
    text=req['utterance'].strip().rstrip('.!')
    if not text or PRIOR_CONTEXT.search(text) or MENTION.search(text) or DOUBT.search(text) or re.search(r'\b(?:אם|אילו|אולי)\b|[״"“”]',text):
        return previous(payload,raw)
    if LOCATION.fullmatch(text):
        accepted=decision()
        reply='אין לי דרך לדעת איפה הכלי נמצא במטבח שלך.'
    else:
        accepted=followup(req,text)
        if accepted is None and re.search(r'(?:הוספ|שמ|שדרג|שכח)(?:תי|נו)\b',text):
            accepted=authored_report(row,text)
        if accepted is None:
            return previous(payload,raw)
        reply=None
    encoded=json.dumps(accepted,ensure_ascii=False)
    result=simulate(row,encoded)
    if reply:
        result['reply']=reply
    return json.dumps({**result,'accepted_text':encoded,'route':'reader_report'},ensure_ascii=False)
