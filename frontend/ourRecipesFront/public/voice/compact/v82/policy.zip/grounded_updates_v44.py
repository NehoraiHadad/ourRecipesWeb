"""Guard high-risk state writes while preserving independently valid proposals."""
from collections import defaultdict
import json
import re

from clause_report_verifier_v40 import CLAUSES
from grounded_scope_v18 import grounded_actions
from scoped_decode_v17 import compact, literal_ids, unresolved_history
from sparse_recipe_v3 import INTENTS, STATUSES, parse

LATER = re.compile(r'\b(?:מחר|בהמשך|מאוחר יותר|אחר כך|בערב|בעוד|בשבוע הבא)\b')
CONTRAST = re.compile(r'[,;]|\b(?:אבל|כבר|בכל זאת|לעומת זאת|בעבר)\b')


def unique_members(pairs):
    result = dict(pairs)
    if len(result)!=len(pairs):
        raise ValueError('Duplicate JSON field')
    return result


def recover_envelope(raw, request):
    """Preserve safe sibling proposals when a known action has conflicting labels."""
    try:
        obj = json.loads(raw,object_pairs_hook=unique_members)
        ids = {a['id'] for a in request['recipe']['actions']}
        if (not isinstance(obj,dict) or set(obj)!={'intent','facts','clarify'} or obj['intent'] not in INTENTS
                or not isinstance(obj['facts'],list) or not isinstance(obj['clarify'],list)
                or any(a is not None and a not in ids for a in obj['clarify'])):
            return None
        groups = defaultdict(list)
        for fact in obj['facts']:
            if (not isinstance(fact,dict) or set(fact)!={'action','status'} or
                    fact['action'] not in ids or not isinstance(fact['status'],str)):
                return None
            groups[fact['action']].append(fact['status'])
        clarify = dict.fromkeys(obj['clarify'])
        facts = []
        for a, proposed in groups.items():
            statuses = set(proposed)
            if a in clarify or len(statuses)!=1 or proposed[0] not in STATUSES:
                clarify[a] = None
                continue
            facts.append({'action':a,'status':proposed[0]})
        intent = obj['intent']
        if intent=='report' and not facts:
            intent = 'clarify'
        if intent=='clarify' and not clarify:
            clarify[None] = None
        return {'intent':intent,'facts':facts,'clarify':list(clarify)}
    except (ValueError, KeyError, TypeError):
        return None


def explicit_future(source, clause):
    first = re.match(r'(?:אני\s+)?([א-ת]+)',clause)
    verbs = source.split(maxsplit=1)
    if not first or not verbs or not verbs[0].startswith('ל') or len(verbs[0])<3:
        return False
    verb = verbs[0]
    stem = verb[2:] if verb.startswith('לה') else verb[1:]
    return first[1]=='א'+stem and bool(LATER.search(clause)) and not CONTRAST.search(clause)


def future_only_actions(request):
    sources = {action['id']:action['source'] for action in request['recipe']['actions']}
    future, other = set(), set()
    for match in CLAUSES.finditer(request['utterance']):
        clause = match.group().strip()
        anchored = literal_ids(clause,request) or grounded_actions(clause,request)
        scheduled = {action for action in anchored if explicit_future(sources[action],clause)}
        if len(scheduled)==1:
            future.update(scheduled)
        else:
            other.update(anchored)
    return future-other


def bare_reference(request):
    text = request['utterance'].strip().rstrip(' .!?')
    return (not re.search(r'[,.;:!?]',text) and not grounded_actions(text,request)
            and unresolved_history(request))


def accept(row, text):
    request = row['input']
    try:
        result = parse(text,request)
        path = 'raw'
    except (ValueError, TypeError, KeyError):
        result = recover_envelope(text,request)
        if result is None:
            # Simulation treats a structurally invalid response as a request for clarification.
            return text, 'unreadable'
        path = 'recovered_envelope'
    if result['facts'] and result['intent']=='report' and bare_reference(request):
        clarification = {'intent':'clarify','facts':[],'clarify':[None]}
        return compact(clarification,row), 'unresolved_reference'
    if result['facts']:
        future = future_only_actions(request)
        kept = [fact for fact in result['facts'] if fact['action'] not in future]
        if len(kept)!=len(result['facts']):
            result['facts'] = kept
            if result['intent']=='report' and not kept:
                result['intent'] = 'clarify' if result['clarify'] else 'other'
            path = 'future_action_ignored'
    return (text if path=='raw' else compact(result,row)),path
