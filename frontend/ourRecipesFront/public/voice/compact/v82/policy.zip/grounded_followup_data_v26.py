"""Independent Hebrew pairs for navigation after reports and scope contrasts."""
from pathlib import Path
import random

from explicit_nonstart_data_v24 import DATA as V24
from fresh_pairs_data_v15 import DATA as V15, canonical
from fresh_pairs_v15 import read, write
from grounded_progress_data_v25 import DATA as V25
from grounded_scope_data_v18 import DATA as V18
from preserve_reports_data_v20 import DATA as V20
from report_scope_data_v21 import DATA as V21
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/grounded-followup-data-v26-20261119.json'

RECIPES = (
    ('עוגת אמרנה ושקדים', ('לקלות את השקדים', 'לסנן דובדבני אמרנה', 'להקציף את הביצים', 'לשקול קמח אורז'),
     ('סיננתי את דובדבני האמרנה והקצפתי את הביצים. איך ממשיכים מפה?',
      'סיננתי את דובדבני האמרנה. איך ממשיכים מפה?'),
     ('השקדים קלויים רק מצד אחד. מה השלב הבא?', 'השקדים קלויים משני הצדדים. מה השלב הבא?'),
     ('״סיננתי את דובדבני האמרנה״ זה רק ציטוט. מה עכשיו?',
      'סיננתי את דובדבני האמרנה. מה עכשיו?')),
    ('קרם סלק ושעועית שחורה', ('למעוך שעועית שחורה', 'לקלף סלק', 'לסחוט תפוז דם', 'לתבל את הקרם'),
     ('קילפתי את הסלק וסחטתי את תפוז הדם. מה עליי לעשות עכשיו?',
      'קילפתי את הסלק. מה עליי לעשות עכשיו?'),
     ('עוד לא מעכתי את כל השעועית השחורה, רק שליש ממנה.',
      'עוד לא מעכתי את השעועית השחורה, אפילו לא שליש ממנה.'),
     ('מעכתי את השעועית השחורה. בעצם עוד לא מעכתי את השעועית השחורה.',
      'עוד לא מעכתי את השעועית השחורה. בעצם מעכתי את השעועית השחורה.')),
    ('סלט מלון ושעועית ים', ('לחתוך מלון', 'לשטוף שעועית ים', 'לערבב את הרוטב', 'לקצוץ נענע'),
     ('שטפתי את שעועית הים, וגם ערבבתי את הרוטב. מה הצעד הבא שלי?',
      'שטפתי את שעועית הים. מה הצעד הבא שלי?'),
     ('חתכתי את המלון, רק רבע ממנו.', 'חתכתי את המלון באופן מלא.'),
     ('נניח ששטפתי את שעועית הים. איך הייתי ממשיכה מכאן?',
      'שטפתי את שעועית הים. איך ממשיכים מכאן?')),
    ('כיסוני אפונה ותרד', ('לטגן את הכיסונים', 'למעוך את האפונה', 'ללוש את הבצק', 'למדוד תרד צעיר'),
     ('מעכתי את האפונה ולשתי את הבצק. מה כדאי לעשות?',
      'מעכתי את האפונה. מה כדאי לעשות?'),
     ('הכיסונים מטוגנים בצד אחד. איך ממשיכים?', 'הכיסונים מטוגנים בשני הצדדים. איך ממשיכים?'),
     ('בעוד שעה אטחן את זה. מה עכשיו?', 'מעכתי את האפונה. מה עכשיו?')),
    ('ריבה מחבושים ומישמש', ('לבשל חבושים', 'לפתוח את הצנצנת', 'להוסיף מחית מישמש', 'לקרר את הריבה'),
     ('פתחתי את הצנצנת והוספתי את מחית המישמש. מה לעשות עכשיו?',
      'פתחתי את הצנצנת. מה לעשות עכשיו?'),
     ('בישלתי את החבושים אבל רק חצי מהם.', 'בישלתי את החבושים עד הסוף.'),
     ('מה הלאה?', 'פתחתי את הצנצנת. מה הלאה?')),
    ('סופלה תפוח ופרג', ('לשקול פרג טחון', 'להמיס חמאה מלוחה', 'להוסיף תפוחים ירוקים', 'לאפות את הסופלה'),
     ('המסתי את החמאה המלוחה והוספתי את התפוחים הירוקים. איך להמשיך מכאן?',
      'המסתי את החמאה המלוחה. איך להמשיך מכאן?'),
     ('לא שקלתי את כל הפרג הטחון, רק קצת ממנו.', 'טרם שקלתי את הפרג הטחון, אפילו לא קצת ממנו.'),
     ('אני מתכוונת להמיס חמאה מלוחה בהמשך. מה הצעד הבא?',
      'המסתי את החמאה המלוחה. מה הצעד הבא?')),
)


def build():
    rows = []
    rng = random.Random(261119)
    for i, (name, sources, nav, amount, contrast) in enumerate(RECIPES):
        (a, b, c, _), ctx = fixture(rng, name, sources, i, 'fresh-v26')
        ctx['progress'].update({a: 'done', b: 'pending', c: 'partial'})
        pair(rows, ctx, 'navigation_0', nav,
             [response('next', [(b, 'done'), (c, 'done')]), response('next', [(b, 'done')])])
        intents = ['next','report','report','next','report','report']
        end = 'pending' if i in (1, 5) else 'done'
        pair(rows, ctx, 'degree_0', amount,
             [response(intents[i], [(a, 'partial')]), response(intents[i], [(a, end)])])
        contrast_labels = (
            (response('next'), response('next', [(b, 'done')])),
            (response('report', [(a, 'pending')]), response('report', [(a, 'done')])),
            (response('explain'), response('next', [(b, 'done')])),
            (response('next'), response('next', [(b, 'done')])),
            (response('next'), response('next', [(b, 'done')])),
            (response('next'), response('next', [(b, 'done')])),
        )
        pair(rows, ctx, 'contrast_0', contrast, contrast_labels[i])

    audit_new(rows, 36)
    prior = [r for split in read_native().values() for r in split] + train_new()
    for path in (V15, V16, V18, V20, V21, V24, V25):
        prior.extend(read(path))
    recipes = {r['input']['recipe']['name'] for r in prior}
    utterances = {canonical(r['input']['utterance']) for r in prior}
    if any(r['input']['recipe']['name'] in recipes or canonical(r['input']['utterance']) in utterances for r in rows):
        raise ValueError('V26 overlaps a known exact utterance or recipe name')
    return rows


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
