"""Resolve positional queries without using the active recipe title as an action mention."""
from recipe_text_responder import POSITION, simulate as previous


def simulate(row, proposal_text):
    request = row['input']
    title = request['recipe'].get('name')
    if title and title in request['utterance'] and POSITION.search(request['utterance']):
        utterance = request['utterance'].replace(title,' ')
        row = {**row,'input':{**request,'utterance':utterance}}
    return previous(row,proposal_text)
