"""Illustrate report scope in the existing Q4 decoding contract."""
from sparse_recipe_data_v4 import messages

EXAMPLES = """
דוגמאות ממתכון אחר. יש להעתיק מזהים רק מהמתכון הנוכחי.
כאשר a7 היא לסחוט תפוז:
״בעוד שעה אסחט תפוז. מה עכשיו?״ => {"intent":"next","facts":[],"clarify":[]}
״עדיין לא סחטתי תפוז. מה עכשיו?״ => {"intent":"next","facts":[{"action":"a7","status":"pending"}],"clarify":[]}
כאשר a2 היא לקלות בוטנים ו־a4 היא לערבב מרק:
״רק ציטטתי 'קליתי את הבוטנים'. את המרק ערבבתי בעצמי.״ => {"intent":"report","facts":[{"action":"a4","status":"done"}],"clarify":[]}
״אולי קליתי את הבוטנים. את המרק רק התחלתי לערבב.״ => {"intent":"report","facts":[{"action":"a4","status":"partial"}],"clarify":["a2"]}
"""


def illustrated_messages(row):
    system, request = messages(row)
    return [{**system, 'content': system['content'] + EXAMPLES}, request]
