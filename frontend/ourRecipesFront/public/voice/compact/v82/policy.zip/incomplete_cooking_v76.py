"""Ground explicit reports of incomplete cooking or toppings applied to part of a dish."""
import json
import re

from colloquial_evidence_v60 import decision
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import ingredient
from ingredient_alternatives_v75 import FRONT, process as previous
from recipe_ingredient_lists_v74 import list_keys
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

INCOMPLETE = re.compile(
    r'([א-ת ]+?) (?:עוד |עדיין )?לא (התבשל[הו]?|נאפתה|נאפה|נאפו|נצלה|נצלתה|נצלו|טוגן|טוגנה|טוגנו) '
    r'(?:לי )?(?:עד הסוף|לגמרי|מספיק)')
TOPPING = re.compile(r'(?:הוספתי|הוספנו|שמתי|שמנו) (?:רק )?על חלק'
                     r'(?: מה(?:מנה|תבנית|כמות|ירקות|חתיכות))?(?: לניסיון)? (.+)')
LEAD_ADD = re.compile(r'(?:השתמשתי ב|השתמשנו ב|שמתי |שמנו |הוספתי |הוספנו )(.+)')
BOUNDARY = re.compile(r'\s*[.;!]\s*|,?\s+ו(?=(?:הוספתי|הוספנו|שמתי|שמנו) )|,\s*(?:אבל )?|\s+אבל\s+')
UNASSERTED = re.compile(r'[?״"“”]|\b(?:אם|האם|כאילו|אולי|אילו|חשבתי|נאמר|אמרו|שאלו|הנחתי)\b')


def matches_cooking(slots, match):
    form = match[2]
    verb = ('לבשל' if form.startswith('התבשל') else 'לאפות' if form.startswith('נאפ')
            else 'לצלות' if form.startswith('נצל') else 'לטגן')
    obj = ingredient(match[1])
    return [a.key for a in slots if a.verb == verb and a.obj == obj]


def added_items(slots, phrase):
    keys = list_keys(slots, phrase)
    if keys is None:
        # Preserve recipe quantities when present. A descriptive "a little" can
        # otherwise be removed at an item boundary, never from inside its name.
        phrasing = re.sub(r'(^|,\s*|\s+ו)(?:מעט|קצת) ', r'\1', phrase)
        keys = list_keys(slots, phrasing)
    return keys


def lead_facts(slots, phrase):
    swap = FRONT.fullmatch(phrase)
    if swap:
        old, new = list_keys(slots, swap[1]), added_items(slots, swap[2])
        if old and new and not set(old) & set(new):
            return {**dict.fromkeys(old, 'pending'), **dict.fromkeys(new, 'done')}
    add = LEAD_ADD.fullmatch(phrase)
    keys = added_items(slots, add[1]) if add else None
    return dict.fromkeys(keys, 'done') if keys else {}


def scoped_amount(row):
    text = row['input']['utterance'].strip().rstrip('.!').strip()
    if not ('לא ' in text or 'על חלק' in text):
        return None
    slots = action_slots(row['input']['recipe']['actions'])
    if text.endswith('?'):
        question = INCOMPLETE.fullmatch(text.removeprefix('האם ').rstrip('?').strip())
        if question:
            keys = matches_cooking(slots, question)
            return [], decision(doubts=keys if len(keys) == 1 else [None])
    if any(p.search(text) for p in (UNASSERTED, DOUBT, MENTION, PRIOR_CONTEXT)):
        return None
    # Try the complete turn and then complete suffixes. Earlier commas may
    # belong to an ingredient list; they are not independent actions.
    for start in [0, *(m.end() for m in BOUNDARY.finditer(text))]:
        phrase = text[start:]
        incomplete = INCOMPLETE.fullmatch(phrase)
        topping = TOPPING.fullmatch(phrase)
        if incomplete:
            keys = matches_cooking(slots, incomplete)
            if len(keys) != 1:
                continue
        elif topping:
            keys = added_items(slots, topping[1])
            if not keys:
                continue
        else:
            continue
        lead = re.sub(r'\s+(?:אבל|ו)$', '', text[:start].rstrip(' ,.;!')).rstrip(' ,.;!')
        facts = lead_facts(slots, lead) if lead else {}
        if lead and not facts:
            # Keep prior handling of any unrelated clauses. The caller will
            # replace only explicitly grounded partial statuses.
            return keys, None
        facts.update(dict.fromkeys(keys, 'partial'))
        return keys, decision(facts.items())
    return None


def process(payload, raw):
    row = json.loads(payload)
    match = scoped_amount(row)
    if not match:
        return previous(payload, raw)
    keys, value = match
    if value is None:
        prior = json.loads(previous(payload, raw))
        accepted = json.loads(prior['accepted_text'])
        facts = {f['action']: f['status'] for f in accepted['facts']}
        facts.update(dict.fromkeys(keys, 'partial'))
        value = decision(facts.items(), doubts=[k for k in accepted['clarify'] if k not in keys])
    encoded = json.dumps(value, ensure_ascii=False)
    return json.dumps({**simulate(row, encoded), 'accepted_text': encoded,
                       'route': 'explicit_partial_scope'}, ensure_ascii=False)
