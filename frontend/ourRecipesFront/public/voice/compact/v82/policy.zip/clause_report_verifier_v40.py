"""Measure a clause-level report verifier with independent action evidence."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
from unittest.mock import patch

from fresh_pairs_v15 import digest, read, write
from grounded_scope_v18 import grounded_actions
from mention_scope_data_v39 import FRESH, ROOT, TRAIN, V28, V38_FRESH, V38_TRAIN
from report_question_study_v32 import fitted_scores
import report_verifier_v30 as base

PLAN = ROOT / 'verification/clause-report-plan-v40-20261119.json'
FREEZE = ROOT / 'verification/clause-report-freeze-v40-20261119.json'
LABELS = ('has_report', 'no_report')
CLAUSES = re.compile(r'(?:״[^״]*״|"[^"]*"|[^.;!?"״])+')
HOLDOUT_RECIPE_IDS = {f'v16-mentions-v39-train-{i}' for i in (2, 7)}


def action_clauses(row):
    request = row['input']
    by_action = {a['id']: [] for a in request['recipe']['actions']}
    for match in CLAUSES.finditer(request['utterance']):
        clause = match.group().strip()
        anchored = grounded_actions(clause, request)
        for action in anchored:
            by_action[action].append((clause, len(anchored) == 1))
    return {action: matches[0][0] for action, matches in by_action.items()
            if len(matches) == 1 and matches[0][1]}


def decisions(rows):
    result = []
    for row in rows:
        request = row['input']
        labels = {f['action']: f for f in row['expected']['facts']}
        sources = {a['id']: a['source'] for a in request['recipe']['actions']}
        for action, clause in action_clauses(row).items():
            fact = labels.get(action)
            result.append({'id': f'{row["id"]}/{action}', 'parent': row['id'], 'action': action,
                           'input': {**request, 'utterance': f'{clause}\nפעולה לבדיקה: {sources[action]}'},
                           'expected': {'facts': [fact] if fact else []}})
    return result


def groups():
    new = read(TRAIN)['mentions']
    validation = [r for r in new if r['input']['recipe']['id'] in HOLDOUT_RECIPE_IDS]
    fit = [r for r in new if r['input']['recipe']['id'] not in HOLDOUT_RECIPE_IDS]
    return {'training': decisions(read(V38_TRAIN)['contrast'] + fit),
            'calibration': decisions(validation), 'fresh':decisions(read(FRESH)),
            'v38_exposed':decisions(read(V38_FRESH)), 'broad_exposed':decisions(read(V28))}


def verify():
    for name, expected in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != expected:
            raise ValueError(f'Frozen V40 source changed: {name}')
    plan = read(PLAN)
    examples = groups()
    if plan['split_sha256'] != {k:base.data_digest(v) for k,v in examples.items()}:
        raise ValueError('Derived V40 data changed')
    return plan, examples


def train(model, destination):
    plan, sets = verify()
    split = {k: sets[k] for k in ('training', 'calibration')}
    with (patch.object(base, 'verify', lambda: (plan, split)), patch.object(base, 'LABELS', LABELS),
          patch.object(base, 'label', lambda row: int(not row['expected']['facts']))):
        base.run(model, destination)


def evaluate(fitted, output):
    import torch

    plan, sets = verify()
    torch.set_num_threads(plan['threads'])
    selected = {name:rows for name,rows in sets.items() if name != 'training'}
    fit, vectors = fitted_scores(fitted, selected, plan)
    calibration = base.calibrate(selected['calibration'], vectors['calibration'], plan)
    if calibration != fit['calibration']:
        raise ValueError('Local recalibration differs from the saved checkpoint proof')
    chosen = calibration['chosen']
    threshold = chosen['threshold'] if chosen else None
    coverage, raw, report = {}, [], {}
    originals = {'fresh':read(FRESH), 'v38_exposed':read(V38_FRESH), 'broad_exposed':read(V28)}
    for name,rows in originals.items():
        actions = {(d['parent'], d['action']) for d in sets[name]}
        pairs = Counter()
        for row in rows:
            true_facts = row['expected']['facts']
            pairs.update(true_facts=len(true_facts), true_facts_anchored=sum((row['id'], f['action']) in actions for f in true_facts))
            if name == 'fresh' and row['family'] in ('plan','quote','scenario'):
                pairs.update(mention_actions=1, mention_actions_anchored=(row['id'],row['focus']) in actions)
        coverage[name] = dict(pairs)
    for name,rows in selected.items():
        counts = Counter(cases=0, true_reports=0, false_vetoes=0, no_report=0, correct_vetoes=0)
        for row, vector in zip(rows, vectors[name], strict=True):
            true = bool(row['expected']['facts'])
            flag = threshold is not None and 1-vector[0] >= threshold
            counts.update(cases=1, true_reports=true, no_report=not true, false_vetoes=true and flag,
                          correct_vetoes=not true and flag)
            raw.append({'group':name,'id':row['id'],'parent':row['parent'],'action':row['action'],
                        'score':1-vector[0],'expected_report':true,'veto':flag})
        report[name] = dict(counts)
    checks = {'calibrated': chosen is not None, 'fresh_zero_real_reports_vetoed':report['fresh']['false_vetoes']==0,
              'fresh_minimum_no_reports_vetoed':report['fresh']['correct_vetoes']>=plan['minimum_fresh_no_reports'],
              'known_zero_real_reports_vetoed':all(report[n]['false_vetoes']==0 for n in ('v38_exposed','broad_exposed'))}
    write(output, {'coverage':coverage,'groups':report,'calibration':calibration,'checks':checks,
                   'diagnostic_gate_passed':all(checks.values()),'raw':raw,'checkpoint_sha256':fit['checkpoint_sha256']})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('fitted', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    train(args.source, args.fitted)
    evaluate(args.fitted, args.output)
