"""Ground reports in a recipe action whose source includes quantities or durations."""
from collections import Counter
import re

from explicit_nonstart_v24 import ENDING, NEGATIVE, WORD
from grounded_followup_v26 import action_forms, apply as v26, empty, fact, with_utterance
from grounded_progress_v25 import DOUBT, VERBS, object_word
from scoped_decode_v17 import compact, safe_parse

NUMBER = (r'(?:[0-9]+(?:[.,][0-9]+)?|אחת|אחד|שתי|שני|שלוש(?:ה)?|ארבע(?:ה)?|'
          r'חמש(?:ה)?|שש(?:ה)?|שבע(?:ה)?|שמונה|תשע(?:ה)?|עשר(?:ה)?|עשרים|שלושים|ארבעים|חמישים|שישים|חצי|רבע)')
UNIT = r'(?:כוס(?:ות)?|כף|כפות|כפית|כפיות|גרם|קילו(?:גרם)?|מיליליטר|ליטר|קורט)'
AMOUNT = re.compile(rf'^(?:{NUMBER}(?: {UNIT})?|{UNIT}) ')
DURATION = re.compile(rf' (?:(?:במשך )?{NUMBER} (?:שנייה|שניות|דקה|דקות|שעה|שעות)|במשך (?:שנייה|דקה|שעה))$')
FINAL_ONE = re.compile(r' (?:אחד|אחת)$')
EXTRA = {'לחמם': 'חיממתי', 'להפשיר': 'הפשרתי', 'לגרר': 'גיררתי', 'למזוג': 'מזגתי'}
PREPARATION = re.compile(r' (?:מרוסק(?:ת|ים|ות)?|קצו(?:ץ|צה|צים|צות)|מגורר(?:ת|ים|ות)?|טחונ(?:ה|ים|ות)|טחון)$')
LEAD = re.compile(r'^(?:(?:למען הסר ספק|ליתר ביטחון|אני חוזר[ת]? בי ממה שאמרתי),\s*|אצלי )')
DONE_LEAD = re.compile(r'^מבחינתי (?:זה הושלם|זה גמור):\s*')
PARTIAL = re.compile(r'^הספקתי רק להתחיל (?P<verb>[א-ת]+) (?P<object>[^,;]+), (?:נשאר|נותר) להשלים$')
QUOTE = re.compile(r'אני (?:רק )?מצטט[ת]? מישהו שאמר (?:"[^"]+"|״[^״]+״); לא אמרתי שביצעתי (?:זאת|את זה)')
CURRENT = re.compile(r'(?:עכשיו הפעולה היא|הפעולה הנוכחית היא) (.+)')
REFERENCE = re.compile(r'(?P<target>לגבי (?:זה|זאת), )?(?P<status>טרם התחלתי|עוד לא התחלתי)')
AMBIGUOUS = re.compile(r'(?:את הדבר ההוא עשיתי|הפעולה ההיא בוצעה|את זה כבר עשיתי)')
FUTURE = re.compile(r'בעוד (?:שעה|חצי שעה) א[א-ת]+ את (?:זה|זאת)\. (?:מה עכשיו|מה השלב הבא)\?')


def project_actions(row, unique_verbs=True):
    request = row['input']
    actions = request['recipe']['actions']
    counts = Counter(action['source'].split(' ', 1)[0] for action in actions)
    projected = []
    for action in actions:
        original = action['source'].strip().removesuffix('.')
        verb, _, obj = original.partition(' ')
        if not unique_verbs or counts[verb] == 1:
            obj = obj.removeprefix('את ')
            obj = FINAL_ONE.sub('', DURATION.sub('', obj))
            obj, quantified = AMOUNT.subn('', obj, count=1)
            if quantified:
                obj = PREPARATION.sub('', obj)
            projected.append({**action, 'source': f'{verb} {obj}' if obj else original})
        else:
            projected.append({**action, 'source': original})
    return {**row, 'input': {**request, 'recipe': {**request['recipe'], 'actions': projected}}}


def resolve_history(row, text):
    history = row['input']['history']
    if not history or history[-1]['role'] != 'assistant':
        return None
    last = history[-1]['content'].strip().removesuffix('.')
    if AMBIGUOUS.fullmatch(text) and last.startswith('הזכרנו שתי פעולות:') and 'לא ברור לאיזו' in last:
        return {**empty('clarify'), 'clarify': [None]}
    anchor = CURRENT.fullmatch(last)
    if not anchor or not REFERENCE.fullmatch(text):
        return None
    addressed = [ident for ident, verb, _, obj in action_forms(row)
                 if re.fullmatch(rf'{verb} (?:את )?{obj}', anchor[1])]
    return fact(addressed[0], 'pending') if len(addressed) == 1 else None


def plain_clauses(text):
    output = []
    for clause in text.split(';'):
        body = clause.strip().removeprefix('לעומת זאת ')
        body = LEAD.sub('', body)
        if body.startswith('קשה לי לזכור אם '):
            body = 'אני לא זוכר אם ' + body.removeprefix('קשה לי לזכור אם ')
        partial = PARTIAL.fullmatch(body)
        if partial and partial['verb'] in (VERBS | EXTRA):
            past = (VERBS | EXTRA)[partial['verb']]
            body = f'{past} {partial["object"]} חלקית'
        output.append(body)
    return '; '.join(output)


def extra_report(row, clause):
    cue = re.match(DOUBT, clause)
    body = clause[cue.end():] if cue else clause
    matches = []
    for action in row['input']['recipe']['actions']:
        verb, _, tail = action['source'].partition(' ')
        obj = [word for word in tail.split() if word != 'את']
        if verb not in EXTRA or not obj or not all(WORD.fullmatch(word) for word in obj):
            continue
        past = EXTRA[verb]
        named = '(?:את )?' + ' '.join(map(object_word, obj))
        patterns = {
            'pending': rf'{NEGATIVE}(?:{past}|התחלתי {verb})(?: בכלל)? {named}{ENDING}',
            'partial': rf'{past} {named} (?:רק )?חלקית',
            'done': rf'(?:כבר )?{past} {named}',
        }
        matches.extend((action['id'], status) for status, pattern in patterns.items()
                       if re.fullmatch(pattern, body))
    if len(matches) != 1:
        return None
    ident, status = matches[0]
    return {**empty('clarify'), 'clarify': [ident]} if cue else fact(ident, status)


def extra_clauses(row):
    parts = row['input']['utterance'].split('; ')
    if len(parts) > 2:
        return None
    facts, clarify = [], []
    for clause in parts:
        text, grounded = v26(with_utterance(row, clause), '{}')
        interpretation = safe_parse(text, row) if grounded else extra_report(row, clause)
        if not interpretation or interpretation['intent'] not in ('report', 'clarify'):
            return None
        facts.extend(interpretation['facts'])
        clarify.extend(interpretation['clarify'])
    ids = [item['action'] for item in facts] + clarify
    if len(set(ids)) != len(ids):
        return None
    return {'intent': 'report' if facts else 'clarify', 'facts': facts, 'clarify': clarify}


def ambiguous_omission(row, utterance):
    if any(mark in utterance for mark in (';', '?')):
        return None
    all_actions = project_actions(with_utterance(row, utterance), unique_verbs=False)
    recipe = all_actions['input']['recipe']
    projected = recipe['actions']
    counts = Counter(action['source'] for action in projected)
    if not any(count > 1 for count in counts.values()):
        return None
    matches = []
    for action in projected:
        if counts[action['source']] < 2:
            continue
        single = {**all_actions, 'input': {**all_actions['input'],
                                         'recipe': {**recipe, 'actions': [action]}}}
        text, grounded = v26(single, '{}')
        found = safe_parse(text, single) if grounded else extra_report(single, utterance)
        if found and found['intent'] == 'report' and len(found['facts']) == 1:
            matches.append(action['id'])
    return {**empty('clarify'), 'clarify': [None]} if len(matches) > 1 else None


def apply(row, raw):
    previous, used = v26(row, raw)
    if used:
        return previous, True
    projected = project_actions(row)
    original = ' '.join(row['input']['utterance'].strip().removesuffix('.').split())
    if QUOTE.fullmatch(original):
        return compact(empty('other'), row), True
    if FUTURE.fullmatch(original):
        return compact(empty('next'), row), True
    if grounded := resolve_history(projected, original):
        return compact(grounded, row), True
    initial = DONE_LEAD.match(original)
    text = original[initial.end():] if initial else original
    name = row['input']['recipe']['name']
    if text.startswith(f'במתכון {name}, '):
        text = text.removeprefix(f'במתכון {name}, ')
    text = re.sub(r'מה עושים מכאן\?$', 'איך ממשיכים מכאן?', text)
    normalized = with_utterance(projected, plain_clauses(text))
    answer, grounded = v26(normalized, '{}')
    value = safe_parse(answer, row) if grounded else extra_clauses(normalized)
    if not value:
        value = ambiguous_omission(row, normalized['input']['utterance'])
    if not value:
        return previous, False
    if initial:
        if not value['facts'] or value['clarify'] or any(f['status'] != 'done' for f in value['facts']):
            return previous, False
    return compact(value, row), True
