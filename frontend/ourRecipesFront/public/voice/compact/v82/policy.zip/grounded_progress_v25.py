"""Recover complete, grounded progress interpretations from explicit recipe clauses."""
import re

from explicit_nonstart_v24 import ENDING, NEGATIVE, PAST, WORD, apply as previous
from scoped_decode_v17 import compact

VERBS = PAST | {
    'להבריש': 'הברשתי', 'להמיס': 'המסתי', 'להשרות': 'השריתי', 'להקציף': 'הקצפתי',
    'להרתיח': 'הרתחתי', 'לכסות': 'כיסיתי', 'ללוש': 'לשתי', 'למרוח': 'מרחתי',
    'למעוך': 'מעכתי', 'לנקות': 'ניקיתי', 'לסנן': 'סיננתי', 'לפתוח': 'פתחתי',
    'לצקת': 'יצקתי', 'לקלות': 'קליתי', 'לקרר': 'קיררתי', 'לרסק': 'ריסקתי',
    'לשבור': 'שברתי', 'לתבל': 'תיבלתי',
}
PASSIVE = {
    'לאפות': 'אפוי(?:ה|ים|ות)?', 'לבשל': 'מבושל(?:ת|ים|ות)?',
    'לחתוך': 'חתו(?:ך|כה|כים|כות)', 'לקצוץ': 'קצו(?:ץ|צה|צים|צות)',
    'לשטוף': 'שטו(?:ף|פה|פים|פות)',
}
AMOUNT = r'(?:רק )?(?:חצי|חלק|קצת|מעט|שליש|רבע)'
DOUBT = (
    r'^(?:אולי |ייתכן ש|יתכן ש|יכול(?:ה)? להיות ש|נדמה לי ש'
    r'|אני לא (?:בטוח[ה]?|זוכר[ת]?|יודע[ת]?) אם |לא הייתי בטוח[ה]? אם )'
)
PLAN_START = (
    r'(?:(?:בהמשך|מאוחר יותר|יותר מאוחר) )?'
    r'(?:אני (?:מתכנן|מתכננת|מתכוון|מתכוונת)|יש לי כוונה) '
)
PLAN_END = r'(?: (?:אולי )?(?:בהמשך(?: היום)?|מאוחר יותר|יותר מאוחר|מחר))?'
CHECK = r'(?:בדקתי|וידאתי|ווידאתי) (?:ו?אכן |וכן |וגיליתי ש)'
CONFIRM = re.compile(rf',\s*(?:אבל )?{CHECK}')
SPLIT = re.compile(r';\s*|,\s*(?=(?:אבל |וגם |ואת )(?!' + CHECK + r'))|\s+(?=וגם |ואת )')
START_LINK = re.compile(r'^(?:אבל |וגם |ו(?=את ))')


def object_word(word):
    base = word.removeprefix('ה') if len(word) >= 4 else word
    exact = {word, base, 'ה' + base}
    if base.startswith('ו'):
        exact.add('הו' + base)
    return '(?:' + '|'.join(re.escape(value) for value in sorted(exact)) + ')'


def action_patterns(source):
    verb, _, tail = source.partition(' ')
    nouns = [word for word in tail.split() if word != 'את']
    if verb not in VERBS or not nouns or not all(WORD.fullmatch(word) for word in nouns):
        return None
    obj = ' '.join(map(object_word, nouns))
    past = VERBS[verb]
    named = rf'(?:את )?{obj}'
    start = rf'(?:{past}|התחלתי {verb})'
    patterns = {
        'pending': (
            rf'(?:אני )?{NEGATIVE}{start}(?: בכלל)? {named}{ENDING}',
            rf'{named} (?:אני )?{NEGATIVE}{start}{ENDING}',
        ),
        'partial': (
            rf'(?:אני )?{past} {AMOUNT} (?:מן |מ){obj}(?: ועדיין לא סיימתי)?',
            rf'(?:אני )?{past} {named} (?:רק )?חלקית',
            rf'{named} {past} (?:רק )?חלקית',
        ),
        'done': (
            rf'(?:אני )?(?:כבר )?{past} {named}(?: (?:כבר|כולו|כולה|לגמרי|במלוא[וה]))?',
            rf'{named} (?:כבר )?{past}(?: (?:כבר|לגמרי))?',
        ),
        'planned': (rf'{PLAN_START}{verb} {named}{PLAN_END}',),
    }
    if verb in PASSIVE:
        patterns['done'] += (rf'{obj} כבר {PASSIVE[verb]}',)
    return past, patterns


def recognize(text, actions):
    doubt = re.match(DOUBT, text)
    if doubt:
        text = text[doubt.end():]
    matches = []
    for ident, past, patterns in actions:
        for status, alternatives in patterns.items():
            if doubt and status == 'planned':
                continue
            if any(re.fullmatch(pattern, text) for pattern in alternatives):
                matches.append((ident, 'uncertain' if doubt else status, past))
    return matches[0] if len(matches) == 1 else None


def resolve_clause(text, actions):
    confirmation = CONFIRM.search(text)
    if not confirmation:
        return recognize(text, actions)
    initial = re.sub(r'^(?:קודם |בהתחלה )?חשבתי ש', '', text[:confirmation.start()])
    first = recognize(initial, actions)
    if not first or first[1] != 'uncertain':
        return None
    followup = text[confirmation.end():]
    second = recognize(followup, actions)
    ident, _, past = first
    if (second and second[:2] == (ident, 'done')) or re.fullmatch(rf'{past}(?: אות(?:ו|ה|ם|ן))?', followup):
        return ident, 'done', past
    return None


def evidence(row):
    recipe = row['input']['recipe']
    actions = []
    for action in recipe['actions']:
        parsed = action_patterns(action['source'])
        if parsed:
            actions.append((action['id'], *parsed))
    utterance = ' '.join(row['input']['utterance'].strip().removesuffix('.').split())
    parts = SPLIT.split(utterance)
    if not 1 <= len(parts) <= 2:
        return None
    results = [resolve_clause(START_LINK.sub('', part), actions) for part in parts]
    if any(result is None for result in results):
        return None
    if len({entry[0] for entry in results}) != len(results):
        return None
    facts, clarify, planned = [], [], []
    for ident, status, _ in results:
        if status == 'uncertain':
            clarify.append(ident)
        elif status == 'planned':
            planned.append(ident)
        else:
            facts.append({'action': ident, 'status': status})
    if planned:
        return {'intent': 'other', 'facts': [], 'clarify': []} if len(results) == 1 else None
    return {'intent': 'report' if facts else 'clarify', 'facts': facts, 'clarify': clarify}


def apply(row, raw):
    grounded = evidence(row)
    if grounded is not None:
        return compact(grounded, row), True
    final, _ = previous(row, raw)
    return final, False
