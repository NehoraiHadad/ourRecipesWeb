"""Suppress a factual update when the whole utterance is explicitly non-factual."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

from fresh_pairs_v15 import digest,measurements,read,write
from grounded_scope_v18 import grounded_actions
from preserve_reports_data_v20 import DATA as V20_DATA
from preserve_reports_v20 import measure as v20_measure,new_inputs,read_group,replay_groups
from report_scope_data_v21 import DATA,ROOT,build
from scoped_decode_v17 import NEXT,SPLIT,compact,safe_parse
from sparse_recipe_v3 import aggregate,score

PLAN=ROOT/'verification/report-scope-plan-v21-20261119.json'
MANIFEST=ROOT/'verification/report-scope-freeze-v21-20261119.json'
V20_RAW=ROOT/'verification/preserve-reports-raw-v20-20261119.jsonl'
UNCERTAIN=re.compile(r'^\s*(?:ייתכן|יתכן|אולי|נדמה לי ש|יכול(?:ה)? להיות|אני לא (?:בטוח[הת]?|זוכר[תה]?) אם)')
RESOLVED=re.compile(r'בכל זאת|לעומת זאת|עם זאת|מצד שני|במקביל|בנפרד|בדקתי|וידאתי|ווידאתי|אכן|התברר|בוודאות|(?:עכשיו|כעת) (?:אני )?(?:יודע[ת]?|בטוח[ה]?)')
SCENARIO=re.compile(r'^\s*(?:נניח ש|אילו |לו )')
FUTURE=re.compile(r'^\s*(?:(?:מאוחר יותר|יותר מאוחר|בהמשך)\s+)?'
                  r'(?:אני (?:מתכוון|מתכוונת|מתכנן|מתכננת)|יש לי כוונה)\s+')
QUESTION=re.compile(r'(?:[,.;!?]\s*|\s+)(?=(?:מה|איך|איזה|איזו)\s+)')
CONDITIONAL=re.compile(r'\b(?:היה|היו|הייתי|הייתה)\b')


def one_claim(text):
    body=text.strip(' .,?!')
    return (bool(body) and not re.search(r'[:;!?]|[״"]',body) and not RESOLVED.search(body)
            and len([p for p in SPLIT.split(body) if p.strip()])==1)


def request_and_question(text):
    parts=QUESTION.split(text.strip(),maxsplit=1)
    return (parts[0],parts[1]) if len(parts)==2 else (parts[0],None)


def revise(row,raw):
    parsed=safe_parse(raw,row)
    if not parsed or not parsed['facts']:
        return raw,'unchanged'
    request=row['input']
    text=request['utterance']
    claim,question=request_and_question(text)
    if not one_claim(claim):
        return raw,'unchanged'
    grounded=grounded_actions(claim,request)
    if not grounded&{f['action'] for f in parsed['facts']}:
        return raw,'unchanged'
    if SCENARIO.search(claim) and question and CONDITIONAL.search(question):
        return compact({'intent':'explain','facts':[],'clarify':[]},row),'hypothetical'
    if FUTURE.search(claim) and (question is None or NEXT.search(question)):
        return compact({'intent':'next' if question else 'other','facts':[],'clarify':[]},row),'planned'
    if (UNCERTAIN.search(claim) and question is None and not parsed['clarify'] and len(parsed['facts'])==1):
        return compact({'intent':'clarify','facts':[],'clarify':[parsed['facts'][0]['action']]},row),'uncertain'
    return raw,'unchanged'


def verify():
    for name,sha in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name)!=sha:
            raise ValueError(f'Changed V21 freeze: {name}')
    if read(DATA)!=build():
        raise ValueError('V21 data differs from author specification')


def known():
    previous=read_group(V20_RAW)
    specs={g:(rows,paired) for g,rows,paired,_ in replay_groups()}
    specs['v20_challenge']=(read(V20_DATA),True)
    for group,(rows,paired) in specs.items():
        name='fresh' if group=='v20_challenge' else group
        yield group,rows,paired,previous[name]


def measure(rows,baseline,paired):
    outputs=[]
    transitions=Counter()
    for row,record in zip(rows,baseline,strict=True):
        if row['id']!=record['id']:
            raise ValueError('Study response order changed')
        text,kind=revise(row,record['text'])
        a,b=score(row,record['text']),score(row,text)
        transitions.update(fixed=not a['exact'] and b['exact'],broken=a['exact'] and not b['exact'],
                           wrong_no_report_removed=row['critical_no_facts'] and bool(a['wrong_facts']) and not b['wrong_facts'])
        outputs.append({'id':row['id'],'v20':record['text'],'text':text,'route':kind})
    def stats(values):
        return measurements(rows,values) if paired else aggregate(rows,[r['text'] for r in values])[0]
    return {'v20':stats(baseline),'v21':stats(outputs),'transitions':dict(transitions)},outputs


def decide(results,raw,regression,plan):
    idx={r['id']:(r,p) for r,p in zip(regression,raw['regression'],strict=True)}
    bugs={k:score(idx[k][0],idx[k][1]['text'])['exact'] for k in plan['known_bug_ids']}
    def metric(g,a):
        v=results[g][a]
        return v.get('overall',v)
    a,b=(metric('fresh',a) for a in ('v20','v21'))
    checks={'legacy_false_reports_fixed':all(bugs.values()),
            'fresh_false_reports_halved':2*b['critical_wrong_fact_cases']<=a['critical_wrong_fact_cases'],
            'fresh_wrong_fact_safety':b['cases_with_wrong_facts']<=a['cases_with_wrong_facts'],
            'fresh_exact_retained':b['exact']>=a['exact'],
            'replay_exact_retained':all(metric(g,'v21')['exact']>=metric(g,'v20')['exact'] for g in results if g!='fresh'),
            'replay_false_reports_not_added':all(metric(g,'v21')['critical_wrong_fact_cases']
                                                 <=metric(g,'v20')['critical_wrong_fact_cases'] for g in results if g!='fresh')}
    return {'passes_quality_gate':all(checks.values()),'checks':checks,'legacy_reproductions':bugs,
            'additional_model_calls':0,'product_promotion':False}


def run(model_dir,out):
    verify()
    plan=read(PLAN)
    out.mkdir(parents=True,exist_ok=False)
    results,raw={},{}
    reg=None
    for group,rows,paired,baseline in known():
        results[group],raw[group]=measure(rows,baseline,paired)
        if group=='regression':
            reg=rows
    write(out/'known-replay.json',results)
    cases=read(DATA)
    baseline,work=new_inputs(cases,model_dir,out,plan)
    _,v20=v20_measure(cases,baseline,True)
    write(out/'fresh-v20.json',v20)
    results['fresh'],raw['fresh']=measure(cases,v20,True)
    write(out/'raw.json',raw)
    write(out/'study.json',{'study':plan['study'],'groups':results,'decision':decide(results,raw,reg,plan),
                            'work':work})


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('model_dir',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    run(args.model_dir,args.output)
