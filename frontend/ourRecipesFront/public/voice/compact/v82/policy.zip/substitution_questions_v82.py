"""Answer substitution questions from the active recipe and isolate any reported work."""
import json
import re

from colloquial_evidence_v60 import decision
from cooking_progress_v81 import process as previous
from turn_evidence_v58 import MENTION, PAST, PRIOR_CONTEXT, simulate

QUESTION_START = re.compile(
    r'(?<![\w])ו?(?:האם|אפשר|ניתן|מותר|יש|איזה|איזו|אילו|מה|במה|איך|'
    r'אפשרי|שווה|כדאי|את חושבת|אתה חושב)\b')
SUBSTITUTE = re.compile(
    r'תחליפ|תחליף|חלופ[הות]|אלטרנטיב|במקום|להחליף|להמיר|כתחליף|'
    r'ש?(?:י|ת)תאי[םמו]|ש?(?:[ית]ו?כל|יכול)[א-ת]* להתאים|ש?מתאי[םא-ת]* למתכון|'
    r'(?:להשתמש ב|לקנות |אפשר (?:גם )?עם )[^.!?]*(?:קנוי[א-ת]*|מוכ(?:ן|נה|נים|נות)\b)|'
    r'(?:קנוי[א-ת]*|מוכ(?:ן|נה|נים|נות))[^.!?]*(?:יעבוד|זה בסדר|אפשר להשתמש)')
REPORT_VERBS = sorted(set(PAST.values()) | {'התחלתי', 'סיימתי', 'החלפתי', 'השתמשתי', 'שמתי',
                                             'עשיתי', 'שמנו', 'הוספנו', 'רידדנו'})
REPORT = re.compile(r'^(?:(?:ו?אני|אנחנו|כבר|בינתיים|קודם|עכשיו|רק|עדיין|עוד|לא)\s+)*ו?(?:'
                    + '|'.join(map(re.escape, REPORT_VERBS)) + r')\b')
# Match a named option in an explicit instruction. Quote the instruction verbatim,
# including restrictions or negation, rather than inferring equivalence.
OPTION = re.compile(r'\b(?:או |(?:גם )?(?:אפשר|ניתן|מותר|אסור) (?:גם )?להשתמש (?:גם )?ב|'
                    r'(?:אפשר|ניתן) להחליף (?:את )?[^,.!?]+? ב)([^,.!?;()]+)')
OPEN_TARGET = re.compile(r'^(?:האם )?(?:יש (?:תחליף|חלופה) ל|'
                         r'(?:במה|איך) (?:אפשר )?להחליף (?:את )?)([א-ת ]+)[?.!]*$')
LIST_INGREDIENT = re.compile(r'(?:להוסיף|לשים|למרוח|למלא|לתבל|להשתמש) (?:את )?([^,.;]+)')
SWAP_INGREDIENT = re.compile(r'(?:אפשר|ניתן) להחליף (?:את )?(.+?) ב')
NO_INFO = 'בהוראות שיש לי אין מספיק מידע כדי לקבוע אם התחליף מתאים.'


def question_span(sentence):
    for start in QUESTION_START.finditer(sentence):
        before = sentence[:start.start()].rstrip()
        if before.endswith(('אי', 'לא', 'שאי')):
            continue
        tail = sentence[start.start():]
        if (re.match(r'ו?יש (?:לי|לנו) ', tail) and '?' not in tail and
                not re.search(r'שיתאי|שיוכל|שיכול', tail)):
            continue
        if SUBSTITUTE.search(tail):
            return start.start()
    if sentence.endswith('?') and SUBSTITUTE.search(sentence):
        # A comma can mark the start of an elliptical question after a report.
        comma = sentence.rfind(',')
        if comma >= 0 and SUBSTITUTE.search(sentence[comma + 1:]):
            return comma + 1
        if comma >= 0 and QUESTION_START.search(sentence[comma + 1:]):
            return None
        if not REPORT.match(sentence):
            return 0
    return None


def recipe_answer(question, actions):
    requested = OPEN_TARGET.fullmatch(question.strip())
    matches = []
    for action in actions:
        for option in OPTION.finditer(action['source']):
            if option[0].startswith('או ') and not action['source'].startswith(
                    ('להוסיף ', 'לשים ', 'להשתמש ', 'למלא ', 'לתבל ', 'למרוח ')):
                continue
            words = re.findall(r'[א-ת]+', option[1])
            if not words:
                continue
            phrase = ' '.join(map(re.escape, words))
            if re.search(r'(?<![א-ת])[ובלהמ]{0,2}' + phrase + r'(?![א-ת])', question):
                matches.append(action)
                break
            if requested:
                original = (LIST_INGREDIENT.fullmatch(action['source'][:option.start()].strip())
                            if option[0].startswith('או ') else SWAP_INGREDIENT.match(option[0]))
                if original and original[1].removeprefix('ה') == requested[1].strip().removeprefix('ה'):
                    matches.append(action)
                    break
    if len(matches) == 1:
        source, = matches
        return f'בהוראות כתוב ״{source["source"].strip()}״.', [source['id']]
    return NO_INFO, []


def process(payload, raw):
    row = json.loads(payload)
    req = row['input']
    text = req['utterance']
    if not SUBSTITUTE.search(text):
        return previous(payload, raw)
    questions, reports = [], []
    for match in re.finditer(r'[^.!?;…]+[.!?;…]*', text):
        sentence = match[0].strip()
        start = question_span(sentence)
        if start is not None:
            questions.append(sentence[start:])
        # A report before the question, or in a separate sentence, is processed
        # on its own. Never give it the encoder proposal for the full question.
        prefix = sentence if start is None else sentence[:start]
        prefix = re.sub(r'(?:[,\s]+(?:אבל|ורציתי לשאול|ורציתי לדעת))?[,\s]+$', '', prefix)
        if prefix and not prefix.endswith('?') and REPORT.match(prefix):
            reports.append(prefix.rstrip('.!;…'))
    if not questions:
        return previous(payload, raw)

    accepted = json.dumps(decision(intent='explain'), ensure_ascii=False)
    if reports and not (MENTION.search(text) or PRIOR_CONTEXT.search(text)):
        scoped = {**row, 'input': {**req, 'utterance': '. '.join(reports)}}
        neutral = json.dumps(decision())
        evidence = json.loads(previous(json.dumps(scoped, ensure_ascii=False), neutral))
        accepted = evidence['accepted_text']
    result = simulate(row, accepted)
    answer, sources = recipe_answer(' '.join(questions), req['recipe']['actions'])
    if result['writes'] or result['clarify']:
        answer = result['reply'] + ' ' + answer
    result.update(reply=answer, reply_source_ids=list(dict.fromkeys(
        [w['action'] for w in result['writes']] + [c for c in result['clarify'] if c] + sources)),
        route='substitution_question', accepted_text=accepted)
    return json.dumps(result, ensure_ascii=False)
