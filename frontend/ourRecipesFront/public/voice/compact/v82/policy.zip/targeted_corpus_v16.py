"""Generate/train only on new synthetic scope and reference pairs; hold out different recipes."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import random

from fresh_pairs_data_v15 import canonical
from semantic_supervision_data_v12 import read_native
from sparse_recipe_v3 import validate

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/targeted-corpus-data-v16-20261118.json'
FRESH = ROOT / 'verification/targeted-corpus-fresh-v16-20261118.json'
TRAIN_RECIPES = [
    ('קציצות חומוס', [('למעוך את החומוס','מעכתי את החומוס'),('לקצוץ את הכוסברה','קצצתי את הכוסברה'),('לערבב את הטחינה עם העיסה','ערבבתי את הטחינה עם העיסה'),('ליצור קציצות','יצרתי קציצות')]),
    ('פשטידת כרישה', [('לשטוף את הכרישה','שטפתי את הכרישה'),('לפרוס את תפוחי האדמה','פרסתי את תפוחי האדמה'),('לגרר את הגבינה','גיררתי את הגבינה'),('לשמן את התבנית','שימנתי את התבנית')]),
    ('אטריות ברוטב בוטנים', [('לדלל את חמאת הבוטנים','דיללתי את חמאת הבוטנים'),('לגרר את הג׳ינג׳ר','גיררתי את הג׳ינג׳ר'),('לסנן את האטריות','סיננתי את האטריות'),('לקצוץ את הבצל הירוק','קצצתי את הבצל הירוק')]),
    ('מאפינס אוכמניות', [('לנפות את הקמח','ניפיתי את הקמח'),('לשטוף את האוכמניות','שטפתי את האוכמניות'),('לערבב את הבלילה','ערבבתי את הבלילה'),('למלא את השקעים','מילאתי את השקעים')]),
    ('שיפודי טופו', [('לייבש את הטופו','ייבשתי את הטופו'),('לחתוך את הטופו לקוביות','חתכתי את הטופו לקוביות'),('לטרוף את המרינדה','טרפתי את המרינדה'),('להשחיל את הקוביות','השחלתי את הקוביות')]),
    ('סלט תפוזים ושומר', [('לקלף את התפוזים','קילפתי את התפוזים'),('לפרוס את השומר','פרסתי את השומר'),('לקלות את השקדים','קליתי את השקדים'),('לסחוט מיץ תפוזים','סחטתי מיץ תפוזים')]),
    ('ממרח פלפלים קלויים', [('להוציא את גרעיני הפלפלים','הוצאתי את גרעיני הפלפלים'),('לקלף את הפלפלים','קילפתי את הפלפלים'),('לכתוש את השום','כתשתי את השום'),('לטחון את התערובת','טחנתי את התערובת')]),
    ('פודינג אורז וקוקוס', [('לשטוף את האורז','שטפתי את האורז'),('לחמם את חלב הקוקוס','חיממתי את חלב הקוקוס'),('להוסיף את הסוכר','הוספתי את הסוכר'),('לקלות את שבבי הקוקוס','קליתי את שבבי הקוקוס')]),
]
# Six fresh fixtures. Each includes two mixed-clause pairs, one nonreport pair,
# an utterance repeated with different history, and one uncertainty or status pair.
FRESH_RECIPES = [
 ('מרק אפונה ונענע', ('להשרות את האפונה', 'לקצוץ את הנענע', 'למדוד מים לסיר', 'לטחון את המרק'),
  ('האפונה הושרתה, ואת הנענע קצצתי.', 'אני לא סגור על ההשריה של האפונה, אבל את הנענע קצצתי.'),
  ('את המים כבר מדדתי. הנענע קצוצה.', 'את המים כבר מדדתי. לגבי הנענע, יכול להיות שאני רק חושב שקצצתי אותה.'),
  ('מדדתי מים לסיר. מה השלב הבא מכאן?', 'אמרתי שעוד מעט אמדוד מים לסיר. מה השלב הבא כרגע?'),
  'סיימתי עם מה שדיברנו עליו.', ('השריתי את כל האפונה.', 'לדעתי השריתי את האפונה, אבל אני לא מצליח להיזכר בוודאות.', 'uncertain')),
 ('פטריות ממולאות', ('להפריד את רגלי הפטריות', 'לגרר את הפרמזן', 'למלא את הפטריות', 'לפזר פירורי לחם'),
  ('רגלי הפטריות כבר בחוץ, ואת הפרמזן כבר גיררתי.', 'אם הרגליים הוצאו אני לא זוכרת. מה שאני יודעת זה שגיררתי את הפרמזן.'),
  ('גיררתי את הפרמזן ואז מילאתי את הפטריות.', 'מילאתי את הפטריות. לגבי גירור הפרמזן אני לא בטוחה שעשיתי את זה.'),
  ('מילאתי את הפטריות, מה עכשיו?', '״למלא את הפטריות״ זה רק הטקסט שאני מקריא. מה עכשיו?'),
  'המשימה שהזכרת גמורה.', ('הפרדתי את כל רגלי הפטריות.', 'הפרדתי את הרגליים רק מחלק מהפטריות.', 'partial')),
 ('גרנולה ביתית', ('למדוד את שיבולת השועל', 'לקצוץ את האגוזים', 'לערבב את הדבש בתערובת', 'לפרוס נייר אפייה'),
  ('את השיבולת מדדתי; את האגוזים קצצתי לפני כן.', 'אני מנסה להיזכר אם מדדתי שיבולת שועל. האגוזים כבר קצוצים אצלי.'),
  ('קצצתי את האגוזים וערבבתי את הדבש בתערובת.', 'הדבש עורבב. אין לי דרך לדעת עכשיו אם קצצתי גם את האגוזים.'),
  ('ערבבתי את הדבש בתערובת. מה בא אחרי זה?', 'אחרי השיחה אערבב את הדבש בתערובת. מה בא עכשיו?'),
  'טיפלתי בזה עד הסוף.', ('את הכמות של שיבולת השועל כבר מדדתי.', 'אולי כבר מדדתי שיבולת שועל, ואולי זה היה במתכון אחר.', 'uncertain')),
 ('פיתות במחבת', ('למדוד את הקמח', 'ללוש את הבצק', 'לחלק את הבצק לכדורים', 'לחמם את המחבת'),
  ('מדדתי את הקמח ולשתי את הבצק.', 'את הלישה סיימתי. על המדידה של הקמח אני לא יכול להעיד כרגע.'),
  ('לשתי את הבצק וגם חילקתי אותו לכדורים.', 'לגבי הלישה אין לי ודאות. את הבצק לכדורים כבר חילקתי.'),
  ('חילקתי את הבצק לכדורים. מה הצעד הבא?', 'אני קוראת מרשימת המשימות ״לחלק את הבצק לכדורים״. מה הצעד הבא?'),
  'אפשר לסמן שזה הושלם.', ('מדדתי את כל הקמח.', 'עדיין לא מדדתי בכלל את הקמח.', 'pending')),
 ('סלסת תירס', ('לסנן את התירס', 'לקצוץ את הפלפל', 'לסחוט את הליים', 'לערבב את הסלסה'),
  ('סיננתי את התירס וקצצתי את הפלפל.', 'לא מצליחה לקבוע אם התירס סונן או שנשאר בקופסה. את הפלפל קצצתי.'),
  ('הפלפל קצוץ, והליים כבר סחוט.', 'על קיצוץ הפלפל אני לא מוכנה להתחייב. את הליים סחטתי.'),
  ('סחטתי את הליים. מה עושים אחרי זה?', 'יש לי תוכנית לסחוט את הליים בהמשך. מה עושים כרגע?'),
  'מה שסיכמנו עליו כבר נעשה.', ('סיננתי את כל התירס.', 'יש מצב שסיננתי את התירס, אבל אני ממש לא זוכר.', 'uncertain')),
 ('קינוח אגסים', ('לקלף את האגסים', 'לפרוס את האגסים', 'למדוד את הסילאן', 'לכתוש את הפיסטוקים'),
  ('קילפתי את האגסים ואז פרסתי אותם.', 'פרסתי את האגסים. לא יכולה לומר בוודאות אם קילפתי אותם.'),
  ('פרסתי את האגסים ומדדתי את הסילאן.', 'מדדתי את הסילאן בוודאות. לגבי פריסת האגסים חסר לי זיכרון ברור.'),
  ('מדדתי את הסילאן. מה השלב הבא?', 'גם אם אכתוב כאן ״למדוד את הסילאן״, זאת רק הצעה. מה השלב הבא?'),
  'זהו, את זה גמרתי.', ('קילפתי את האגסים כולם.', 'קילפתי כמה אגסים אבל עוד נשאר לקלף.', 'partial')),
]


def response(intent, reports=(), clarify=()):
    return {'intent': intent, 'facts': [{'action':a,'status':s} for a,s in reports], 'clarify':list(clarify)}


def fixture(rng, name, actions, idx, group):
    ids = rng.sample([f'a{i}' for i in range(10)], 4)
    recipe = {'id':f'v16-{group}-{idx}', 'version':'source-1', 'name':name,
              'actions':[{'id':a,'source':s,'step':j} for j,(a,s) in enumerate(zip(ids,actions,strict=True))]}
    return ids, {'recipe':recipe,'progress':{a:rng.choice(['done','partial','pending']) for a in ids},
                 'currentStep':rng.randrange(4)}


def pair(rows, fixture, name, texts, outputs, histories=([],[])):
    for i,(text,output,h) in enumerate(zip(texts,outputs,histories,strict=True)):
        request = {**fixture,'history':h,'utterance':text}
        rows.append({'id':f'{fixture["recipe"]["id"]}-{name}-{i}', 'pair':f'{fixture["recipe"]["id"]}-{name}',
                     'variant':i, 'family':name.split('_')[0], 'input':request,
                     'expected':validate(output,request), 'critical_no_facts':not output['facts']})


def train_new():
    rows=[]
    rng=random.Random(161818)
    for i,(name, actions) in enumerate(TRAIN_RECIPES):
        sources,past=zip(*actions,strict=True)
        ids,context=fixture(rng,name,sources,i,'train')
        for j in range(3):
            idx=(i+j)%4
            other=(idx+1+j%2)%4
            accepted, stable=ids[idx],ids[other]
            good=past[idx]
            safe=past[other]
            uncertain=[
                f'על {sources[idx]} אני בספק, לא בטוח אם עשיתי את זה',
                f'עוד לא הצלחתי לברר אם באמת {good}',
                f'לא סגורה אם {good} או שרק עבר לי בראש לעשות את זה',
                f'לגבי זה ש{good}, הזיכרון שלי מעורפל ואין לי תשובה',
            ][(i+j)%4]
            definite=[
                f'{good}, בדקתי ואני בטוח',
                f'אפשר לעדכן ש{good}',
                f'הפעם אני יכולה לאשר, {good}',
                f'{good}, בזה אין לי ספק',
            ][(i+2*j)%4]
            notes=[
                (f'{safe}; {definite}.',f'{safe}; {uncertain}.'),
                (f'{definite}, וגם {safe}.', f'{uncertain}, אבל {safe}.'),
                (f'{definite}. לגבי הדבר השני, {safe}. מה ההוראה הבאה?', f'{uncertain}. לגבי הדבר השני, {safe}. מה ההוראה הבאה?'),
            ][j]
            intent='next' if j==2 else 'report'
            pair(rows,context,f'clause_{j}',notes,
                 [response(intent,[(accepted,'done'),(stable,'done')]),
                  response(intent,[(stable,'done')],[accepted])])
        for j in range(3):
            idx=(i+j+1)%4
            other=(idx+1)%4
            anchor, competing=sources[idx],sources[other]
            utterances=('סיימתי את מה שהצעת עכשיו.','על הפעולה הזאת אני יכולה לסמן וי.','אותה כבר עשיתי, היא גמורה.',
                        'סגור, גמרתי עם הדבר הזה.','זה הסתיים, בדיוק מה ששאלת.','ביצעתי כבר את הצעד שדיברנו עליו.')
            utterance=utterances[(i+2*j)%len(utterances)]
            if j==0:
                hs=([{'role':'assistant','content':f'כרגע השאלה היא האם כבר יצא לך {anchor}.'}],
                    [{'role':'assistant','content':f'על מה מדובר, {anchor} או {competing}? עוד לא נבחרה פעולה.'}])
            elif j==1:
                hs=([{'role':'user','content':f'אשמח שנתמקד רק בלברר אם צריך {anchor}.'},
                     {'role':'assistant','content':'בסדר, נדבר על הפעולה שבחרת.'}],[])
            else:
                common={'role':'assistant','content':f'יש שתי משימות אפשריות, {anchor} וגם {competing}.'}
                hs=([common,{'role':'user','content':f'מבין השתיים אני מתכוונת לפעולה {anchor}.'}],
                    [common,{'role':'user','content':'מתכוונת לאחת מהן, עוד לא אמרתי לאיזו.'}])
            pair(rows,context,f'history_{j}',[utterance,utterance],
                 [response('report',[(ids[idx],'done')]),response('clarify',clarify=[None])],hs)
    return rows


def fresh_new():
    rows=[]
    rng=random.Random(166015)
    for i,(name,actions,c1,c2,non,pronoun,last) in enumerate(FRESH_RECIPES):
        (a,b,c,d),context=fixture(rng,name,actions,i,'fresh')
        pair(rows,context,'clause_0',c1,[response('report',[(a,'done'),(b,'done')]),response('report',[(b,'done')],[a])])
        pair(rows,context,'clause_1',c2,[response('report',[(b,'done'),(c,'done')]),response('report',[(c,'done')],[b])])
        pair(rows,context,'nonreport_0',non,[response('next',[(c,'done')]),response('next')])
        choice=actions[0] if i%2 else actions[3]
        correct=a if i%2 else d
        hs=([{'role':'user','content':f'אפשר לדבר רגע על הדבר הזה, {choice}?'},
             {'role':'assistant','content':'כן, אגב הפעולה ששאלת עליה, תרצה לעדכן שהתקדמת?'}],
            [{'role':'user','content':f'מתלבט אם לתאר מצב של {choice} או של {actions[2]}.'},
             {'role':'assistant','content':'שתיהן אפשריות. תגיד לאיזו מהן אתה מתייחס.'}])
        pair(rows,context,'history_0',[pronoun,pronoun],[response('report',[(correct,'done')]),response('clarify',clarify=[None])],hs)
        s=last[2]
        bad=response('clarify',clarify=[a]) if s=='uncertain' else response('report',[(a,s)])
        pair(rows,context,f'{s}_0',last[:2],[response('report',[(a,'done')]),bad])
    return rows


def audit_new(rows, expected):
    if len(rows)!=expected or len({r['id'] for r in rows})!=expected:
        raise ValueError('Unexpected pair count')
    for left,right in zip(rows[::2],rows[1::2],strict=True):
        if left['pair']!=right['pair'] or left['expected']==right['expected']:
            raise ValueError('Rows must form a paired semantic contrast')
        changed=[k for k in left['input'] if left['input'][k]!=right['input'][k]]
        axis='history' if left['family']=='history' else 'utterance'
        if changed!=[axis]:
            raise ValueError('A pair altered more than the declared input field')
        for r in (left,right):
            validate(r['expected'],r['input'])


def build():
    source=read_native()['train']
    train,fresh=train_new(),fresh_new()
    audit_new(train,96)
    audit_new(fresh,60)
    pos=defaultdict(list)
    for i,row in enumerate(source):
        if row['training_origin']=='native':
            pos[row['family']].append(i)
    replace=[]
    for indices in pos.values():
        # Leave two original pairs per family and vary their recipes across families.
        pairs=defaultdict(list)
        for index in indices:
            pairs[source[index]['pair']].append(index)
        values=list(pairs.values())
        if len(values)!=6 or any(len(x)!=2 for x in values):
            raise ValueError('Frozen Native V10 pair organization changed')
        rng=random.Random(16180+indices[0])
        leave=rng.sample(range(6),2)
        replace.extend(idx for j,pair_indices in enumerate(values) if j not in leave for idx in pair_indices)
    if len(replace)!=len(train):
        raise ValueError('Replacement and authored corpus counts disagree')
    target=source.copy()
    for i,row in zip(sorted(replace),train,strict=True):
        target[i]=row
    prior=[r for rs in read_native().values() for r in rs]
    prior.extend(json.loads((ROOT/'verification/fresh-pairs-data-v15-20261118.json').read_text()))
    def names(rows):
        return {r['input']['recipe']['name'] for r in rows}
    def texts(rows):
        return {canonical(r['input']['utterance']) for r in rows}
    if names(fresh) & names(prior+train) or names(train) & names(prior) or texts(fresh) & texts(prior+train) or texts(train) & texts(prior):
        raise ValueError('New TRAIN or fresh dataset overlaps an old or competing split')
    info={'original_train_records':len(source),'target_train_records':len(target),'replacements':len(replace),
          'new_train_pairs_by_family':dict(Counter(r['family'] for r in train[::2])),
          'fresh_pairs_by_family':dict(Counter(r['family'] for r in fresh[::2])),
          'fresh_no_report':sum(r['critical_no_facts'] for r in fresh),
          'recipe_names_train_new':len(names(train)),'recipe_names_fresh':len(names(fresh))}
    return {'targeted_train':target,'audit':info},fresh


if __name__=='__main__':
    material,fresh=build()
    for path,value in [(DATA,material),(FRESH,fresh)]:
        with path.open('x') as out:
            out.write(json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n')
    print(json.dumps(material['audit'],ensure_ascii=False,indent=2))
