"""Use a small learned texture classifier only for a grounded cooking attempt."""
import json
import math
import re
from functools import lru_cache
from pathlib import Path

from colloquial_evidence_v60 import decision
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import ingredient
from incomplete_cooking_v76 import process as previous
from ingredient_alternatives_v75 import amounts
from reader_event_roles_v73 import exact_event
from turn_evidence_v58 import DOUBT, MENTION, PLAN, PRIOR_CONTEXT, simulate

COOK = ('לבשל', 'לאפות', 'לצלות', 'לטגן', 'לאדות')
HEAT = re.compile(r'בישל|אפיתי|אפינו|צליתי|צלינו|טיגנתי|טיגנו|אידיתי|בתנור|על האש|בבישול|באפייה|באפיה|'
                  r'(?:סירב|סרב|מסרב)[א-ת]* ל(?:התבשל|התרכך|היאפות)|(?:הורדתי|הנמכתי) ל\s*\d+|'
                  r'(?:שעות|דקות|שעה|שעתיים) (?:בסיר|במחבת)|אחרי (?:הבישול|האפייה)|'
                  r'לא (?:התבשל|התרכ[ךכ]|נאפה|נאפתה|נאפו)[א-ת]* (?:לגמרי|מספיק|עד הסוף)')
UNFINISHED = re.compile(r'לא (?:התבשל|התרכ[ךכ]|הספיק|מוכ|מבושל|עשוי|אפוי|נהי|נאפה|נאפתה|נאפו|נכנס)|'
                        r'(?:סירב|סרב|מסרב)[א-ת]* ל|(?:עדיין|עוד|נשאר[הו]?|נותר[הו]?|יצא[הו]?|בפנים) '
                        r'(?:לי |קצת |ממש |לגמרי )?(?:חי|נא|קש[היות]|בצקי)|חצי מבושל|'
                        r'קש(?:ה|ים|ות) מבפנים|בקושי נכנס|רק מבחוץ|חסר .{0,14}זמן')
SCOPE = re.compile(r'[?"״“”]|(?:^|\s)(?:אם|ואם|אילו|לו|כאילו|כש|לפני|האם|אולי|נניח|'
                   r'לטענת|לדבריה|אמר[הו]?|שאל[הו]?|חשבתי|במתכון כתוב|אל תסמ[ןני]+)\b|'
                   r'לא (?:התחל|הכנס|בישל|אפי|שמ)(?:תי|נו)|(?:בפעם הבאה|מחר|תמיד|בדרך כלל)')
RESOLUTION = re.compile(r'\b(?:בסוף|עכשיו|כעת|אחר כך|לאחר מכן|כבר|ואז)\b.{0,27}(?:מוכ[ןנהיםות]+|התרכ[ךכ]|הצליח|סיימתי|רך|רכ(?:ה|ים|ות))|'
                        r'(?:לא (?:נשאר[הו]? |עדיין )?(?:קשה|חי|נא)(?:ה|ים|ות)?\b)|'
                        r'(?:קשה (?:לי|היה לי) |קשה ל(?:הבין|קרוא|מצוא))')
METHODS = {
    'לאפות': r'אפיתי|אפינו|לאפות|להיאפות|נאפה|נאפו|נאפתה|בתנור',
    'לבשל': r'בישלתי|בישלנו|להתבשל|התבשל[הו]?|בבישול|על האש',
    'לטגן': r'טיגנתי|טיגנו|בטיגון',
    'לצלות': r'צליתי|צלינו|בצלייה',
    'לאדות': r'אידיתי|אידינו|באידוי',
}
FAIL = re.compile(r'לא הצלח(?:תי|נו) (ל[א-ת]+) (.+?)(?: כדי ש.+)?[.! ]*$')
LOWER = re.compile(r'(?:הורדתי|הנמכתי) (?:את (?:האש|הלהבה) )?ל\s*-?\s*\d+')
END_CONDITION = re.compile(r' (?:עד (?:ל|ש)|במשך ).*$')


def features(text):
    words = re.findall(r'[א-ת]+', text)
    grams = {('w:' + w): 2.0 for w in words}
    for a, b in zip(words, words[1:]):
        grams[a + ' ' + b] = 2.0
    for word in words:
        padded = '^' + word + '$'
        for n in (3, 4):
            for i in range(len(padded) - n + 1):
                grams[padded[i:i+n]] = 1.0
    norm = math.sqrt(sum(v*v for v in grams.values())) or 1.0
    return {k: v / norm for k, v in grams.items()}


@lru_cache(maxsize=1)
def weights():
    return json.loads(Path(__file__).with_name('outcome_weights_v77.json').read_text())


def matches_object(obj, text):
    # Attached Hebrew conjunctions are common after an independent clause.
    words = re.findall(r'[א-ת]+', text)
    for i, first in enumerate(words):
        variants = (first, first[1:]) if first.startswith(('ו', 'שה')) else (first,)
        if any(ingredient(' '.join([v, *words[i+1:i+len(obj)]])) == obj for v in variants):
            return True
    return False


def cooking_target(actions, text):
    slots = action_slots([{**a, 'source': END_CONDITION.sub('', a['source'])} for a in actions])
    pool = [a for a in slots if a.verb in COOK and matches_object(a.obj, text)]
    if not pool:
        return None
    # Distinct named ingredients in a cooking report need clause-level tracking.
    if len({a.obj for a in pool}) != 1:
        return None
    methods = {v for v, pattern in METHODS.items() if re.search(pattern, text)}
    if methods:
        pool = [a for a in pool if a.verb in methods or
                (a.verb == 'לצלות' and 'בתנור' in text and not re.search('אפיתי|אפינו', text))]
    return pool[0].key if len(pool) == 1 else None


SWAP = re.compile(r'(?:בסופר |בבית |במקרר )?לא (?:היה|היו|הי[י]?תה) (?:לי |לנו )?'
                  r'(.+?)[, ]+אז (?:החלפ|המר)(?:תי|נו) אות[והםן] ב(.+)')
PRAISE = re.compile(r' (?:והמתיקות|והתוצאה|והמנה) יצאה (?:מצויינת|מצוינת|מעולה|מוצלחת)$')
SHARED = re.compile(r'(אפיתי|בישלתי|טיגנתי|שטפתי|קילפתי|חתכתי|קצצתי) (.+)')
UNIT = re.compile(r'(?:(?:גם |אפילו )?אחרי|כעבור) (?:[0-9א-ת ]+ (?:דקות|שעות)|שעתיים|שעה|חצי שעה)(?: וחצי)?$')
REFERENCE = re.compile(r'^ו?(?:(?:גם |בכל זאת |ואף על פי כן |בסוף |ובסוף |כי )*'
                       r'(?:הם|הן|הוא|היא|זה|עדיין|עדין|עוד|נשאר[וה]?|נותר[וה]?|לא התרכ[ךכ]|לא התבשל)|'
                       r'גם אחרי )')
CLAUSES = re.compile(r'[,;.!]+|\s+(?:אבל|כי|ובכל זאת)\s+')


def explicit_report(actions, text):
    slots = action_slots(actions)
    swapped = SWAP.fullmatch(PRAISE.sub('', text))
    if swapped:
        old, new = (amounts(slots, name) for name in swapped.groups())
        if old and new and not set(old) & set(new):
            return {**dict.fromkeys(old, 'pending'), **dict.fromkeys(new, 'done')}
    shared = SHARED.fullmatch(text)
    if shared:
        body = shared[2]
        if shared[1] == 'אפיתי':
            body = body.removesuffix(' בתנור')
        if exact_event(slots, shared[1] + ' ' + body):
            return {}  # A compound object can itself be one recipe action.
        items = re.split(r',\s*|\s+ו(?=[א-ת])', body)
        if len(items) > 1:
            events = [exact_event(slots, shared[1] + ' ' + x) for x in items]
            if all(events) and len({e.key for e in events}) == len(events):
                return {e.key: 'done' for e in events}
    return {}


def result_clause(actions, text):
    pieces = [p.strip() for p in CLAUSES.split(text) if p.strip()]
    if not pieces:
        return None
    result = pieces[-1]
    if len(pieces) > 1 and (UNIT.fullmatch(result) or
                            re.fullmatch(r'למרות ש.{0,10}(?:על האש|בתנור) כבר .{1,12}', result)):
        result = pieces[-2]
    target = cooking_target(actions, result)
    if not target and REFERENCE.match(result):
        target = cooking_target(actions, text)
    if not target or not UNFINISHED.search(result):
        return None
    # A change of subject across clauses must not attach an earlier failed
    # outcome to an unrelated ingredient. Score the terminal observation only.
    model = weights()
    score = sum(model.get(k, 0) * x for k, x in features(result).items())
    return target if score >= 0.25 else None


def result_facts(req):
    text = req['utterance'].strip().rstrip('.!').strip()
    text = re.sub(r'[.!]\s*(?:מה (?:עושים|לעשות|עכשיו)|איך (?:מצילים|ממשיכים))\?$', '', text)
    if any(pattern.search(text) for pattern in (SCOPE, DOUBT, MENTION, PLAN, PRIOR_CONTEXT, RESOLUTION)):
        return {}
    actions = req['recipe']['actions']
    explicit = explicit_report(actions, text)
    if explicit:
        return explicit
    failed = FAIL.search(text)
    if failed and failed[1] in ('לייבש', 'לרכך', 'לסנן', 'לטחון', 'להקציף', 'לרדד', 'לקפל'):
        # A failed attempt alone need not imply work began (e.g. a missing tool).
        obj = failed[2].strip(' .!')
        slots = [a for a in action_slots(actions) if a.verb == failed[1] and
                 (matches_object(a.obj, obj) or (obj in ('אותו','אותה','אותם','אותן') and
                                                 matches_object(a.obj, text[:failed.start()])))]
        if len(slots) == 1 and re.search(r'יצא[הו]?|ניסיתי|התחלתי|אחרי|תוך כדי|נשאר', text[:failed.start()]):
            return {slots[0].key: 'partial'}
    if not HEAT.search(text):
        return {}
    action = result_clause(actions, text)
    if not action:
        return {}
    facts = {action: 'partial'}
    lowered = [a for a in actions if a['source'] in ('להנמיך את האש', 'להנמיך את הלהבה')]
    if len(lowered) == 1 and LOWER.search(text):
        facts[lowered[0]['id']] = 'done'
    return facts


def process(payload, raw):
    row = json.loads(payload)
    facts = result_facts(row['input'])
    old = previous(payload, raw)
    if not facts:
        return old
    accepted = json.loads(json.loads(old)['accepted_text'])
    corrected = {f['action']: f['status'] for f in accepted['facts']}
    corrected.update(facts)
    encoded = json.dumps(decision(corrected.items(), doubts=[k for k in accepted['clarify'] if k not in facts]),
                         ensure_ascii=False)
    return json.dumps({**simulate(row, encoded), 'accepted_text': encoded, 'route': 'reported_cooking_outcome'},
                      ensure_ascii=False)
