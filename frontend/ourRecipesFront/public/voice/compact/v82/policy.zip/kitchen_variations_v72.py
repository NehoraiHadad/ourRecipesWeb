"""Handle ingredient substitutions, continued ingredient lists, and off-recipe questions."""
import json
import re

from colloquial_evidence_v60 import decision
from conversational_scope_v69 import resolve
from coordinated_claims_v62 import action_slots
from reader_reports_v71 import additions, process as previous, unique_add
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

SUBSTITUTE = re.compile(r'^במקום (.+?) (?:שמתי|הוספתי|שמנו|הוספנו) (.+)$')
SEQUENCE = re.compile(r'\s+(?:ואז|ולאחר מכן|ואחר כך)\s+')
INGREDIENT_LIST = re.compile(r'(.+?)\s+ו(?:הוספתי|שמתי|הוספנו|שמנו) (.+)')
OPTION = re.compile(r'(?:(?:האם )?אפשר (?:עם|בלי|להמיר|להשתמש|להכין|לשלב|להקפיא|להחליף|לוותר|להוסיף)\b|מה (?:אפשר )?לשים במקום\b)')


def variation(row, text):
    slots = action_slots(row['input']['recipe']['actions'])
    substitution = SUBSTITUTE.fullmatch(text)
    if substitution:
        old = unique_add(slots,substitution[1])
        name = re.sub(r'^\d+(?:[./]\d+)?\s+', '', substitution[2])
        new = unique_add(slots,substitution[2]) or unique_add(slots,name)
        if old and new and old!=new:
            return decision([(new,'done'),(old,'pending')])
    parts = SEQUENCE.split(text)
    if len(parts)!=2 or not parts[1].startswith('את '):
        return None
    prefix = INGREDIENT_LIST.fullmatch(parts[0])
    if not prefix:
        return None
    lead = resolve(row,prefix[1])
    first = additions(prefix[2],slots)
    rest = additions(parts[1],slots)
    if lead and lead['facts'] and not lead['clarify'] and first and rest:
        facts = {f['action']:f['status'] for f in lead['facts']}
        facts.update(first)
        facts.update(rest)
        return decision(facts.items())
    return None


def process(payload,raw):
    row=json.loads(payload)
    text=row['input']['utterance'].strip().rstrip('.!')
    if (not PRIOR_CONTEXT.search(text) and not MENTION.search(text) and not DOUBT.search(text)
            and not re.search(r'\b(?:אם|אילו|נניח|לא)\b|[״"“”?]',text)
            and ('במקום ' in text or SEQUENCE.search(text))):
        value=variation(row,text)
        if value:
            accepted=json.dumps(value,ensure_ascii=False)
            return json.dumps({**simulate(row,accepted),'accepted_text':accepted,'route':'ingredient_variation'},ensure_ascii=False)
    result=previous(payload,raw)
    if ('?' in text and OPTION.search(text) and not re.search(r'[א-ת]+תי\b',text)
            and not PRIOR_CONTEXT.search(text)):
        out=json.loads(result)
        if not out['writes'] and (out['reply'].startswith(('הצעד הבא','אפשר לשאול על הצעד הבא','לאיזו פעולה התכוונת'))):
            # The supplied action list doesn't establish whether an alternative works.
            accepted=json.dumps(decision(intent='explain'),ensure_ascii=False)
            answer=simulate(row,accepted)
            if answer['reply'].startswith('לאיזו פעולה') or 'במקום' in text or 'להמיר' in text:
                answer['reply']='אין לי מספיק מידע בהוראות המתכון כדי לקבוע אם השינוי הזה מתאים.'
                answer['reply_source_ids']=[]
            return json.dumps({**answer,'accepted_text':accepted,'route':'recipe_option'},ensure_ascii=False)
    return result
