"""Train a compact whole-turn verifier and calibrate when it may veto proposed facts."""
import argparse
import hashlib
import json
from pathlib import Path
import random

from fresh_pairs_v15 import digest, read, write
from report_verifier_data_v30 import ROOT, build
from sparse_recipe_v3 import INTENTS

LABELS = ('has_report', *INTENTS[1:])
PLAN = ROOT / 'verification/report-verifier-plan-v30-20261119.json'
FREEZE = ROOT / 'verification/report-verifier-freeze-v30-20261119.json'
PUBLIC = ROOT / 'verification/report-verifier-public-v30-20261119.json'


def data_digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def verify():
    for name, sha in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != sha:
            raise ValueError(f'Changed V30 input: {name}')
    cfg = read(PLAN)
    rows = build()
    if any(data_digest(cases) != cfg['split_sha256'][name] for name, cases in rows.items()):
        raise ValueError('V30 training or calibration material changed')
    return cfg, rows


def prepare(tokenizer, rows, config):
    utterances, contexts = [], []
    for row in rows:
        request = row['input']
        utterances.append(request['utterance'])
        source = ' | '.join(a['source'] for a in request['recipe']['actions'])
        history = ' | '.join(f'{p["role"]}: {p["content"]}' for p in request['history'])
        contexts.append(source + ('\n' + history if history else ''))
    encoded = tokenizer(utterances, contexts, truncation=False)
    if max(map(len, encoded['input_ids'])) > config['max_input_tokens']:
        raise ValueError('The verifier input exceeds the frozen context limit')
    return [{name: values[i] for name, values in encoded.items()} for i in range(len(rows))]


def label(row):
    return 0 if row['expected']['facts'] else LABELS.index(row['expected']['intent'])


def probabilities(model, tokenizer, examples, config):
    import torch

    model.eval()
    predictions = []
    with torch.inference_mode():
        for i in range(0, len(examples), config['batch']):
            batch = tokenizer.pad(examples[i:i + config['batch']], return_tensors='pt')
            predictions.extend(torch.softmax(model(**batch).logits, dim=-1).tolist())
    return predictions


def calibrate(rows, predictions, config):
    positive = [bool(r['expected']['facts']) for r in rows]
    grid = []
    for threshold in config['thresholds']:
        flags = [1 - vector[0] >= threshold for vector in predictions]
        erased = sum(flag and report for flag, report in zip(flags, positive, strict=True))
        correct = sum(flag and not report for flag, report in zip(flags, positive, strict=True))
        grid.append({'threshold': threshold, 'false_vetoes': erased, 'correct_vetoes': correct})
    feasible = [entry for entry in grid if entry['false_vetoes'] == 0
                and entry['correct_vetoes'] >= config['min_calibration_coverage']]
    best = max(feasible, key=lambda entry: (entry['correct_vetoes'], entry['threshold']), default=None)
    return {'chosen': best, 'grid': grid, 'with_report': sum(positive), 'no_report': len(positive) - sum(positive)}


def run(source, output):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    config, splits = verify()
    for name, info in read(PUBLIC)['files'].items():
        path = source / name
        if path.stat().st_size != info['bytes'] or digest(path) != info['sha256']:
            raise ValueError(f'Public model integrity mismatch: {name}')
    output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(config['threads'])
    torch.set_num_interop_threads(1)
    torch.manual_seed(config['seed'])
    torch.use_deterministic_algorithms(True)
    rng = random.Random(config['seed'])
    tokenizer = AutoTokenizer.from_pretrained(source, local_files_only=True, trust_remote_code=False)
    model = AutoModelForSequenceClassification.from_pretrained(
        source, local_files_only=True, trust_remote_code=False,
        num_labels=len(LABELS), id2label=dict(enumerate(LABELS)),
        label2id={label: i for i, label in enumerate(LABELS)},
    )
    model.get_input_embeddings().requires_grad_(False)
    optimizer = torch.optim.AdamW(
        (value for value in model.parameters() if value.requires_grad),
        lr=config['learning_rate'], weight_decay=0.01,
    )
    examples = prepare(tokenizer, splits['training'], config)
    targets = [label(r) for r in splits['training']]
    training = []
    lengths = {name: max(map(lambda x: len(x['input_ids']), prepare(tokenizer, rows, config)))
               for name, rows in splits.items()}
    records = list(range(len(examples)))
    for epoch in range(1, config['epochs'] + 1):
        rng.shuffle(records)
        model.train()
        loss_sum = 0
        for i in range(0, len(records), config['batch']):
            indices = records[i:i + config['batch']]
            batch = tokenizer.pad([examples[k] for k in indices], return_tensors='pt')
            loss = model(**batch, labels=torch.tensor([targets[k] for k in indices])).loss
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            loss_sum += loss.item() * len(indices)
        training.append({'epoch': epoch, 'mean_loss': loss_sum / len(records)})
        write(output / 'training.json', training)
        print(f"Epoch {epoch}: loss {training[-1]['mean_loss']:.4f}", flush=True)

    checkpoint = output / 'checkpoint'
    model.save_pretrained(checkpoint, safe_serialization=True)
    tokenizer.save_pretrained(checkpoint)
    torch.save({'optimizer': optimizer.state_dict(), 'rng': torch.get_rng_state(), 'epoch': config['epochs']},
               output / 'training-state.pt')
    calibration_rows = splits['calibration']
    scores = probabilities(model, tokenizer, prepare(tokenizer, calibration_rows, config), config)
    write(output / 'calibration-raw.json', [{'id': r['id'], 'probabilities': probs}
                                            for r, probs in zip(calibration_rows, scores, strict=True)])
    proof = {
        'training': training, 'calibration': calibrate(calibration_rows, scores, config),
        'max_input_tokens_observed': lengths, 'training_rows': len(examples),
        'checkpoint_sha256': {p.name: digest(p) for p in sorted(checkpoint.iterdir()) if p.is_file()},
        'training_state_sha256': digest(output / 'training-state.pt'),
    }
    write(output / 'fit.json', proof)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.source, args.output)
