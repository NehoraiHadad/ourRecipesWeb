"""Prospective synthetic pairs for checking evidence boundaries."""
from collections import Counter
import json
from pathlib import Path
import random

from fresh_pairs_data_v15 import DATA as V15, canonical
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, fixture, pair, response, train_new, audit_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/grounded-scope-data-v18-20261119.json'
RECIPES = [
    ('קרוטוני שום', ('לחתוך לחם לקוביות', 'לכתוש שום', 'למדוד שמן לקערה', 'לקלות את הקוביות'),
     ('מבחינתי זה מטופל: חתכתי את הלחם לקוביות.', 'זה כבר בוצע.'),
     ('ייתכן ששכחתי לנעול את הדלת; כבר כתשתי את השום.', 'ייתכן שכבר מדדתי את השמן; כבר כתשתי את השום.'),
     ('עדיין נשאר לי להשלים; חתכתי את הלחם רק בחלקו.', 'חתכתי את הלחם רק בחלקו; מדדתי את השמן עד הסוף.'),
     ('חתכתי את הלחם וסיימתי לכתוש את השום.', 'אין לי ודאות שחתכתי את הלחם, אבל סיימתי לכתוש את השום.'),
     'גמרתי לגמרי עם זה.'),
    ('סלט שומר ושמיר', ('לשטוף שומר', 'לקצוץ שמיר', 'לסחוט לימון', 'לערבב את הסלט'),
     ('עכשיו אפשר לסמן שזה הושלם: שטפתי את השומר.', 'עכשיו אפשר לסמן שזה הושלם.'),
     ('אולי האינטרקום מצלצל; קצצתי את השמיר.', 'אולי כבר סחטתי את הלימון; קצצתי את השמיר.'),
     ('לא השלמתי את הכול; שטפתי חלק מהשומר.', 'שטפתי חלק מהשומר; כבר סחטתי את הלימון.'),
     ('את השומר שטפתי וגם קצצתי את השמיר.', 'אני בספק אם שטפתי את השומר, אבל קצצתי את השמיר.'),
     'את הדבר הזה כבר עשיתי.'),
    ('בורקס תרד', ('לשטוף תרד', 'לפורר גבינה', 'לטרוף ביצה', 'למלא את ריבועי הבצק'),
     ('זה כבר נעשה אצלי: שטפתי את התרד.', 'זה כבר נעשה אצלי.'),
     ('לא ברור לי אם הגיע שליח; כבר פוררתי את הגבינה.', 'לא ברור לי אם טרפתי את הביצה; כבר פוררתי את הגבינה.'),
     ('זה נשאר לי באמצע; שטפתי רק חלק מהתרד.', 'שטפתי רק חלק מהתרד; טרפתי את הביצה עד שהיא אחידה.'),
     ('שטפתי את התרד ואת הגבינה כבר פוררתי.', 'נדמה לי ששטפתי תרד אבל אני לא בטוח; את הגבינה כבר פוררתי.'),
     'על ההיא אפשר לסמן שכבר גמרתי.'),
    ('תבשיל כרוב ודלעת', ('לפרוס כרוב', 'לקלף דלעת', 'למדוד כמון', 'לכסות את הסיר'),
     ('כן, מבחינתי זה הושלם: כבר פרסתי את הכרוב.', 'כן, מבחינתי זה הושלם.'),
     ('אולי החלון נשאר פתוח; את הדלעת קילפתי.', 'אולי כבר מדדתי את הכמון; את הדלעת קילפתי.'),
     ('עוד נשאר מה לעשות; פרסתי את הכרוב באופן חלקי.', 'פרסתי את הכרוב באופן חלקי; כבר מדדתי את הכמון.'),
     ('פרסתי את הכרוב, וגם קילפתי את הדלעת.', 'אני לא סגור אם פרסתי את הכרוב. את הדלעת קילפתי.'),
     'הפעולה ששאלת עליה גמורה.'),
    ('לביבות סלק', ('לגרר סלק', 'למדוד קמח', 'לטרוף ביצה', 'לחמם את המחבת'),
     ('אני מאשרת שזה נגמר מבחינתי: גיררתי את הסלק.', 'אני מאשרת שזה נגמר מבחינתי, כבר גמרתי.'),
     ('אולי נגמרה הסוללה של השלט; כבר מדדתי קמח.', 'אולי כבר טרפתי את הביצה; כבר מדדתי קמח.'),
     ('יש עוד עבודה; גיררתי רק חלק מהסלק.', 'גיררתי רק חלק מהסלק; את הביצה כבר טרפתי.'),
     ('גיררתי את הסלק, ואת הקמח מדדתי.', 'איני זוכרת בוודאות אם גיררתי את הסלק, ואת הקמח מדדתי.'),
     'מה שדיברנו עליו כבר נעשה.'),
    ('תבשיל דוחן', ('לשטוף דוחן', 'לקצוץ כרישה', 'לסחוט ליים', 'לערבב את התבשיל'),
     ('זה כבר הושלם מבחינתי: שטפתי את הדוחן.', 'זה כבר הושלם מבחינתי.'),
     ('ייתכן שמישהו דופק בחוץ; את הכרישה קצצתי.', 'ייתכן שכבר סחטתי את הליים; את הכרישה קצצתי.'),
     ('זה עוד לא גמור; שטפתי רק חלק מהדוחן.', 'שטפתי רק חלק מהדוחן; סחטתי את הליים כולו.'),
     ('שטפתי את הדוחן וקצצתי את הכרישה.', 'אני מתלבט אם ביצעתי את שטיפת הדוחן, אבל קצצתי את הכרישה.'),
     'מבחינתי עם זה סיימתי.'),
]


def build():
    rows = []
    rng = random.Random(181819)
    for i, (name, actions, explicit, side, partial, mixed, pronoun) in enumerate(RECIPES):
        (a, b, c, _), ctx = fixture(rng, name, actions, i, 'fresh-v18')
        pair(rows, ctx, 'explicit_0', explicit, [response('report', [(a, 'done')]), response('clarify', clarify=[None])])
        pair(rows, ctx, 'side_0', side, [response('report', [(b, 'done')]), response('report', [(b, 'done')], [c])])
        pair(rows, ctx, 'partial_0', partial, [response('report', [(a, 'partial')]), response('report', [(a, 'partial'), (c, 'done')])])
        pair(rows, ctx, 'mixed_0', mixed, [response('report', [(a, 'done'), (b, 'done')]), response('report', [(b, 'done')], [a])])
        histories = ([{'role': 'assistant', 'content': f'אנחנו מתמקדים בפעולה {actions[1]}.'}],
                     [{'role': 'assistant', 'content': f'שתי אפשרויות, {actions[1]} או {actions[2]}. תגיד לאיזו כוונתך.'}])
        pair(rows, ctx, 'history_0', [pronoun, pronoun], [response('report', [(b, 'done')]), response('clarify', clarify=[None])], histories)
    audit_new(rows, 60)
    old = [row for values in read_native().values() for row in values]
    for path in (V15, V16):
        old.extend(json.loads(path.read_text()))
    old.extend(train_new())
    recipe_names = {r['input']['recipe']['name'] for r in old}
    utterances = {canonical(r['input']['utterance']) for r in old}
    if any(r['input']['recipe']['name'] in recipe_names or canonical(r['input']['utterance']) in utterances for r in rows):
        raise ValueError('V18 overlaps an exposed recipe or exact normalized utterance')
    return rows


if __name__ == '__main__':
    rows = build()
    with DATA.open('x') as out:
        for_dump = json.dumps(rows, ensure_ascii=False, separators=(',', ':'))
        out.write(for_dump+'\n')
    print(Counter(r['family'] for r in rows), sum(r['critical_no_facts'] for r in rows))
