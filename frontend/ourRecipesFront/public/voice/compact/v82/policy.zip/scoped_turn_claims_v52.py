"""Verify recipe scope, history anchors, and independent reports before a state write."""
import re

from scoped_decode_v17 import COMPLETED, UNRESOLVED, compact, literal_ids, safe_parse
from scoped_doubt_v48 import PARTS, RECHECK, targets
from turn_scope_v50 import (
    CLAIM, CURRENT_REPORT, REFERENCE, classify, interpret as previous,
)

PRIOR_CONTEXT = re.compile(
    r'\b(?:(?:ב|מ|של |על )ה?(?:מתכון|תבשיל) (?:הישן|הקודם|שסגרנו|שהחלפנו)|'
    r'(?:ב|מ|ל|של |על )ה?(?:הכנה|מנה) (?:הישנה|הקודמת|שעברנו ממנה|שלפני המעבר)|'
    r'לפני (?:המעבר בין המתכונים|שהחלפתי מתכון|שעברתי למתכון הזה))\b'
)
ACTIVE_NOTE = re.compile(
    r'^(?:במתכון (?:הזה|הנוכחי|החדש)|פה|כאן)[ ,:]*(?:עוד לא|עדיין לא|לא) '
    r'(?:דיווחתי על ביצוע|סימנתי פעולה|עדכנתי שבוצע משהו)$'
)
POSITIVE_LEAD = re.compile(
    r'^(?:מה שאני כן זוכר(?:ת)? (?:הוא |זה )?ש|'
    r'בנפרד מ(?:זה|כך)[, ]+|לגבי מה שבוצע[,: ]+|'
    r'בוודאות אני יודע(?:ת)? ש|מה שבטוח[,: ]+|ובינתיים )'
)
NAMED_UNCERTAINTY = re.compile(
    r'\b(?:יש לי ספק|מסופק(?:ת)?|לא בטוח(?:ה)? (?:בכלל|שזה בוצע)|'
    r'לא זוכר(?:ת)? אם|מנסה להיזכר אם|לא יודע(?:ת)? להגיד אם|'
    r'אין לי דרך לדעת אם|מתלבט(?:ת)? אם)\b'
)
REPORT_CLOSER = re.compile(
    r'^(?:(?:עדיין |עוד )?יש לי (?:מה לסיים|מה להשלים|חלק להשלים)|בנפרד מ(?:זה|כך))$'
)
POSITION_REPORT = re.compile(
    r'^(?:(?:ב[א-ת״׳-]+(?: [א-ת״׳-]+){0,8}|אני|כרגע) )?'
    r'(?:כבר )?(?:הגעתי|עברתי|התקדמתי) (?:לשלב|לצעד) '
    r'(?:ה[א-ת]+|[0-9]+|ראשון|שני|שלישי|רביעי|חמישי)$'
)
MISSED_QUESTION = re.compile(
    r'^(?:מה|אילו|איזה|איזו)\b.*\b(?:עוד פתוח|נשאר(?:ו)?|פספסתי|טרם בוצע(?:ו)?)\b'
    r'.*\b(?:[במ]?(?:השלבים הראשונים|שלבים קודמים|השלבים הקודמים)|לפני(?:ו| כן)?|מאחור|מהשלב הקודם)\b'
)
NEXT_QUESTION = re.compile(
    r'^(?:איפה (?:ממשיכים|להמשיך)|במה (?:ממשיכים|מתחילים|כדאי לטפל)|'
    r'מה (?:עוד (?:נשאר|צריך)|הצעד הבא|השלב הבא|מתחילים אחרי))\b'
)
REFERENCE_LANGUAGE = re.compile(
    r'\b(?:בה|בו|היא|הוא|מה ש(?:שאלת|הזכרת)|הפעולה ש(?:שאלת|הזכרת)|'
    r'לשאלה שלך|לגבי (?:הפעולה|המשימה) ההיא)\b'
)
POSITIVE_FINISH = re.compile(r'\b(?:השלמתי|לסמן וי|סימנתי וי|הסתיימה|מוכן(?:ה)?)\b')
SINGLE_QUESTION = re.compile(r'\b(?:האם|סיימת|סיימתם|עשית|ביצעת|השלמת|בוצעה|הושלמה)\b')
REPORT_DISQUALIFIER = re.compile(
    r'\b(?:לא|בלי|אולי|אם|עוד לא|חלק(?:ית)?|חצי|בערך|אבל|טרם|'
    r'מתכננ[תן]|כנראה|אסיים|הראשונה|השנייה|השניה)\b'
)
QUOTED_OPEN = re.compile(r'^(?:את )?(?:הפעולה |המשימה )?״([^״]+)״ (?:צריך |אפשר |נא )?(?:להשאיר|להחזיר) פתוחה$')
NO_START = re.compile(r'^(?:עוד |עדיין )?לא (?:נגעתי (?:בה|בו|בזה)|התחלתי (?:אותה|אותו|בזה)|ניגשתי (?:אליה|אליו|לזה))$')


def clauses_of(text):
    # A conjunction attached to an explicit switch can delimit a report without punctuation.
    text = re.sub(r'\s+(?=ובמתכון (?:הזה|הנוכחי|החדש)\b)', '. ',text)
    return [m.group().strip() for m in PARTS.finditer(text) if m.group().strip()]


def classify_claim(row, clause):
    request = row['input']
    if PRIOR_CONTEXT.search(clause):
        return 'previous',None
    if ACTIVE_NOTE.fullmatch(clause):
        return 'qualifier',None
    if MISSED_QUESTION.search(clause):
        return 'follow_up','missed'
    if NEXT_QUESTION.search(clause):
        return 'follow_up','next'
    if POSITION_REPORT.fullmatch(clause):
        return 'position',None
    if REPORT_CLOSER.fullmatch(clause):
        return 'qualifier',None
    if NAMED_UNCERTAINTY.search(clause) and not RECHECK.search(clause):
        named,witnessed = targets(clause,request)
        if len(named)==1 and witnessed:
            return 'doubt',next(iter(named))
    body = POSITIVE_LEAD.sub('',CURRENT_REPORT.sub('',clause)).strip()
    return classify(row,body) if body!=clause else classify(row,clause)


def history_completion(request):
    history = request['history']
    text = request['utterance']
    if (not history or history[-1]['role']!='assistant' or '?' in text or len(text)>115
            or REPORT_DISQUALIFIER.search(text) or literal_ids(text,request)):
        return None
    if not (REFERENCE.search(text) or REFERENCE_LANGUAGE.search(text)):
        return None
    if not (COMPLETED.search(text) or CLAIM.search(text) or POSITIVE_FINISH.search(text)):
        return None
    last = history[-1]['content']
    selected = literal_ids(last,request)
    if len(selected)>1 and UNRESOLVED.search(last):
        return {'intent':'clarify','facts':[],'clarify':[None]}
    if len(selected)==1 and '?' in last and SINGLE_QUESTION.search(last) and not UNRESOLVED.search(last):
        return {'intent':'report','facts':[{'action':next(iter(selected)),'status':'done'}],'clarify':[]}
    return None


def classify_turn(row, parts):
    labeled = [classify_claim(row,part) for part in parts]
    kinds = {kind for kind,_ in labeled}
    reports = [value for kind,value in labeled if kind=='report']
    doubts = {value for kind,value in labeled if kind=='doubt'}
    navigation = {value for kind,value in labeled if kind=='follow_up'}
    reported_ids = {fact['action'] for fact in reports}
    if (len(navigation)>1 or len(reports)!=len(reported_ids) or doubts & reported_ids):
        return None
    if 'previous' in kinds and 'unknown' in kinds:
        # A foreign report is never evidence for updating the active recipe.
        return {'intent':'clarify','facts':[],'clarify':[None]}
    if 'unknown' in kinds:
        return None
    if not (('previous' in kinds and (reports or navigation))
            or {'doubt','report'}<=kinds or {'position','follow_up'}<=kinds
            or ('report' in kinds and 'qualifier' in kinds and len(parts)>1)):
        return None
    intent = next(iter(navigation)) if navigation else 'report' if reports else 'clarify'
    return {'intent':intent,'facts':reports,'clarify':sorted(doubts)}


def interpret(row, raw):
    accepted,route = previous(row,raw)
    current = safe_parse(accepted,row)
    request = row['input']
    parts = clauses_of(request['utterance'])
    result = classify_turn(row,parts)
    if result is not None and result!=current:
        return compact(result,row),'independent_scoped_claims'
    anchor = history_completion(request)
    if anchor and (not current or not current['facts'] or anchor['intent']=='clarify') and anchor!=current:
        return compact(anchor,row),'bound_history_reference'
    if len(parts)==2 and (opening := QUOTED_OPEN.fullmatch(parts[0])) and NO_START.fullmatch(parts[1]):
        selected = literal_ids(opening[1],request)
        if len(selected)==1:
            corrected = {'intent':'report','facts':[{'action':next(iter(selected)),'status':'pending'}],'clarify':[]}
            if corrected!=current:
                return compact(corrected,row),'explicit_unstarted_action'
    return accepted,route
