"""Prospective Hebrew progress pairs with separate explicit and open-form strata."""
from pathlib import Path
import random

from explicit_nonstart_data_v24 import DATA as V24
from fresh_pairs_data_v15 import DATA as V15, canonical
from fresh_pairs_v15 import read, write
from grounded_scope_data_v18 import DATA as V18
from preserve_reports_data_v20 import DATA as V20
from report_scope_data_v21 import DATA as V21
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/grounded-progress-data-v25-20261119.json'

RECIPES = (
    ('פשטידת דלעת וכוסמין', ('לרסק דלעת', 'להמיס חמאה', 'להבריש תבנית', 'לשקול קמח כוסמין'),
     ('ריסקתי רק שליש מהדלעת.', 'את הדלעת עוד לא ריסקתי.'),
     ('אולי המסתי את החמאה.', 'קודם חשבתי שאולי המסתי את החמאה, בדקתי ואכן המסתי אותה.'),
     ('עוד לא הברשתי את התבנית; את קמח הכוסמין כבר שקלתי.',
      'הברשתי רק חצי מהתבנית; יכול להיות ששקלתי את קמח הכוסמין.'),
     ('הברשתי את התבנית. מה עכשיו?', 'נניח שהברשתי את התבנית. מה הייתי עושה אחר כך?')),
    ('שקשוקת כרישה', ('לפרוס כרישה', 'לשבור ביצים', 'לתבל את הרוטב', 'לכסות את המחבת'),
     ('פרסתי מעט מהכרישה.', 'טרם פרסתי את הכרישה.'),
     ('אני לא בטוחה אם שברתי את הביצים.', 'לא הייתי בטוחה אם שברתי את הביצים, אבל בדקתי ואכן שברתי.'),
     ('טרם תיבלתי את הרוטב, אבל כבר כיסיתי את המחבת.',
      'תיבלתי את הרוטב רק חלקית; אולי כיסיתי את המחבת.'),
     ('פרסתי את הכרישה אבל רק חלק ממנה.', 'פרסתי את הכרישה עד הסוף.')),
    ('רוטב יוגורט ושמיר', ('לסנן יוגורט', 'לקצוץ שמיר', 'לסחוט לימון', 'לערבב את הרוטב'),
     ('סיננתי קצת מהיוגורט.', 'עד עכשיו לא סיננתי את היוגורט.'),
     ('ייתכן שקצצתי את השמיר.', 'חשבתי שאולי קצצתי את השמיר, וידאתי ואכן קצצתי את השמיר.'),
     ('לא סחטתי בכלל את הלימון; ערבבתי את הרוטב כבר.',
      'סחטתי חלק מהלימון; אני לא זוכרת אם ערבבתי את הרוטב.'),
     ('קצצתי את השמיר וסחטתי את הלימון. איך ממשיכים?', 'קצצתי את השמיר. איך ממשיכים?')),
    ('לביבות צנונית ותרד', ('לשטוף את התרד', 'לטגן את הלביבות', 'להוסיף שמן אגוזים', 'לנקות את הצנוניות'),
     ('שטפתי רק רבע מהתרד.', 'את התרד בכלל לא שטפתי.'),
     ('יכול להיות שלא טיגנתי את הלביבות.', 'קודם חשבתי שאולי טיגנתי את הלביבות, בדקתי ואכן טיגנתי אותן.'),
     ('את שמן האגוזים עדיין לא הוספתי, ואת הצנוניות כבר ניקיתי.',
      'הוספתי מעט משמן האגוזים; נדמה לי שניקיתי את הצנוניות.'),
     ('כמה שמן אגוזים צריך לפי המתכון?', 'הוספתי את שמן האגוזים. מה הצעד הבא?')),
    ('קינוח כוסמת ודובדבנים', ('למדוד גרגירי כוסמת', 'להרתיח את המים', 'לקרר את הסירופ', 'לצקת את הקרם'),
     ('מדדתי רק חלק מגרגירי הכוסמת.', 'עדיין לא התחלתי למדוד גרגירי כוסמת.'),
     ('אני לא יודע אם הרתחתי את המים.', 'לא הייתי בטוח אם הרתחתי את המים, אבל בדקתי ואכן הרתחתי.'),
     ('עד כה לא קיררתי את הסירופ וגם יצקתי את הקרם.',
      'קיררתי חצי מהסירופ; אולי לא יצקתי את הקרם.'),
     ('גרגירי הכוסמת עוד לא מוכנים למדידה. מה כדאי לעשות?', 'גרגירי הכוסמת כבר מדודים. מה כדאי לעשות?')),
    ('מרק סלק ועלי חוביזה', ('לקלף סלק', 'למעוך את השום', 'לבשל חוביזה', 'לפתוח את המכסה'),
     ('קילפתי חלק מהסלק ועדיין לא סיימתי.', 'עוד לא קילפתי את הסלק בכלל.'),
     ('נדמה לי שמעכתי את השום.', 'בהתחלה חשבתי שאולי מעכתי את השום, בדקתי ואכן מעכתי אותו.'),
     ('את החוביזה לא בישלתי עד עכשיו; פתחתי את המכסה.',
      'בישלתי את החוביזה חלקית; אני לא בטוח אם פתחתי את המכסה.'),
     ('״מעכתי את השום״ זו רק דוגמה. מה השלב הבא?', 'מעכתי את השום. מה השלב הבא?')),
    ('כריך אנשובי וזיתים ירוקים', ('למרוח ממרח זיתים', 'לקלות את הלחם', 'לחתוך מלפפון חמוץ', 'להוסיף אנשובי'),
     ('מרחתי חלק מממרח הזיתים.', 'את ממרח הזיתים טרם מרחתי.'),
     ('אולי קליתי את הלחם.', 'לא הייתי בטוח אם קליתי את הלחם, אבל בדקתי ואכן קליתי אותו.'),
     ('עוד לא חתכתי את המלפפון החמוץ; כבר הוספתי אנשובי.',
      'חתכתי מעט מהמלפפון החמוץ; יכול להיות שהוספתי אנשובי.'),
     ('הלחם קלוי רק מצד אחד. מה עכשיו?', 'הלחם קלוי משני הצדדים. מה עכשיו?')),
    ('מוס ליים ופיסטוק', ('להקציף שמנת מתוקה', 'לסחוט ליים', 'לטחון פיסטוקים', 'לקרר את המוס'),
     ('הקצפתי את השמנת המתוקה רק חלקית.', 'טרם הקצפתי את השמנת המתוקה.'),
     ('יכול להיות שסחטתי את הליים.', 'קודם חשבתי שאולי סחטתי את הליים, וידאתי ואכן סחטתי אותו.'),
     ('לא טחנתי את הפיסטוקים בכלל, אבל כבר קיררתי את המוס.',
      'טחנתי רבע מהפיסטוקים; אני לא בטוח אם קיררתי את המוס.'),
     ('עוד לא סחטתי את כל הליים, רק מעט ממנו.', 'עוד לא סחטתי את הליים, אפילו לא מעט ממנו.')),
)


def build():
    rng = random.Random(251119)
    rows = []
    for i, (name, sources, progress, doubt, independent, open_form) in enumerate(RECIPES):
        (a, b, c, d), ctx = fixture(rng, name, sources, i, 'fresh-v25')
        ctx['progress'].update({a: 'done', b: 'partial', c: 'done', d: 'pending'})
        pair(rows, ctx, 'progress_0', progress,
             [response('report', [(a, 'partial')]), response('report', [(a, 'pending')])])
        pair(rows, ctx, 'doubt_0', doubt,
             [response('clarify', clarify=[b]), response('report', [(b, 'done')])])
        pair(rows, ctx, 'independent_0', independent,
             [response('report', [(c, 'pending'), (d, 'done')]),
              response('report', [(c, 'partial')], [d])])
        open_labels = (
            (response('next', [(c, 'done')]), response('explain')),
            (response('report', [(a, 'partial')]), response('report', [(a, 'done')])),
            (response('next', [(b, 'done'), (c, 'done')]), response('next', [(b, 'done')])),
            (response('quantity'), response('next', [(c, 'done')])),
            (response('next'), response('next', [(a, 'done')])),
            (response('next'), response('next', [(b, 'done')])),
            (response('next', [(b, 'partial')]), response('next', [(b, 'done')])),
            (response('report', [(b, 'partial')]), response('report', [(b, 'pending')])),
        )
        pair(rows, ctx, 'open_0', open_form, open_labels[i])

    audit_new(rows, 64)
    past = [r for split in read_native().values() for r in split] + train_new()
    for path in (V15, V16, V18, V20, V21, V24):
        past.extend(read(path))
    recipes = {r['input']['recipe']['name'] for r in past}
    utterances = {canonical(r['input']['utterance']) for r in past}
    if any(r['input']['recipe']['name'] in recipes or canonical(r['input']['utterance']) in utterances for r in rows):
        raise ValueError('V25 overlaps known exact utterances or recipe names')
    return rows


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
