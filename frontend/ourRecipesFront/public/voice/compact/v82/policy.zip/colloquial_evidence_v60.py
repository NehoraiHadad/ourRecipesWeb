"""Interpret grounded kitchen result descriptions and explicitly scoped recipe switches."""
import json
import re

from turn_evidence_v58 import (DOUBT, MENTION, NOMINAL, PLAN, PRIOR_CONTEXT,
                               WORDS, interpret as previous, simulate)

# Narrow, present-state expressions with a distinct effect in a recipe.
RESULTS = (
    (('לחתוך','לקצוץ'), r'בקוביות|בחתיכות קטנות'),
    (('לפרוס',), r'בפרוסות'),
    (('לגרר',), r'מגורר(?:ת|ים|ות)?'),
    (('לטגן',), r'רא(?:ה|תה|ו) מחבת'),
    (('להוסיף',), r'בפנים|בתוך (?:הסיר|הקערה|התערובת)|בסיר|בקערה|בתערובת'),
)
LEAD = re.compile(r'^(?:(?:יאללה|טוב|אז|הנה|זהו|סבבה|תכלס|וואלה|אה|ועכשיו|עכשיו|כבר)\s+)+')
SPLIT = re.compile(r'([.,;!?]+|\s+(?:אבל|ואילו|ומצד שני)\s+)')
AWAITING = re.compile(r'(?:עוד |עדיין )?(?:ברשימת (?:ההמתנה|המטלות)(?: שלי)?|בתור|מחכ(?:ה|ים|ות) לתור(?:ו|ה|ם|ן)?)')
SWITCH = re.compile(r'(?:[.;!?]\s*|,\s*אבל\s+|\s+אבל\s+)(?:ו?במתכון (?:הזה|הנוכחי|החדש)|כאן|פה|הפעם)\s*[:,]?\s+')
FRACTION = re.compile(r'^(?:רק )?(?:חצי|שליש|רבע|חלק) מ(?:ן )?|^רק (?:חלק מ|כמה מ)')
BLOCK = re.compile(r'\b(?:אם|אילו|אולי|לו|כש|מחר|מתישהו|כדאי|צריך|אמור|יהיה|יהיו|תהיה|יהפוך|יהפכו|כאילו|לדבריו)\b|[״"“”]')
FILLER = re.compile(r'(?:טוב|אז|שנייה|רגע|יאללה|וואלה|תכלס|זהו|סבבה|אה|נו)(?:\s+(?:שנייה|אחד|אז|טוב))*')
TOPIC = re.compile(r'(?:באמצע עם|לגבי|בקשר אל) (.+)')
CORRECTION_ASIDE = re.compile(r'(?:נסחפתי|הגזמתי|טעיתי) עם ה[״"](?:גמור|מוכן|מושלם)[״"] הזה')
REMAINDER = re.compile(r' וחצי (?:עוד |עדיין )?(?:מחכה|מסתכל עליי) (?:על|מ|ב)(?:הקרש|הצלחת|צד)$')

TOOLS = {'מחבת':'לטגן','פומפייה':'לגרר','מסננת':'לסנן'}
STATUS_PREFIX = r'(?:כבר |כן |עכשיו |אצלי |כול[והםן] |לגמרי )*'


def decision(facts=(), doubts=(), intent=None):
    return {'intent':intent or ('report' if facts else 'clarify' if doubts else 'other'),
            'facts':[{'action':key,'status':status} for key,status in facts],
            'clarify':list(doubts)}


def pack(value,route):
    return json.dumps(value,ensure_ascii=False),route


def plain(word):
    return word[1:] if len(word)>3 and word.startswith('ה') else word


def object_matches(fragment, source):
    """Match a contiguous ingredient name, allowing a definite article on either side."""
    wanted=[plain(w) for w in WORDS.findall(fragment)]
    available=[plain(w) for w in WORDS.findall(source)[1:] if w!='את']
    return bool(wanted) and any(available[i:i+len(wanted)]==wanted for i in range(len(available)))


def candidates(actions, names, obj):
    return [a for a in actions if a['source'].split()[0] in names and object_matches(obj,a['source'])]


def result_claim(clause,actions,last_object):
    """Return (ingredient, compatible recipe actions, status) for a complete result clause."""
    text=LEAD.sub('',clause).strip()
    if FRACTION.match(text):
        text=REMAINDER.sub('',text)
    if AWAITING.search(text):
        for verb,noun in NOMINAL.items():
            match=re.fullmatch(r'ה?'+noun+r' (?:של )?(.+?) '+AWAITING.pattern,text)
            if match:
                obj=match[1]
                return obj,candidates(actions,(verb,),obj),'pending'
    for verbs,expression in RESULTS:
        match=re.fullmatch(r'(.+?) '+STATUS_PREFIX+r'((?:עוד לא |עדיין לא |טרם )?)('+expression+r')(?: כבר| עכשיו| אצלי| אצלנו)?',text)
        if not match:continue
        subject,negation,cue=match.groups()
        fraction=FRACTION.match(subject)
        obj=subject[fraction.end():] if fraction else re.sub(r'^כל ', '', subject)
        if obj in ('מנו','מנה','הם','הן','החומר','זה','אותו','אותה'):
            obj=last_object
        actions_found=candidates(actions,verbs,obj) if obj else []
        if verbs==('להוסיף',) and cue!='בפנים':
            vessel='סיר' if 'סיר' in cue else 'קערה' if 'קערה' in cue else 'תערובת'
            actions_found=[a for a in actions_found if not any(
                part in a['source'] and vessel!=other for part,other in
                [('לסיר','סיר'),('לקערה','קערה'),('לתערובת','תערובת')])]
        if negation and (fraction or verbs!=('להוסיף',)):
            return obj,actions_found,'uncertain'
        return obj,actions_found,'pending' if negation else 'partial' if fraction else 'done'
    return None


def interpret(row,raw):
    req=row['input']
    text=req['utterance'].strip()
    actions=req['recipe']['actions']
    # Explicit change of recipe resets the antecedent: only the local suffix may write.
    switch=SWITCH.search(text)
    if switch and PRIOR_CONTEXT.search(text[:switch.start()]):
        tail=text[switch.end():]
        if not PRIOR_CONTEXT.search(tail) and not BLOCK.search(tail):
            local={**req,'history':[],'utterance':tail}
            accepted,route=previous({'id':row['id'],'input':local},json.dumps(decision()))
            if route=='clause_evidence' and json.loads(accepted)['facts']:
                return accepted,'current_recipe_claim'
    # A single attributed, hypothetical or uncertain result does not assert completion.
    utterance=text.rstrip('.!? ').strip()
    guarded=re.fullmatch(r'(אולי|ייתכן ש|נדמה לי ש|אני לא בטוח ש|אני לא בטוחה ש|נניח ש|נגיד ש|אם|כתוב ש|היא אמרה ש|הוא אמר ש)\s*(.+)',utterance)
    if guarded:
        condition,body=guarded.groups()
        claim=result_claim(body.strip('״"“”'),actions,None)
        if claim and claim[1]:
            if DOUBT.search(condition):
                keys=[a['id'] for a in claim[1]]
                return pack(decision(doubts=keys if len(keys)==1 else [None]),'uncertain_result')
            return pack(decision(),'mentioned_result')
    accepted,route=previous(row,raw)
    # Attribution, conditional instructions and uncertainty may extend across a comma.
    analysis_text=CORRECTION_ASIDE.sub('רגע',text)
    if (PRIOR_CONTEXT.search(analysis_text) or MENTION.search(analysis_text)
            or DOUBT.search(analysis_text) or BLOCK.search(analysis_text)):
        return accepted,route
    parts=SPLIT.split(analysis_text)
    claims={}
    doubts=[]
    last_object=None
    tool=None
    indirect=False
    fully_read=True
    rewritten=[]
    for index in range(0,len(parts),2):
        part=parts[index].strip()
        delimiter=parts[index+1] if index+1<len(parts) else ''
        if not part:
            rewritten.append(delimiter)
            continue
        replacement=part
        topic=TOPIC.fullmatch(part)
        claim=result_claim(part,actions,last_object)
        if tool and re.fullmatch(r'(?:עוד |עדיין )?לא (?:הגעתי לשם|ניגשתי לזה|התחלתי)',part):
            claim=(last_object,candidates(actions,(tool,),last_object),'pending')
        tool=None
        if claim:
            obj,matched,status=claim
            indirect=True
            if len(matched)==1:
                key=matched[0]['id']
                last_object=obj
                if '?' in delimiter or status=='uncertain':
                    claims.pop(key,None)
                    if key not in doubts:
                        doubts.append(key)
                else:
                    if key in doubts:
                        doubts.remove(key)
                    claims[key]=status
                    prefix={'done':'סיימתי','pending':'טרם התחלתי','partial':'עשיתי חצי מהשלב של'}[status]
                    replacement=prefix+' '+matched[0]['source']
            else:
                doubts.append(None)
                last_object=None
        elif topic and any(object_matches(topic[1],a['source']) for a in actions):
            last_object=topic[1]
        elif last_object and part in TOOLS and '?' in delimiter:
            tool=TOOLS[part]
        elif not FILLER.fullmatch(part):
            fully_read=False
            last_object=None
        rewritten.append(replacement+delimiter)
    if indirect and fully_read and tool is None:
        return pack(decision(claims.items(),dict.fromkeys(doubts)),'grounded_result')
    if indirect and not doubts and tool is None and not PLAN.search(analysis_text.replace('כשהייתי ','בזמן שהייתי ')):
        normalized=' '.join(rewritten).strip()
        return previous({**row,'input':{**req,'utterance':normalized}},raw)
    return accepted,route


def process(payload,raw):
    row=json.loads(payload)
    accepted,route=interpret(row,raw)
    return json.dumps({**simulate(row,accepted),'route':route,'accepted_text':accepted},ensure_ascii=False)
