"""Ground result clauses in their cooking event, tracking the dish across a short report."""
import json
import re

from colloquial_evidence_v60 import decision
from cooking_outcome_v77 import (COOK, END_CONDITION, METHODS, RESOLUTION, SCOPE, features,
                                 process as previous, weights)
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import ingredient
from ingredient_alternatives_v75 import amounts
from recipe_ingredient_lists_v74 import ASIDE
from turn_evidence_v58 import DOUBT, MENTION, PLAN, PRIOR_CONTEXT, simulate

BOUNDARY = re.compile(r'[.,;!…]+|\s+(?:אבל|ובכל זאת|כי)\s+')
FOLLOWUP = re.compile(r'(?:[.!…]+\s*|\s+[🙁😔]\s*)(?:מה (?:אפשר )?(?:לעשות|עושים)|איפה טעי(?:תי|נו)|למה זה קרה)\?\s*$')
PAREN = re.compile(r'\((?:שנחשב|שנחשבת) [א-ת ]+\?\)')
PAST_DISH = re.compile(r'(?:^|[.!]\s*)(?:הכנתי|בישלתי|אפיתי) (?:בשבוע שעבר|שבוע שעבר|בפעם הקודמת) (?:מרק|סלט|פשטידת|עוגת|תבשיל) ([א-ת]+)')
ATTEMPT = re.compile(r'בתנור|ולתנור|על האש|בישול|אפייה|אפיה|בישל|אפיתי|אפינו|הרתחתי|טיגנתי|צליתי|'
                     r'(?:נתתי|השארתי|השארנו).{0,15}(?:דקות|שעה|שעות)|(?:סירב|סרב|מסרב)[א-ת]* ל(?:התבשל|התרכך)')
OBSERVED = re.compile(r'(?:עדיין|עדין|עוד|נשאר[הו]?|נותר[הו]?|בפנים|במרכז) '
                      r'(?:(?:היה|היו|היתה|הייתה|נותר|קצת|ממש|די|לגמרי|עדיין|מאוד) )*'
                      r'(?:קש(?:ה|ים|ות)|בצקי[א-ת]*|לא אפוי[א-ת]*|נא(?:ה|ים|ות)?|חי(?:ה|ים|ות)?)(?![א-ת])|'
                      r'לא (?:התרכ[ךכ]|התבשל|נאפה|נאפו|נאפתה)[א-ת]*|'
                      r'(?:סירב|סרב|מסרב)[א-ת]* ל(?:התבשל|התרכך)|'
                      r'(?:קיסם|סכין|מזלג) (?:עדיין |עוד )?(?:לא נכנס|בקושי נכנס)|'
                      r'(?:נא|חי|בצקי) (?:בפנים|במרכז)|לא (?:מספיק )?(?:עשוי|מבושל|אפוי)[א-ת]*')
TIME = re.compile(r'(?:(?:גם |אפילו )?(?:אחרי|כעבור) |נתתי (?:ל[וה]|לה[םן]) )?(?:[0-9]+|[א-ת]+) (?:דקות|שעות)|'
                  r'(?:גם |אפילו )?(?:אחרי|כעבור) (?:שעה|שעתיים|חצי שעה)(?: וחצי)?')
ANAPHOR = re.compile(r'^(?:ו?(?:הם|הן|הוא|היא|זה)\b|ו?(?:עדיין|עדין|עוד|נשארו?|נותרו?|בפנים|במרכז)\b|'
                     r'נתתי לה[ןם]|(?:גם |אפילו )?(?:אחרי|כעבור) .{1,30}? (?:עוד|עדיין|הם|הן|הוא|היא)\b)')
CONTRADICT = re.compile(r'לא (?:אמ[רתי]+|התכוונתי|ניסיתי|הדלקתי|הפעלתי)|'
                        r'(?:מוכן|מוכנה|מוכנים|מוכנות|רך|רכה|רכים|רכות) (?:לגמרי|לחלוטין)|'
                        r'(?:הסתדר|הצלחתי בסוף|התברר|תיקון|טעיתי|הטעיתי|התקלקל|קשה (?:לי|להבין|לעבוד))')
ADD = re.compile(r'(?:הוספתי|הוספנו|שמתי|שמנו) (?:לתיבול |עוד |גם )?(.+)')
NO_STOCK = re.compile(r'(?:הכנתי ו)?לא (?:היה|היו|הי[י]?תה) לי (.+?)[, ]+אז (?:פשוט )?(.+)')
NO_ADD = re.compile(r'לא (?:שמתי|הוספתי)(?: (?:אותו|אותה|אותן|אותם))?(?: ועדיין יצא (?:מעולה|טעים|מצוין))?')
STAGE = re.compile(r' (?:בשלב (?:של )?ה[א-ת]+|בזמן ה[א-ת]+)$')
RESULT = re.compile(r'(?:ו?יצא[הו]? (?:ממש |מאוד |מאד |לי )?(?:מצוי+ן|טעי[םמה]+|מעולה|נפלא|מושלם)(?: ואורחים החמיאו)?|'
                    r'תודה(?: רבה)?|אהבו|אחלה מתכון)')
PAST_METHOD = {'בישלתי':'לבשל','בישלנו':'לבשל','אפיתי':'לאפות','אפינו':'לאפות','צליתי':'לצלות','טיגנתי':'לטגן'}


def mentions(obj, text):
    words = re.findall(r'[א-ת]+', text)
    for i, first in enumerate(words):
        # Hebrew allows a preposition and the conjunction to attach to the noun.
        forms = [first]
        if first.startswith('ו'):
            forms.append(first[1:])
        forms += [w[1:] for w in tuple(forms) if len(w) > 2 and w[0] in 'במלש']
        if any(ingredient(' '.join([word, *words[i+1:i+len(obj)]])) == obj for word in forms):
            return True
    return False


def linked_result(req, text):
    if not OBSERVED.search(text) or not ATTEMPT.search(text) or CONTRADICT.search(text):
        return None
    parts = [x.strip() for x in BOUNDARY.split(text) if x.strip()]
    if not parts:
        return None
    end = len(parts) - 1
    if end and TIME.fullmatch(parts[end]):
        end -= 1
    clause = parts[end]
    observed = OBSERVED.search(clause)
    if not observed:
        return None
    slots = action_slots([{**a, 'source':END_CONDITION.sub('', a['source'])} for a in req['recipe']['actions']])
    thermal = [a for a in slots if a.verb in COOK]
    subjects = [a for a in thermal if mentions(a.obj, clause)]
    if not subjects and ANAPHOR.match(clause):
        # The most recent named food is the antecedent. Never choose a food just
        # because it has the only cooking step in the checklist.
        for earlier in reversed(parts[:end]):
            subjects = [a for a in slots if mentions(a.obj, earlier)]
            if subjects:
                subjects = [a for a in subjects if a.verb in COOK]
                break
            if not (ANAPHOR.match(earlier) or re.match(r'^(?:חתכתי|חילקתי|ערבבתי) (?!את )', earlier)):
                break
    if len({a.obj for a in subjects}) != 1:
        return None
    if len(subjects) > 1:
        methods = {v for v, pattern in METHODS.items() if re.search(pattern, text)}
        subjects = [a for a in subjects if a.verb in methods]
    if len(subjects) != 1:
        return None
    # Only amplify weak lexical evidence when the learned classifier also
    # supports it. A direct report that the food did not cook has explicit scope.
    direct = re.search(r'לא (?:התבשל|נאפה|נאפו|נאפתה|התרכ[ךכ])|(?:סירב|סרב|מסרב)[א-ת]* ל', clause)
    source = next(a['source'] for a in req['recipe']['actions'] if a['id'] == subjects[0].key)
    # A recipe with a named endpoint can confirm that it was missed even when
    # a novel spelling or a long aside weakens the statistical texture signal.
    unmet_goal = ('עד לריכוך' in source and TIME.search(text) and 'קש' in observed[0])
    model = weights()
    score = max(sum(model.get(k, 0) * v for k, v in features(span).items())
                for span in (clause, observed[0]))
    if not (direct or unmet_goal or score >= 0.07):
        return None
    return subjects[0].key


def destination_add(slots, part):
    report = re.fullmatch(r'(ל[א-ת]+(?: [א-ת]+){0,3}) (?:הוספתי|הוספנו|שמתי|שמנו) (.+)', part)
    if not report:
        return None
    found = []
    for fragment in re.split(r'\s+ו(?=[א-ת])', report[2]):
        obj = ingredient(fragment + ' ' + report[1])
        hits = [a for a in slots if a.verb in ('להוסיף', 'לשים') and a.obj == obj and not a.vessel]
        if len(hits) != 1:
            return None
        found.append(hits[0].key)
    return found


def reported_items(actions, text):
    slots = action_slots(actions)
    facts = {}
    for part in (x.strip() for x in re.split(r'[.!…,;]+', text)):
        if not part or ASIDE.fullmatch(part) or RESULT.fullmatch(part):
            continue
        directed = destination_add(slots, part)
        add = ADD.fullmatch(part)
        if directed or add:
            keys = directed or amounts(slots, STAGE.sub('', add[1]))
            if not keys:
                return None
            facts.update(dict.fromkeys(keys, 'done'))
            continue
        before, _, tail = part.partition(' ')
        if before in PAST_METHOD and re.fullmatch(r'(?:יותר זמן|פחות זמן|קצת יותר)(?: ממה ש[א-ת ]+)?', tail):
            hits = [a for a in slots if a.verb == PAST_METHOD[before]]
            # Extra time alone doesn't say whether the intended result was reached.
            if len(hits) == 1 and re.search(r'ויצא (?:מצוי+ן|מעולה|טעים)', text):
                facts[hits[0].key] = 'done'
                continue
        return None
    return facts


def stock_report(actions, text):
    # The first comma may separate the two halves of the substitution.
    m = NO_STOCK.fullmatch(text)
    if not m:
        return None
    slots = action_slots(actions)
    missing = amounts(slots, m[1])
    if not missing:
        return None
    if NO_ADD.fullmatch(m[2]):
        return dict.fromkeys(missing, 'pending')
    new = reported_items(actions, m[2])
    if new and not new.keys() & set(missing):
        return {**dict.fromkeys(missing, 'pending'), **new}
    return None


def process(payload, raw):
    row = json.loads(payload)
    req = row['input']
    text = FOLLOWUP.sub('', PAREN.sub('', req['utterance'])).strip().rstrip('.!…').strip()
    earlier = PAST_DISH.match(text)
    actions = req['recipe']['actions']
    if (earlier and not re.search(r'\b(?:הפעם|עכשיו|כיום|היום|כאן|הזה|הנוכחי|והפעם|ועכשיו|והיום)\b|[.!;]', text)
            and not any(mentions(ingredient(earlier[1]), s['source']) for s in actions)):
        facts = {}
    elif any(p.search(text) for p in (SCOPE, DOUBT, MENTION, PLAN, PRIOR_CONTEXT, RESOLUTION)):
        return previous(payload, raw)
    else:
        facts = stock_report(actions, text) or reported_items(actions, text)
        if not facts:
            action = linked_result(req, text)
            if not action:
                return previous(payload, raw)
            old = json.loads(previous(payload, raw))
            accepted = json.loads(old['accepted_text'])
            facts = {f['action']:f['status'] for f in accepted['facts']}
            facts[action] = 'partial'
            doubts = [k for k in accepted['clarify'] if k is not None and k != action]
            encoded = json.dumps(decision(facts.items(), doubts=doubts), ensure_ascii=False)
            return json.dumps({**simulate(row, encoded), 'accepted_text':encoded, 'route':'linked_cooking_result'}, ensure_ascii=False)
    encoded = json.dumps(decision(facts.items()), ensure_ascii=False)
    return json.dumps({**simulate(row, encoded), 'accepted_text':encoded, 'route':'reported_recipe_events'}, ensure_ascii=False)
