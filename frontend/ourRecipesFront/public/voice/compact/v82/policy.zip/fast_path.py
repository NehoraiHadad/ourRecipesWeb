"""Handle complete, grounded turns using the existing V52 policy and renderer."""
import re

from grounded_followup_v26 import NEXT, empty
from grounded_recipe_source_v27 import apply as grounded
from recipe_text_responder_v52 import simulate
from scoped_decode_v17 import compact, safe_parse
from scoped_turn_claims_v52 import interpret

NAVIGATION = re.compile(
    r'על (?:איזה שלב|מה) דילגתי|אילו שלבים דילגתי|מה (?:נשאר לי מהשלבים הקודמים|טרם סומן בשלבים קודמים)'
)
QUANTITY = re.compile(
    r'כמה [א-ת ]{2,45} (?:כתוב|צריך) (?:להוסיף|למזוג|לשקול|להכניס)(?: לפי המתכון)?'
    r'|כמה כתוב (?:בשורה|בהוראה) (?:הראשונה|האחרונה)(?: של [א-ת ]{1,45})?'
)
AMOUNT = re.compile(r'\d|\b(?:כפית|כף|חצי|רבע|שתי|שלוש|ארבע|חמש|שש|שבע|שמונה|תשע|עשר)\b')


def run(row):
    accepted, route = interpret(row, '{}')
    if safe_parse(accepted,row):
        return simulate(row,accepted), accepted, route

    grounded_text, recognized = grounded(row, '{}')
    if recognized:
        accepted, _ = interpret(row, grounded_text)
        parsed = safe_parse(accepted,row)
        if parsed and parsed['intent'] in {'report','clarify','next'}:
            return simulate(row,accepted), accepted, 'explicit_recipe_evidence'

    text = ' '.join(row['input']['utterance'].strip().removesuffix('?').split())
    if re.fullmatch(NEXT,text):
        intent = 'next'
    elif NAVIGATION.fullmatch(text):
        intent = 'missed'
    elif QUANTITY.fullmatch(text):
        intent = 'quantity'
    else:
        return None
    accepted = compact(empty(intent),row)
    result = simulate(row,accepted)
    if intent=='quantity':
        ids = result['reply_source_ids']
        if len(ids)!=1 or not AMOUNT.search(result['reply']):
            return None
    return result, accepted, 'explicit_recipe_question'
