"""Track unfinished cooking across tense, elapsed time and explicit status repairs."""
import json
import re

from colloquial_evidence_v60 import decision
from cooking_outcome_v77 import COOK, END_CONDITION
from coordinated_claims_v62 import action_slots
from grounded_results_v79 import ATTEMPT, END, HYPOTHESIS, report_segments
from outcome_clauses_v78 import PAREN, mentions
from reader_event_roles_v73 import exact_event
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate
from validated_report_v80 import NO_TRIAL, valid_updates
from grounded_results_v79 import process as interpret_v79

NOT_READY = re.compile(r'(?:עוד |עדיין |בחלק[וה] )?לא (?:(?:היה|הייתה|היתה|היו) )?'
                       r'(?:מוכ(?:ן|נה|נים|נות)|אפוי(?:ה|ים|ות)?|מבושל(?:ת|ים|ות)?)\b|'
                       r'לא הספיק[וה]? ל(?:התרכך|התבשל|היאפות|הפשיר)|'
                       r'(?:לא הספיק[וה]?|לא הספיקה) ל[א-ת]+|חצי מבושל[תיםות]*')
ACTIVE = re.compile(r'(?:עכשיו|כרגע|בינתיים|עדיין) (?:ה[א-ת]+ )?(?:באפייה|באפיה|מתבשל[תיםות]*|'
                    r'בתהליך (?:הבישול|האפייה))\b')
FINISHED = re.compile(r'(?:עכשיו|בסוף|בסופו של דבר|ואז) (?:ה[א-ת]+ |כן |כבר )*'
                      r'(?:התרכ[ךכ]|מוכ(?:ן|נה|נים|נות)|הצליח|יצא[הו]? (?:כמו|מעולה|טעים))|'
                      r'ויצא בסוף כמו|הגיע[הו]? (?:למרקם|למצב) (?:הרצוי|הנכון)')
TIME = re.compile(r'שעה|שעות|שעתיים|דקות|דק[׳’\']|בתנור|בסיר|אחרי|במהלך')
READY_FAMILY = COOK + ('לרכך','להפשיר','לייבש')
DOUBT_ABOUT_RESULT = re.compile(r'(?:(?:אולי|יכול להיות|ייתכן|נראה לי|חושב[ת]?|לא בטוח[ה]?) [^.!?]{0,34}'
                                r'(?:לא (?:היה |היו )?(?:מוכן|מבושל|אפוי)|נשאר קשה))')
CONTROLLED = re.compile(r'(?:^|\s)(?:הוא|היא|הם|הן|הכל|זה|הבצק|המרכז|האמצע|מבפנים|בפנים|בחוץ|'
                        r'עכשיו|בסוף|כרגע|עדיין|ועכשיו)\b')


def in_progress(req, text):
    if not (NOT_READY.search(text) or ACTIVE.search(text)):
        return {}
    if any(p.search(text) for p in (NO_TRIAL, PRIOR_CONTEXT, MENTION, DOUBT_ABOUT_RESULT)):
        return {}
    parts = report_segments(text)
    report = ' '.join(parts)
    if HYPOTHESIS.search(report):
        return {}
    slots = action_slots([{**a,'source': END.sub('', END_CONDITION.sub('', a['source']))} for a in req['recipe']['actions']])
    facts = {}
    for idx, part in enumerate(parts):
        incomplete = NOT_READY.search(part) or ACTIVE.search(part)
        if not incomplete or FINISHED.search(' '.join(parts[idx:])):
            continue
        if DOUBT.search(part) or re.search(r'אולי|אם |לפי המתכון צריך|לפני ששמתי|צריך להיות', part):
            continue
        context = ' '.join(parts[max(0,idx-2):idx+1])
        if not (ATTEMPT.search(context) or TIME.search(context) or ACTIVE.search(part)
                or re.search(r'לא היה מוכן|בחלקו לא מוכן|לא הספיק להפשיר', part)):
            continue
        token = incomplete[0]
        if 'אפוי' in token or 'באפי' in token:
            verbs = ('לאפות',)
        elif 'להפשיר' in token:
            verbs = ('להפשיר',)
        else:
            verbs = READY_FAMILY
        pool = [a for a in slots if a.verb in verbs]
        named = [a for a in pool if mentions(a.obj,part)]
        if not named and idx:
            if ACTIVE.search(part) or CONTROLLED.search(part) or re.match(r'^(?:וב)?חלק[וה]|^עיסתי|^ועוד|^לא ',part):
                for prev in reversed(parts[max(0,idx-2):idx]):
                    named = [a for a in pool if mentions(a.obj,prev)]
                    if named:
                        break
        if not named and len(pool)==1 and (ACTIVE.search(part) or CONTROLLED.search(part)):
            # Avoid borrowing a unique task for a different explicitly named food.
            if not re.search(r'^(?:ו?ה[א-ת]+) (?:עוד |עדיין )?לא ', part):
                named = pool
        if len(named)==1:
            facts[named[0].key] = 'partial'
    return facts


def process(payload, raw):
    row = json.loads(payload)
    req = row['input']
    raw_result = interpret_v79(payload,raw)
    original = json.loads(raw_result)
    # Parenthetical questions about the type of a cut are not questions about
    # the reported event. Keep the display and simulation on the original text.
    text = PAREN.sub('',req['utterance'])
    clean = {**row,'input':{**req,'utterance':text}}
    reviewed = valid_updates(clean, original)
    prior = json.loads(original['accepted_text'])
    value = reviewed or prior
    facts = {f['action']: f['status'] for f in value['facts']}
    doubts = list(value['clarify'])
    if reviewed and doubts:
        slots = action_slots([{**a,'source': END.sub('', END_CONDITION.sub('', a['source']))}
                              for a in req['recipe']['actions']])
        pieces = report_segments(text)
        for key in doubts.copy():
            explicit = [exact_event(slots,p) for p in pieces[:-1]]
            old_done = any(f['action']==key and f['status']=='done' for f in prior['facts'])
            slot = next((a for a in slots if a.key==key),None)
            # A following named subject, distinct from the confirmed event, may
            # be outside the checklist. It doesn't revoke the earlier action.
            if (old_done and slot and any(a and a.key==key for a in explicit) and pieces and
                    re.match(r'^ה[א-ת]+ (?:נשאר|נותר)',pieces[-1]) and not mentions(slot.obj,pieces[-1])):
                facts[key]='done'
                doubts.remove(key)
    facts.update(in_progress(req, text))
    if (len(facts)==1 and 'partial' in facts.values() and FINISHED.search(text) and
            re.search(r'(?:לשלש|להכפיל|הכפלנו|שילשנו).{0,35}כדי (?:לכסות|להשלים)',text)):
        key, = facts
        facts[key]='done'
    doubts=[key for key in doubts if key not in facts]
    if not reviewed and facts=={f['action']:f['status'] for f in prior['facts']} and doubts==prior['clarify']:
        return raw_result
    encoded = json.dumps(decision(facts.items(),doubts=doubts),ensure_ascii=False)
    return json.dumps({**simulate(row,encoded),'accepted_text':encoded,'route':'cooking_progress'},ensure_ascii=False)
