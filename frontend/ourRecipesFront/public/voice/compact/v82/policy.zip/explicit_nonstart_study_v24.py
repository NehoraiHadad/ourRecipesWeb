"""Evaluate the V24 status correction on frozen replays and new native Q4 calls."""
import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
from unittest.mock import patch

from compare_llama_v22 import PLAN as RUNTIME_PLAN, launch, verify as verify_runtime
from explicit_nonstart_data_v24 import DATA, ROOT, build
from explicit_nonstart_v24 import apply
from fresh_pairs_v15 import PLAN as TOKENIZER_PLAN, digest, measurements, read, write
import preserve_reports_v20 as preservation
from quantized_state_v23 import state_gate
import report_scope_v21 as v21
import scoped_decode_v17 as decomposition
from sparse_recipe_v3 import aggregate, score

PLAN = ROOT / 'verification/explicit-nonstart-plan-v24-20261119.json'
FREEZE = ROOT / 'verification/explicit-nonstart-freeze-v24-20261119.json'
V21_RAW = ROOT / 'verification/report-scope-raw-v21-20261119.jsonl'
V22_RAW = ROOT / 'verification/llama-parity-raw-v22-20261119.jsonl'
V23_RAW = ROOT / 'verification/quantized-state-raw-v23-20261119.jsonl'


def verify():
    for name, expected in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != expected:
            raise ValueError(f'Changed V24 input: {name}')
    if read(DATA) != build():
        raise ValueError('V24 prospective data differs from its specification')
    verify_runtime()
    v21.verify()
    return read(PLAN)


def measure(rows, baseline, paired):
    if [p['id'] for p in baseline] != [r['id'] for r in rows]:
        raise ValueError('Response and request identity mismatch')
    output = []
    transitions = Counter()
    for row, record in zip(rows, baseline, strict=True):
        original = record['text']
        text, fixed = apply(row, original)
        a, b = score(row, original), score(row, text)
        transitions.update(status_corrections=fixed,
                           exact_fixed=not a['exact'] and b['exact'],
                           exact_broken=a['exact'] and not b['exact'])
        output.append({'id': row['id'], 'v21': original, 'text': text, 'status_corrected': fixed})
    if paired:
        before = measurements(rows, baseline)['overall']
        after = measurements(rows, output)
    else:
        before = aggregate(rows, [p['text'] for p in baseline])[0]
        after = {'overall': aggregate(rows, [p['text'] for p in output])[0]}
    return {'before': before, 'after': after, 'transitions': dict(transitions),
            'new_errors': state_gate(rows, baseline, output)}, output


def historical():
    groups = preservation.read_group(V21_RAW)
    for name, rows, paired, _ in v21.known():
        yield name, rows, paired, groups[name]
    rows = read(v21.DATA)
    for name in ('native_f16', 'native_q4'):
        base = []
        with V22_RAW.open() as source:
            for line in source:
                item = json.loads(line)
                if item['kind'] == 'final' and item['backend'] == name:
                    base.append(item)
        yield name, rows, True, base
    with V23_RAW.open() as source:
        yield 'native_q5', rows, True, [item for line in source
                                       if (item := json.loads(line))['kind'] == 'final']


def decide(groups, known_fixed, plan):
    fresh = groups['prospective_q4']
    progress = fresh['after']['overall']['exact'] - fresh['before']['exact']
    checks = {
        'prospective_exact_gain': progress >= plan['min_prospective_exact_gain'],
        'known_quantization_failures_fixed': all(known_fixed.values()),
        'no_exact_breaks': all(g['transitions']['exact_broken'] == 0 for g in groups.values()),
        'no_new_wrong_state_or_fact': all(not any(g['new_errors'].values()) for g in groups.values()),
    }
    return {'checks': checks, 'known_quantization_failures': known_fixed,
            'additional_model_calls': 0, 'passes_research_gate': all(checks.values())}


def run(assets, bin_dir, output):
    from transformers import AutoTokenizer

    plan = verify()
    output.mkdir(parents=True, exist_ok=False)
    groups, raw, known_fixed = {}, {}, {}
    for name, cases, paired, records in historical():
        groups[name], raw[name] = measure(cases, records, paired)
        known_ids = set(plan['known_ids'].get(name, []))
        for row, result in zip(cases, raw[name], strict=True):
            if row['id'] in known_ids:
                known_fixed[f'{name}/{row["id"]}'] = score(row, result['text'])['exact']
    if len(known_fixed) != sum(map(len, plan['known_ids'].values())):
        raise ValueError('Frozen known examples missing')
    write(output / 'historical.json', groups)

    runtime = read(RUNTIME_PLAN)
    model = (assets / runtime['formats']['q4_k_m']).resolve()
    expected = read(ROOT / runtime['export_manifest'])['models'][model.name]
    if model.stat().st_size != expected['bytes'] or digest(model) != expected['sha256']:
        raise ValueError('Q4 must match the verified V22 export')
    tokenizer_path = ROOT / runtime['tokenizer_base']
    hashes = read(TOKENIZER_PLAN)['model_sha256']
    for name in ('tokenizer.json', 'tokenizer_config.json'):
        if digest(tokenizer_path / name) != hashes[name]:
            raise ValueError(f'Tokenizer integrity mismatch: {name}')
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True, trust_remote_code=False)
    binary = (bin_dir / 'llama-server').resolve()
    version = subprocess.check_output([str(binary), '--version'], stderr=subprocess.STDOUT, text=True).strip()
    if runtime['llama_commit'][:9] not in version:
        raise ValueError('Incorrect llama.cpp build')

    rows = read(DATA)
    with launch(binary, model, output / 'runtime.log', runtime) as (decoder, _, _):
        with patch.object(preservation, 'model_for', lambda *a, **k: (decoder, tokenizer)), \
             patch.object(preservation, 'decode', decoder.decode), \
             patch.object(decomposition, 'decode', decoder.decode):
            inputs, work = preservation.new_inputs(rows, tokenizer_path, output, read(v21.PLAN))
        write(output / 'calls.json', decoder.calls)
    _, v20 = preservation.measure(rows, inputs, True)
    _, baseline = v21.measure(rows, v20, True)
    groups['prospective_q4'], raw['prospective_q4'] = measure(rows, baseline, True)
    write(output / 'raw.json', raw)
    report = {'runtime': version, 'q4': expected, 'groups': groups, 'work': work,
              'decision': decide(groups, known_fixed, plan)}
    write(output / 'study.json', report)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.output)
