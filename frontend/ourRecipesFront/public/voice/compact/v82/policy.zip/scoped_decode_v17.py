"""Decode clauses separately when evidence is local; abstain on explicitly ambiguous references."""
import argparse
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import re
import time
import zipfile

from fresh_pairs_data_v15 import DATA as EXPOSED,canonical
from fresh_pairs_v15 import decode,digest,measurements,write
from semantic_supervision_data_v12 import read_native
from sparse_recipe_v3 import aggregate,parse,validate
from targeted_corpus_train_v16 import ARMS,FRESH,PLAN as V16_PLAN,ROOT,decide

MANIFEST=ROOT/'verification/scoped-decode-freeze-v17-20261118.json'
UNC=re.compile(r'אולי|ייתכן|יכול(?:ה)? להיות|לא (?:זוכר|זוכרת|בטוח|בטוחה|ברור|סגור|סגורה|יודע|יודעת)|'
               r'בספק|אין לי (?:מושג|דרך|ודאות)|מתלבט|נדמה לי|להיזכר|זיכרון|לא (?:מצליח|מצליחה|יכול|יכולה|מוכן|מוכנה) (?:להעיד|לקבוע|להתחייב|לומר)')
SPLIT=re.compile(r';\s*|(?<=\.)\s+|,\s*(?=(?:אבל|וגם|ואת|ועל|ואז|ו[א-ת]{2,}תי)\b)|'
                 r'\s+(?=(?:אבל|וגם|ואת|ועל|ואז|וכבר|ו[א-ת]{2,}תי)\b)')
CUES=re.compile(r'^\s*(?:עוד מעט|אחרי השיחה|מאוחר יותר|כשאתפנה|יש לי תוכנית|אני (?:קורא|קוראת|מקריא|מקריאה)|'
                r'אמרתי ש(?:עוד מעט|בהמשך)|[״"]|מישהו הציע\s*[:״"])')
NEXT=re.compile(r'מה\s+(?:עכשיו|השלב הבא|הצעד הבא|לעשות|בא |עושים)|איך\s+ממשיכים')
ANAPHOR=re.compile(r'(?:\b[בשולמ]?(?:זה|זאת)\b|\bאותה\b|\bההיא\b|המשימה ש|מה ש(?:דיברנו|סיכמנו)|הדבר הזה|הפעולה הזאת|הצעד ש)')
COMPLETED=re.compile(r'סיימתי|גמרתי|בוצע|עשיתי|בוצעה|גמורה|סגרתי|מאחוריי|נעשה|הושלם|הסתיים|טיפלתי|ביצעתי')
UNRESOLVED=re.compile(r'לא (?:סיכמנו|בחרנו|אמרת|ברור|נבחר)|אחת מהן|לאיזו|שתיהן אפשריות|שתי (?:אפשרויות|פעולות|משימות)|על מה מדובר')
STOPWORDS={'של','את','שלי','על','לי','עם','לגבי','שלו','שלה','כבר','לא','אם','אולי','התחלתי','סיימתי','אני','סוף','שלב','פעולה','להוסיף'}


def read(path):
    return json.loads(path.read_text())


def verify():
    for name,sha in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name)!=sha:
            raise ValueError('Frozen V17 file changed: '+name)


def safe_parse(text,row):
    try:
        return parse(text,row['input'])
    except (ValueError,TypeError,KeyError):
        return None


def compact(value,row):
    validate(value,row['input'])
    return json.dumps(value,ensure_ascii=False,separators=(',',':'))


def literal_ids(text,request):
    quoted=canonical(text).replace('.','')
    return {a['id'] for a in request['recipe']['actions'] if canonical(a['source']).rstrip('.') in quoted}


def stem_words(text):
    words=set()
    for word in re.findall(r'[א-ת]+',text):
        if len(word)>4 and word[0] in 'וה':
            word=word[1:]
        if len(word)>3 and word not in STOPWORDS:
            words.add(word)
    return words


def unique_lexical_id(text,request):
    words=stem_words(text)
    scores={a['id']:len(words & stem_words(a['source'])) for a in request['recipe']['actions']}
    if not scores or max(scores.values())<1:
        return None
    best=[i for i,s in scores.items() if s==max(scores.values())]
    return best[0] if len(best)==1 else None


def unresolved_history(request):
    text=request['utterance']
    if (len(text)>95 or '?' in text or not ANAPHOR.search(text) or not COMPLETED.search(text)
            or UNC.search(text) or NEXT.search(text) or literal_ids(text,request)
            or unique_lexical_id(text,request) is not None):
        return False
    history=request['history']
    if not history:
        return True
    turns=history[-2:]
    last=turns[-1]['content']
    if not UNRESOLVED.search(last):
        return False
    return len(literal_ids(' '.join(turn['content'] for turn in turns),request))>=2


def explicit_nonreport(text):
    # Only a single prospective/quoted clause followed by a pure navigation question.
    if not CUES.search(text) or not NEXT.search(text):
        return False
    match=NEXT.search(text)
    beginning=text[:match.start()]
    return (not re.search(r'\b(?:אבל|וגם|ואילו|ואז)\b|[.;!]',beginning.rstrip(' ,.?!'))
            and len(text[match.start():].split())<=8)


def clean_part(text):
    part=text.strip(' ,.\t')
    part=re.sub(r'^(?:אבל|וגם|ואז)\s+','',part)
    part=re.sub(r'^ו(?=(?:את|על|כבר|[א-ת]{2,}תי)\b)','',part)
    return part


def routes(row,raw):
    request=row['input']
    text=request['utterance']
    decoded=safe_parse(raw,row)
    if not decoded:
        return 'original',None
    if unresolved_history(request):
        return 'history',{'intent':'clarify','facts':[],'clarify':[None]}
    if explicit_nonreport(text):
        return 'nonreport',{'intent':'next','facts':[],'clarify':[]}
    if '?' in text or request['history'] or len(text)<32 or CUES.search(text):
        return 'original',None
    parts=[clean_part(p) for p in SPLIT.split(text)]
    parts=[p for p in parts if p]
    if len(parts)!=2 or min(map(len,parts))<9 or sum(bool(UNC.search(p)) for p in parts)>1:
        return 'original',None
    if not any(UNC.search(p) for p in parts) and len(decoded['facts'])!=1:
        return 'original',None
    # A shared, uniquely named object across clauses may describe a correction of one action.
    hypotheses=[unique_lexical_id(p,request) for p in parts]
    if not any(hypotheses) or (hypotheses[0] is not None and hypotheses[0]==hypotheses[1]):
        return 'original',None
    return 'split',parts


def merge(row,original,parts,responses):
    request=row['input']
    parsed=[safe_parse(text,{**row,'input':{**request,'utterance':part}}) for part,text in zip(parts,responses,strict=True)]
    if not all(parsed):
        return original
    kept=[]
    clarify=[]
    for part,value in zip(parts,parsed,strict=True):
        lexical=unique_lexical_id(part,request)
        if UNC.search(part):
            proposals={x for x in value['clarify'] if x is not None}|{f['action'] for f in value['facts']}
            if lexical is not None:
                if proposals and lexical not in proposals:
                    return original
                proposals={lexical}
            if len(proposals)!=1:
                return original
            clarify.extend(proposals)
        else:
            fs=value['facts']
            if len(fs)!=1 or value['clarify'] or (lexical is not None and lexical!=fs[0]['action']):
                return original
            kept.extend(fs)
    ids=[f['action'] for f in kept]
    if not kept or len(set(ids))!=len(ids) or set(ids)&set(clarify):
        return original
    proposal={'intent':'report','facts':kept,'clarify':clarify}
    return compact(proposal,row)


def model_for(folder,source_zip,source_sha,arm,artifacts,plan):
    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM,AutoTokenizer

    for name,sha in plan['model_sha256'].items():
        if digest(folder/name)!=sha:
            raise ValueError('Public CPU model files differ from V15 freeze')
    if digest(source_zip)!=source_sha:
        raise ValueError('Control checkpoint archive changed')
    path=artifacts/'adapter'
    path.mkdir()
    with zipfile.ZipFile(source_zip) as archive:
        inv=json.loads(archive.read('MANIFEST.json'))
        for name in ('adapter_config.json','adapter_model.safetensors'):
            item=f'study/{arm}/checkpoint-160/{name}'
            raw=archive.read(item)
            if hashlib.sha256(raw).hexdigest()!=inv[item]['sha256']:
                raise ValueError('Control checkpoint differs from verified SHA')
            (path/name).write_bytes(raw)
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    tokenizer=AutoTokenizer.from_pretrained(folder,local_files_only=True,trust_remote_code=False)
    tokenizer.padding_side='left'
    tokenizer.pad_token=tokenizer.pad_token or tokenizer.eos_token
    base=AutoModelForCausalLM.from_pretrained(folder,local_files_only=True,trust_remote_code=False,
                                             dtype=torch.bfloat16,attn_implementation='sdpa')
    return PeftModel.from_pretrained(base,path,is_trainable=False).eval(),tokenizer


def apply(rows,baseline,model,tokenizer,plan):
    jobs=[]
    decided=[]
    counts=Counter()
    for row,raw in zip(rows,baseline,strict=True):
        if row['id']!=raw['id']:
            raise ValueError('Base output order disagrees with the benchmark')
        kind,aux=routes(row,raw['text'])
        counts[kind]+=1
        decided.append((kind,aux))
        if kind=='split':
            for i,part in enumerate(aux):
                jobs.append({**row,'id':f'{row["id"]}/clause{i}',
                             'input':{**row['input'],'utterance':part}})
    start=time.monotonic()
    answers=decode(model,tokenizer,jobs,plan,start+plan['cpu_budget_seconds'])
    chosen=[]
    j=0
    for row,base,(kind,item) in zip(rows,baseline,decided,strict=True):
        original=base['text']
        if kind=='original':
            text=original
        elif kind=='split':
            text=merge(row,original,item,[a['text'] for a in answers[j:j+2]])
            j+=2
        else:
            text=compact(item,row)
        chosen.append({'id':row['id'],'text':text,'original':original,'path':kind})
    return chosen,{'routes':dict(counts),'additional_clause_calls':len(jobs),'cpu_seconds':time.monotonic()-start,
                   'changed_outputs':sum(c['text']!=c['original'] for c in chosen)},answers


def exposed_run(output,folder):
    from fresh_pairs_v15 import PLAN

    plan=read(PLAN)
    old=plan['archive']
    baseline=read(ROOT/'runs/ourrecipes-fresh-pairs-v15-20261118/primary_only-fresh.json')
    rows=read(EXPOSED)
    output.mkdir(parents=True)
    model,tok=model_for(folder,ROOT/old['path'],old['sha256'],'primary_only',output,plan)
    chosen,counts,fragments=apply(rows,baseline,model,tok,plan)
    write(output/'fresh-raw.json',chosen)
    write(output/'fragments.json',fragments)
    write(output/'study.json',{'exposed_diagnostic':True,'baseline':measurements(rows,baseline),
                               'candidate':measurements(rows,chosen),'work':counts})


def confirm_run(output,folder,v16):
    from fresh_pairs_v15 import PLAN

    plan=read(PLAN)
    outcome=read(v16/'recovery.json')
    if read(v16/'owner-state.json')['phase']!='stopped' or outcome['status']!='complete':
        raise ValueError('V16 custody or completion was not verified')
    v16base=v16/'recovered/study'/ARMS[0]
    groups={'fresh':read(FRESH),**{k:read_native()[k] for k in ('validation','diagnostic','regression')}}
    output.mkdir(parents=True)
    model,tok=model_for(folder,v16/'results.zip',outcome['sha256'],ARMS[0],output,plan)
    baselines,results,logs,fragments={},{},{},{}
    index={'fresh':'fresh-','validation':'','diagnostic':'diagnostic-','regression':'regression-'}
    for name,rows in groups.items():
        raw=read(v16base/f'validation-step-{index[name]}160.json')['records']
        new,logs[name],fragments[name]=apply(rows,raw,model,tok,plan)
        baselines[name]=raw
        results[name]=new
    write(output/'raw.json',results)
    write(output/'fragments.json',fragments)
    def scores(pred):
        acc=lambda names:aggregate([r for g in names for r in groups[g]],[x['text'] for g in names for x in pred[g]])[0]
        return {'fresh':measurements(groups['fresh'],pred['fresh']),
                'known':{'regression':acc(['regression']),'all_development':acc(['validation','diagnostic'])}}
    a,b=scores(baselines),scores(results)
    write(output/'study.json',{'baseline':a,'candidate':b,'work':logs,'decision':decide(a,b,read(V16_PLAN)),
                               'design':'Archived V16 T4 control generation in both arms; added split calls local CPU BF16.'})


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('--model-folder',type=Path,required=True)
    parser.add_argument('--v16',type=Path)
    args=parser.parse_args()
    verify()
    if args.v16:
        confirm_run(args.output,args.model_folder,args.v16)
    else:
        exposed_run(args.output,args.model_folder)
