"""Compare one Q5 alternative against the saved V22 F16 and Q4 runs."""
import argparse
from pathlib import Path
from statistics import median
import subprocess
from unittest.mock import patch

from compare_llama_v22 import PLAN, compare, launch, peak_rss, verify
from fresh_pairs_v15 import PLAN as TOKENIZER_PLAN, digest, read, write
import preserve_reports_v20 as preservation
from report_scope_v21 import DATA, PLAN as SCOPE_PLAN, ROOT, measure as apply_report_scope
import scoped_decode_v17 as decomposition
from sparse_recipe_v3 import score

FREEZE = ROOT / 'verification/quantized-state-freeze-v23-20261119.json'


def state_gate(rows, reference, candidate):
    differences = {'new_wrong_facts': {}, 'new_wrong_state': {}}
    for row, before, after in zip(rows, reference, candidate, strict=True):
        baseline = score(row, before['text'])
        current = score(row, after['text'])
        new_facts = [item for item in current['wrong_facts'] if item not in baseline['wrong_facts']]
        new_states = [item for item in current['wrong_state'] if item not in baseline['wrong_state']]
        if new_facts:
            differences['new_wrong_facts'][row['id']] = new_facts
        if new_states:
            differences['new_wrong_state'][row['id']] = new_states
    return differences


def run(assets, bin_dir, native, output):
    from transformers import AutoTokenizer

    verify()
    frozen = read(FREEZE)
    for filename, expected in frozen['sha256'].items():
        if digest(ROOT / filename) != expected:
            raise ValueError(f'Frozen V23 input changed: {filename}')
    plan = read(PLAN)
    f16 = assets / 'model-f16.gguf'
    f16_proof = read(ROOT / plan['export_manifest'])['models'][f16.name]
    if f16.stat().st_size != f16_proof['bytes'] or digest(f16) != f16_proof['sha256']:
        raise ValueError('V22 F16 integrity mismatch')
    references = {}
    for name, expected in frozen['native_reference_sha256'].items():
        path = native / name / 'final.json'
        if digest(path) != expected:
            raise ValueError(f'Native reference integrity mismatch: {name}')
        references[name] = read(path)
    tokenizer_path = ROOT / plan['tokenizer_base']
    hashes = read(TOKENIZER_PLAN)['model_sha256']
    for name in ('tokenizer.json', 'tokenizer_config.json'):
        if digest(tokenizer_path / name) != hashes[name]:
            raise ValueError(f'Tokenizer integrity mismatch: {name}')
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True, trust_remote_code=False)
    binary = (bin_dir / 'llama-server').resolve()
    version = subprocess.check_output([str(binary), '--version'], stderr=subprocess.STDOUT, text=True).strip()
    if plan['llama_commit'][:9] not in version:
        raise ValueError('Incorrect llama.cpp build')

    rows = read(DATA)
    output.mkdir(parents=True, exist_ok=False)
    model = (output / 'model-q5_k_m.gguf').resolve()
    with (output / 'quantize.log').open('x') as log:
        subprocess.run([str(bin_dir / 'llama-quantize'), str(f16.resolve()), str(model), 'Q5_K_M', '4'],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    proof = {'bytes': model.stat().st_size, 'sha256': digest(model)}
    report = {'study': 'quantized-state-v23', 'runtime': version, 'format': proof,
              'within_download_budget': proof['bytes'] <= plan['max_download_bytes']}
    if not report['within_download_budget']:
        write(output / 'report.json', report | {'passes': False})
        return

    with launch(binary, model, output / 'runtime.log', plan) as (decoder, pid, load_seconds):
        with patch.object(preservation, 'model_for', lambda *a, **k: (decoder, tokenizer)), \
             patch.object(preservation, 'decode', decoder.decode), \
             patch.object(decomposition, 'decode', decoder.decode):
            inputs, work = preservation.new_inputs(rows, tokenizer_path, output, read(SCOPE_PLAN))
        _, v20 = preservation.measure(rows, inputs, True)
        _, final = apply_report_scope(rows, v20, True)
        timings = {'load_seconds': load_seconds, 'peak_process_rss_bytes': peak_rss(pid),
                   'median_first_visible_text_seconds': median(
                       c['first_visible_text_seconds'] for c in decoder.calls
                       if c['first_visible_text_seconds'] is not None),
                   'total_generation_seconds': sum(c['seconds'] for c in decoder.calls)}
    write(output / 'final.json', final)
    write(output / 'calls.json', decoder.calls)
    comparison = compare(rows, references['f16'], final, plan)
    states = state_gate(rows, references['f16'], final)
    facts_retained = comparison['candidate']['overall']['facts_exact'] >= comparison['reference']['overall']['facts_exact']
    write(output / 'report.json', report | {
        'f16_to_q5': comparison, 'q4_to_q5': compare(rows, references['q4_k_m'], final, plan),
        'state_gate': states, 'facts_retained': facts_retained,
        'passes': comparison['passes'] and facts_retained and not any(states.values()),
        'timings': timings, 'work': work, 'matched_prompt_token_ids': len(decoder.calls)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('native_v22', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.native_v22, args.output)
