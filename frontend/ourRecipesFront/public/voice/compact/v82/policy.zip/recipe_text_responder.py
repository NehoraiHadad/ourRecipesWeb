"""Render a Hebrew reply from the active recipe and a validated research interpretation."""
import re

from grounded_scope_v18 import WORDS, forms, grounded_actions
from sparse_recipe_v3 import facts, parse

ACKNOWLEDGMENT = {'done': 'בוצע', 'partial': 'בוצע חלקית', 'pending': 'טרם בוצע'}
ORDER = re.compile(r'\b(?:מה|איזה|איזו|איך)\s+(?:(?:השלב|הפעולה|באים|בא|נשאר|מגיע|מגיעה|צריך|עושים|הצעד)\s+)*(לפני|אחרי)\s+')
POSITION_WORD = r'הראשון|הראשונה|האחרון|האחרונה'
POSITION = re.compile(rf'\b(?:ב|מ)?ה?(הוראה|שורה|שלב|צעד)\s+({POSITION_WORD})\b')


def match_recipe_actions(request):
    utterance = request['utterance']
    words = set(WORDS.findall(utterance))
    anchored = grounded_actions(utterance, request)
    actions = request['recipe']['actions']
    literal = [a for a in actions if a['source'].strip().rstrip('.') in utterance]
    if literal:
        return literal
    explicit = [a for a in actions if a['id'] in anchored and set(WORDS.findall(a['source'])[:1]) & words]
    if explicit:
        return explicit
    # Prefer the candidate with the most specific shared object words.
    options = [a for a in actions if a['id'] in anchored]
    if not options:
        return []
    cue = forms(utterance)
    scores = [len(cue & forms(' '.join(WORDS.findall(a['source'])[1:]))) for a in options]
    best = max(scores)
    return [a for a, score in zip(options, scores, strict=True) if score == best]


def positional_actions(utterance, actions):
    position = POSITION.search(utterance)
    if position is None:
        return None
    if (len(re.findall(rf'\b(?:{POSITION_WORD})\b', utterance)) != 1 or not actions
            or re.search(r'\bלא\s*$',utterance[:position.start()])):
        return []
    index = 0 if position[2].startswith('הראשו') else -1
    action = actions[index]
    if position[1] in ('שלב','צעד'):
        return [a for a in actions if a['step'] == action['step']]
    return [action]


def render(request, interpretation):
    actions = sorted(request['recipe']['actions'], key=lambda action: action['step'])
    by_id = {action['id']: action for action in actions}
    progress = {**request['progress'], **dict(facts(interpretation))}
    remaining = [action for action in actions if progress[action['id']] != 'done']
    intent = interpretation['intent']
    accepted = interpretation['facts']
    pieces, cited = [], []

    def cite(action):
        cited.append(action['id'])
        return action['source'].strip().rstrip('.')

    if accepted:
        updates = [f'{cite(by_id[fact["action"]])} — {ACKNOWLEDGMENT[fact["status"]]}' for fact in accepted]
        pieces.append('עדכנתי: ' + ', '.join(updates) + '.')

    targets = interpretation['clarify']
    if targets:
        questions = ['לאיזו פעולה התכוונת?' if target is None else
                     f'מה מצב הפעולה ״{cite(by_id[target])}״ — בוצעה, בוצעה חלקית או טרם בוצעה?'
                     for target in targets]
        pieces.extend(questions)
        if intent in ('next', 'missed', 'report', 'clarify'):
            return ' '.join(pieces), list(dict.fromkeys(cited))

    if intent == 'next':
        # Earlier unfinished work can matter even if navigation is already on a later step.
        if not remaining:
            pieces.append('כל הפעולות במתכון מסומנות כהושלמו.')
        else:
            next_action = remaining[0]
            if progress[next_action['id']] == 'partial':
                pieces.append(f'הצעד הבא הוא להשלים: {cite(next_action)}.')
            else:
                pieces.append(f'הצעד הבא לפי המתכון: {cite(next_action)}.')
    elif intent == 'missed':
        earlier = [action for action in remaining if action['step'] < request['currentStep']]
        if earlier:
            pieces.append('מה שנשאר מהשלבים הקודמים: ' + ', '.join(cite(a) for a in earlier) + '.')
        else:
            pieces.append('אין פעולות פתוחות בשלבים שלפני השלב הנוכחי.')
    elif intent in ('quantity', 'explain'):
        selected = match_recipe_actions(request)
        positioned = positional_actions(request['utterance'],actions)
        if positioned is not None:
            selected = [a for a in positioned if not selected or a in selected]
        if len(selected) != 1:
            pieces.append('לאיזו פעולה או לאיזה מרכיב במתכון התכוונת?')
        else:
            action = selected[0]
            order = ORDER.search(request['utterance']) if intent == 'explain' else None
            if order is None:
                pieces.append(f'כך כתוב במתכון: {cite(action)}.')
            else:
                direction = -1 if order.group(1) == 'לפני' else 1
                position = actions.index(action) + direction
                if 0 <= position < len(actions):
                    pieces.append(f'לפי סדר המתכון: {cite(actions[position])}.')
                else:
                    pieces.append(f'אין במתכון פעולה {order.group(1)} הפעולה הזאת.')
    elif not pieces:
        pieces.append('אפשר לשאול על הצעד הבא או לעדכן מה כבר בוצע במתכון.')
    return ' '.join(pieces), list(dict.fromkeys(cited))


def simulate(row, proposal_text):
    request = row['input']
    try:
        decision = parse(proposal_text, request)
    except (ValueError, TypeError, KeyError):
        decision = {'intent': 'clarify', 'facts': [], 'clarify': [None]}
    reply, sources = render(request, decision)
    recipe = request['recipe']
    writes = [{**update, 'recipe_id': recipe['id'], 'recipe_version': recipe['version']}
              for update in decision['facts']]
    return {'id': row['id'], 'proposal_text': proposal_text, 'reply': reply, 'reply_source_ids': sources,
            'writes': writes, 'intent': decision['intent'], 'clarify': decision['clarify']}
