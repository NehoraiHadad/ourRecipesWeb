"""Apply statements about the remaining portion to that portion's operation."""
import json
import re

from coordinated_claims_v62 import action_slots
from elliptical_events_v66 import EVIDENCE, NEUTRAL, interpret as previous, process as previous_process
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

BOUNDARY=re.compile(r'\s*(?:[,.;]\s*(?:אבל\s+|ואילו\s+)?|\s+(?:אבל|ואילו|ואז)\s+|\s+ו(?=את השאר))')
REMAINDER=re.compile(r'(?<![א-ת])ו?(?:את )?(?:השאר|היתר|החצי השני|החלק הנותר)(?![א-ת])')
WHOLE=re.compile(r'(?<![א-ת])(?:את )?(?:כולם|כולן|כולו|כולה)(?![א-ת])')


def portion_decision(row):
    req=row['input']
    text=req['utterance'].strip().rstrip('.!')
    if not (REMAINDER.search(text) or WHOLE.search(text)):
        return None
    if '?' in text or any(c in text for c in '"״“”') or any(p.search(text) for p in (PRIOR_CONTEXT,DOUBT,MENTION)):
        return None
    matches=list(BOUNDARY.finditer(text))
    if not matches:
        return None
    split=matches[-1]
    first=text[:split.start()]
    tail=text[split.end():]
    remainder=REMAINDER.search(tail)
    whole=WHOLE.search(tail)
    if bool(remainder)==bool(whole):
        return None
    def grounded(fragment):
        local={**row,'input':{**req,'utterance':fragment}}
        value,route=previous(local,NEUTRAL)
        parsed=json.loads(value)
        return parsed if route in EVIDENCE and parsed['facts'] and not parsed['clarify'] else None

    prior=grounded(first)
    if not prior:
        return None
    last=prior['facts'][-1]
    if remainder and last['status']!='partial':
        return None
    slots=action_slots(req['recipe']['actions'])
    source=next((a for a in slots if a.key==last['action']),None)
    if not source:
        return None
    marker=remainder or whole
    stated=tail[:marker.start()]+'את '+' '.join(source.obj)+tail[marker.end():]
    final=grounded(stated)
    if not final or len(final['facts'])!=1:
        return None
    update=final['facts'][0]
    status=update['status']
    if remainder:
        if update['action']==source.key:
            # A completed remainder closes the operation. Any unfinished
            # remainder leaves the previously completed portion in place.
            status='done' if status=='done' else 'partial'
        elif status=='done':
            status='partial'
        else:
            # A negative report about part of a different operation does not
            # establish the status of that whole operation.
            return None
    facts={f['action']:f['status'] for f in prior['facts']}
    facts[update['action']]=status
    return json.dumps({'intent':'report','facts':[{'action':key,'status':value} for key,value in facts.items()],
                       'clarify':[]},ensure_ascii=False)


def interpret(row,raw):
    accepted=portion_decision(row)
    if accepted is not None:
        return accepted,'portion_scope'
    return previous(row,raw)


def process(payload,raw):
    row=json.loads(payload)
    accepted=portion_decision(row)
    if accepted is None:
        return previous_process(payload,raw)
    return json.dumps({**simulate(row,accepted),'accepted_text':accepted,'route':'portion_scope'},ensure_ascii=False)
