"""Compare a fixed report-scope prompt against the existing Q4 pipeline."""
import argparse
from collections import Counter
from pathlib import Path
from unittest.mock import patch

from broad_text_data_v28 import DATA as BROAD_DATA
from broad_text_study_v28 import verify as verify_prior
import compare_llama_v22 as native
from fresh_pairs_v15 import digest, measurements, read, write
from grounded_progress_study_v25 import generate_q4
from grounded_recipe_source_v27 import apply
from report_prompt_data_v29 import DATA, ROOT, build
from report_prompt_v29 import illustrated_messages
from sparse_recipe_v3 import facts, parse, score

FREEZE = ROOT / 'verification/report-prompt-freeze-v29-20261119.json'
PLAN = ROOT / 'verification/report-prompt-plan-v29-20261119.json'


def verify():
    verify_prior()
    for name, sha in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != sha:
            raise ValueError(f'Changed V29 input: {name}')
    if read(DATA) != build():
        raise ValueError('V29 data differs from its specification')
    return read(PLAN)


def assess(rows, results):
    values = measurements(rows, results)
    retained = Counter()
    for row, record in zip(rows, results, strict=True):
        expected = set(facts(row['expected']))
        retained['expected'] += len(expected)
        try:
            actual = set(facts(parse(record['text'], row['input'])))
        except (ValueError, TypeError, KeyError):
            actual = set()
        retained['correct'] += len(actual & expected)
    values['correct_reported_facts'] = dict(retained)
    return values


def compare(rows, prior, candidate):
    ids = [row['id'] for row in rows]
    if ids != [r['id'] for r in prior] or ids != [r['id'] for r in candidate]:
        raise ValueError('Response and request identity mismatch')
    output = []
    switches = Counter()
    for row, a, b in zip(rows, prior, candidate, strict=True):
        base, proposal = (apply(row, record['text'])[0] for record in (a, b))
        control, variant = score(row, base), score(row, proposal)
        switches.update(fixed_exact=not control['exact'] and variant['exact'],
                        broke_exact=control['exact'] and not variant['exact'])
        output.append({'id': row['id'], 'control_v21': a['text'], 'illustrated_v21': b['text'],
                       'control_v27': base, 'illustrated_v27': proposal})
    results = {arm: assess(rows, [{'id': r['id'], 'text': r[f'{arm}_v27']} for r in output])
               for arm in ('control', 'illustrated')}
    return {**results, 'switches': dict(switches)}, output


def decide(summary, plan, fresh):
    a, b = (summary[k]['overall'] for k in ('control', 'illustrated'))
    x, y = (summary[k]['correct_reported_facts']['correct'] for k in ('control', 'illustrated'))
    start, end = a['critical_wrong_fact_cases'], b['critical_wrong_fact_cases']
    checks = {'full_interpretation_retained': b['exact'] >= a['exact'] - plan['max_exact_loss'],
              'real_facts_retained': y >= x - plan['max_correct_fact_loss'],
              'no_extra_invalid': b['valid'] >= a['valid']}
    if fresh:
        checks['reduced_false_reports'] = start - end >= plan['min_false_reports_removed'] and 3 * end <= 2 * start
    else:
        checks['no_increase_false_reports'] = end <= start
    return {'checks': checks, 'passed': all(checks.values())}


def run(assets, bin_dir, output):
    plan = verify()
    output.mkdir(parents=True, exist_ok=False)
    rows = read(DATA)
    runs = {}
    for arm, prompt in (('control', native.messages), ('illustrated', illustrated_messages)):
        print(f'Prospective: {arm}', flush=True)
        leaf = output / arm
        leaf.mkdir()
        with patch.object(native, 'messages', prompt):
            baseline, runs[arm] = generate_q4(rows, assets, bin_dir, leaf)
        write(leaf / 'assembled.json', baseline)
    summary, results = compare(rows, *(read(output / k / 'assembled.json') for k in runs))
    fresh = decide(summary, plan['fresh_gate'], True)
    write(output / 'fresh.json', results)
    report = {'runs': runs, 'fresh': summary, 'fresh_gate': fresh,
              'broad_evaluation': 'skipped after prospective failure'}
    write(output / 'study.json', report)
    if fresh['passed']:
        print('V28 retention', flush=True)
        rows = read(BROAD_DATA)
        baseline = read(ROOT / plan['broad_control'])
        leaf = output / 'broad'
        leaf.mkdir()
        with patch.object(native, 'messages', illustrated_messages):
            candidate, runs['broad'] = generate_q4(rows, assets, bin_dir, leaf)
        write(leaf / 'assembled.json', candidate)
        summary, results = compare(rows, baseline, candidate)
        write(output / 'broad.json', results)
        report.update(broad_evaluation='complete', broad=summary,
                      broad_gate=decide(summary, plan['broad_gate'], False))
        write(output / 'study.json', report)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('assets', type=Path)
    parser.add_argument('bin_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.assets, args.bin_dir, args.output)
