"""Keep separately grounded earlier facts when V19 replaces the full answer with a colon tail."""
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path
import re
import time

from fresh_pairs_v15 import PLAN as DECODER_PLAN, decode, digest, measurements, read, write
from grounded_clause_v19 import PARTIAL, INCOMPLETE, cache, doubt, install, one_clause
from grounded_scope_data_v18 import DATA as V18_DATA
from grounded_scope_v18 import grounded_actions, old_groups, restrict
from preserve_reports_data_v20 import DATA,ROOT,build
from scoped_decode_v17 import CUES, SPLIT, apply, clean_part, compact, model_for, safe_parse
from sparse_recipe_v3 import aggregate, score

PLAN=ROOT/'verification/preserve-reports-plan-v20-20261119.json'
MANIFEST=ROOT/'verification/preserve-reports-freeze-v20-20261119.json'
V18_RAW=ROOT/'verification/grounded-scope-raw-v18-20261119.jsonl'
V19_RAW=ROOT/'verification/grounded-clause-raw-v19-20261119.jsonl'
PAST=re.compile(r'\b[א-ת]{2,}תי\b|אני באמצע')
QUOTE=re.compile(r'[״"]|\b(?:מקריא|מקריאה|מצטט|מצטטת|תוכנית|התכוונתי|תכננתי)\b')


def verify():
    for name,sha in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name)!=sha:
            raise ValueError(f'Changed V20 freeze: {name}')
    if read(DATA)!=build():
        raise ValueError('V20 evaluation does not match its authored specification')


def protect(row,prior,result,route):
    """Re-use only a fact from the full-turn result with separate, matching evidence."""
    if route!='explicit' or result==prior:
        return result,0
    old,current=safe_parse(prior,row),safe_parse(result,row)
    if not old or not current or current['intent']!='report' or len(current['facts'])!=1:
        return result,0
    text=row['input']['utterance']
    lead,tail=text.split(':',1)
    excluded=grounded_actions(tail,row['input'])|{current['facts'][0]['action']}|set(current['clarify'])
    prior_facts={f['action']:f for f in old['facts']}
    keep={}
    for part in map(clean_part,SPLIT.split(lead)):
        if not PAST.search(part) or doubt(part) or CUES.search(part) or QUOTE.search(part):
            continue
        ids=grounded_actions(part,row['input'])-excluded
        desired='partial' if PARTIAL.search(part) or INCOMPLETE.search(part) else 'done'
        candidates=[prior_facts[action] for action in sorted(ids & prior_facts.keys())
                    if prior_facts[action]['status']==desired]
        if len(candidates)==1:
            keep[candidates[0]['action']]=candidates[0]
    if not keep:
        return result,0
    combined={**current,'facts':list(keep.values())+current['facts']}
    return compact(combined,row),len(keep)


def read_group(path):
    by_group=defaultdict(list)
    for line in path.read_text().splitlines():
        value=json.loads(line)
        by_group[value.pop('group')].append(value)
    return by_group


def replay_groups():
    v18,v19=read_group(V18_RAW),read_group(V19_RAW)
    datasets={g:(r,p) for g,r,_,p in old_groups()}
    datasets['v18_challenge']=(read(V18_DATA),True)
    for group,(rows,paired) in datasets.items():
        key='fresh' if group=='v18_challenge' else group
        values=[]
        for row,p,q in zip(rows,v18[key],v19[key],strict=True):
            if row['id']!=p['id'] or row['id']!=q['id'] or p['v18']!=q['v18']:
                raise ValueError('Mismatch between frozen historical outputs')
            values.append({'id':q['id'],'prior':q['v18'],'v19':q['text'],'route':q['route']})
        yield group,rows,paired,values


def measure(rows,raw,paired):
    output=[]
    transitions=Counter()
    for row,value in zip(rows,raw,strict=True):
        if row['id']!=value['id']:
            raise ValueError('V20 row alignment changed')
        revised,kept=protect(row,value['prior'],value['v19'],value['route'])
        a,b=score(row,value['v19']),score(row,revised)
        transitions.update(exact_fixed=not a['exact'] and b['exact'],exact_broken=a['exact'] and not b['exact'],
                           restored_facts=kept,changed_responses=revised!=value['v19'])
        output.append({**value,'text':revised,'restored_facts':kept})
    before=[{'id':r['id'],'text':r['v19']} for r in output]
    evaluate=(lambda rs:measurements(rows,rs)) if paired else (lambda rs:aggregate(rows,[r['text'] for r in rs])[0])
    return {'v19':evaluate(before),'v20':evaluate(output),'transitions':dict(transitions)},output


def decide(groups, raw, rows, plan):
    cfg=plan['gate']
    def metric(group,arm):
        stats=groups[group][arm]
        return stats.get('overall',stats)
    a,b=(metric('fresh',key) for key in ('v19','v20'))
    diagnostic={r['id']:(row,r) for row,r in zip(rows,raw['diagnostic'],strict=True)}
    protected={
        ident:score(diagnostic[ident][0],diagnostic[ident][1]['text'])['exact']
        for ident in plan['known_bug_ids']
    }
    checks={'known_examples_restored':all(protected.values()),
            'fresh_gain':b['exact']-a['exact']>=cfg['min_fresh_exact_gain'],
            'fresh_wrong_fact_safety':b['cases_with_wrong_facts']<=a['cases_with_wrong_facts'],
            'known_and_prior_exact_retained':all(metric(g,'v20')['exact']>=metric(g,'v19')['exact']
                                                  for g in groups if g!='fresh'),
            'critical_safety_on_all_groups':all(metric(g,'v20')['critical_wrong_fact_cases']
                                                 <=metric(g,'v19')['critical_wrong_fact_cases'] for g in groups),
            'fresh_restorations':groups['fresh']['transitions']['restored_facts']>=cfg['min_fresh_exact_gain']}
    return {'checks':checks,'known_bug_recovery':protected,'passes_research_gate':all(checks.values()),
            'changes_frozen_adapter':False,'additional_calls_for_preservation':0}


def new_inputs(rows, folder, out, plan):
    decoding=read(DECODER_PLAN)
    model,tokenizer=model_for(folder,ROOT/plan['source_archive'],plan['source_archive_sha256'],
                              'frozen_control',out,decoding)
    print('48 full-turn replies',flush=True)
    full=decode(model,tokenizer,rows,decoding,time.monotonic()+decoding['cpu_budget_seconds'])
    write(out/'full-turn.json',full)
    print('Optional V17 clause replies',flush=True)
    v17,work,fragments=apply(rows,full,model,tokenizer,decoding)
    write(out/'v17-fragments.json',fragments)
    available=cache(rows,v17,fragments)
    jobs,choices=[],[]
    for row,value in zip(rows,v17,strict=True):
        prior,reason=restrict(row,value)
        job=one_clause(row,{'v18':prior})
        choices.append((prior,job))
        if job and (row['id'],job['text']) not in available:
            jobs.append({**row,'input':{**row['input'],'utterance':job['text']}})
    print('V19 extra single-clause replies',flush=True)
    generated=decode(model,tokenizer,jobs,decoding,time.monotonic()+decoding['cpu_budget_seconds'])
    generated_by_id={x['id']:x['text'] for x in generated}
    write(out/'v19-fragments.json',generated)
    values=[]
    for row,(prior,job) in zip(rows,choices,strict=True):
        text,route=prior,'unchanged'
        if job:
            key=(row['id'],job['text'])
            fragment=available[key] if key in available else generated_by_id[row['id']]
            text,route=install(row,prior,job,fragment),job['route']
        values.append({'id':row['id'],'prior':prior,'v19':text,'route':route})
    return values,{'whole_turn_calls':len(full),'shared_v17_fragment_calls':work['additional_clause_calls'],
                   'other_v19_fragment_calls':len(generated),'additional_v20_model_calls':0}


def run(folder,out):
    verify()
    plan=read(PLAN)
    out.mkdir(parents=True,exist_ok=False)
    results,outputs={},{}
    diag=None
    for group,rows,paired,raw in replay_groups():
        if group=='diagnostic':
            diag=rows
        results[group],outputs[group]=measure(rows,raw,paired)
    write(out/'known-replay.json',results)
    rows=read(DATA)
    inputs,work=new_inputs(rows,folder,out,plan)
    results['fresh'],outputs['fresh']=measure(rows,inputs,True)
    write(out/'raw.json',outputs)
    write(out/'study.json',{'study':plan['study'],'groups':results,'work':work,
                            'decision':decide(results,outputs,diag,plan)})


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('model_dir',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    run(args.model_dir,args.output)
