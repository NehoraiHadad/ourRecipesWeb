"""Bind a reported quantity, preparation method, or substitution to its own action."""
import json
import re

from colloquial_evidence_v60 import decision
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import SOURCE_VERB, ingredient
from kitchen_variations_v72 import process as previous
from reader_reports_v71 import unique_add
from turn_evidence_v58 import DOUBT, MENTION, NOMINAL, PAST, PRIOR_CONTEXT, simulate

# A verbal noun preceding the ingredient can appear in the construct form.
NOUN_FORMS = {noun: verb for verb, noun in NOMINAL.items()}
NOUN_FORMS.update({noun[:-1] + 'ת': verb for verb, noun in NOMINAL.items() if noun.endswith('ה')})
METHOD = re.compile(r'(.+?) (?:עם (?:הטריק|השיטה) של|בשיטה של|בשיטת|באמצעות) (\S+) (.+)')
PORTION = re.compile(
    r'(.+?)(?:\s*[,;.]\s*ו?|\s+ו(?:אז )?)([א-ת]+) (?:רק )?'
    r'(חצי|רבע|שליש|חלק)(?: (מהכמות|ממנ[וה]|מה[םן]|כוס|כף|כפית))?')
REPLACE = re.compile(r'(?:הכנתי|הכנו|עשיתי|עשינו) עם (.+?) במקום (.+)')
SWAP = re.compile(r'החלפ(?:תי|נו) (?:את )?(.+?) ב(.+)')
PAST_FORMS = '|'.join(sorted(set(PAST.values()), key=len, reverse=True))
FINAL_EVENT = re.compile(r' (?:ואז |ו)(' + PAST_FORMS + r')(?: (.+))?$')
TRANSFER = {
    'שמתי': SOURCE_VERB, 'שמנו': SOURCE_VERB,
    'הוספתי': ('להוסיף', 'לשים'), 'הוספנו': ('להוסיף', 'לשים'),
    'מזגתי': ('למזוג', 'לשפוך'), 'מזגנו': ('למזוג', 'לשפוך'),
    'העברתי': ('להעביר',), 'העברנו': ('להעביר',),
    'שפכתי': ('לשפוך', 'למזוג'), 'שפכנו': ('לשפוך', 'למזוג'),
}
# Remove a trailing opinion only when the entire aside describes the outcome.
TASTE = r'(?:טעים|מעולה|נהדר|חריף|מתובלן|מתובל|יבש|רטוב|מתוק|קריספי)'
DESCRIPTION = r'(?:(?:לא|ממש|מאוד|מאד|קצת) )*' + TASTE + r'(?: מדי)?(?: לטעמי)?'
OPINION = re.compile(r'(?:[,.;]\s*|\s+ו)(?:עדיין )?יצא ' + DESCRIPTION +
                     r'(?: אבל ' + DESCRIPTION + r'(?:, רק ה[א-ת]+)?)?$')
GUARD = re.compile(r'[?״"“”]|\b(?:אולי|אם|אילו|לא|בלי|טרם|כמעט|רציתי|בעתיד)\b')


def exact_event(slots, phrase):
    verb, _, words = phrase.partition(' ')
    obj = ingredient(words)
    matches = [a for a in slots if PAST.get(a.verb) == verb and a.obj == obj]
    return matches[0] if len(matches) == 1 else None


def portion_event(slots, match):
    verbs = TRANSFER.get(match[2])
    if not verbs:
        return None
    # A mistyped direct-object marker followed by a stop occurs in a reader report.
    lead = re.sub(r'\bא[תץ]\s*\.\s*(?=[א-ת])', 'את ', match[1])
    source = exact_event(slots, lead)
    if not source or source.verb in SOURCE_VERB:
        return None
    first = [(source.key, 'done')]
    if match[4] in ('כוס', 'כף', 'כפית'):
        # An absolute measure establishes completion only against a matching recipe amount.
        target = ingredient(match[3] + ' ' + match[4]) + source.obj
        status = 'done'
    else:
        target = source.obj
        status = 'partial'
    matches = [a for a in slots if a.obj == target and a.verb in verbs]
    if len(matches) == 1:
        return decision(first + [(matches[0].key, status)])
    return decision(first, doubts=[None])


def substitution_event(slots, match):
    if match.re == SWAP:
        old_name, new_name = match.groups()
    else:
        new_name, old_name = match.groups()
    last = FINAL_EVENT.search(old_name if match.re == REPLACE else new_name)
    if last:
        if match.re == REPLACE:
            old_name = old_name[:last.start()]
        else:
            new_name = new_name[:last.start()]
    old = unique_add(slots, old_name)
    new = unique_add(slots, new_name)
    if not old or not new or old == new:
        return None
    facts = [(new, 'done'), (old, 'pending')]
    if last:
        verb, obj = last.groups()
        if obj in (None, 'בתנור', 'במחבת', 'בסיר'):
            matches = [a for a in slots if PAST.get(a.verb) == verb and
                       (not obj or not a.vessel or a.vessel == obj[1:])]
            if len(matches) != 1:
                return decision(facts, doubts=[None])
            action = matches[0]
        else:
            action = exact_event(slots, verb + ' ' + obj)
        if not action or action.key in (old, new):
            return None
        facts.append((action.key, 'done'))
    return decision(facts)


def event_roles(row, text):
    content = OPINION.sub('', text.strip().rstrip('.!')).strip()
    if any(pattern.search(content) for pattern in (GUARD, PRIOR_CONTEXT, MENTION, DOUBT)):
        return None
    portion = PORTION.fullmatch(content)
    method = METHOD.fullmatch(content)
    replacement = REPLACE.fullmatch(content) or SWAP.fullmatch(content)
    if not any((portion, method, replacement)):
        return None
    slots = action_slots(row['input']['recipe']['actions'])
    if portion:
        return portion_event(slots, portion)
    if method:
        dish = exact_event(slots, method[1])
        matches = [a for a in slots if a.verb == NOUN_FORMS.get(method[2]) and
                   a.obj == ingredient(method[3])]
        if dish and len(matches) == 1 and matches[0].key != dish.key:
            return decision([(dish.key, 'done'), (matches[0].key, 'done')])
    if replacement:
        return substitution_event(slots, replacement)
    return None


def process(payload, raw):
    row = json.loads(payload)
    value = event_roles(row, row['input']['utterance'])
    if value is None:
        return previous(payload, raw)
    accepted = json.dumps(value, ensure_ascii=False)
    result = simulate(row, accepted)
    return json.dumps({**result, 'accepted_text': accepted, 'route': 'reader_event_roles'},
                      ensure_ascii=False)
