"""Ask about a named uncertain action while keeping certain reports in the turn."""
import re

from grounded_progress_v25 import VERBS
from grounded_scope_v18 import WORDS, grounded_actions
from quote_report_recovery_v45 import QUOTED
from scoped_decode_v17 import compact, literal_ids, safe_parse
from scoped_reports_v47 import SCENARIO, scoped_report

PARTS = re.compile(r'(?:״[^״]*״|"[^"]*"|[^.,;!?"״])+')
DOUBT = re.compile(r'^(?:(?:אבל|ואילו)\s+)?(?:אולי\b|נראה לי\b|נדמה לי\b|ספק אם\b|ייתכן\b|יתכן\b|'
                   r'יכול(?:ה)? להיות\b|(?:אני )?לא (?:זוכר[ת]?|יודע[ת]?|בטוח[ה]?) אם\b)')
RECHECK = re.compile(r'\b(?:אבל|אולם|בעצם|בדקתי|וידאתי|בכל זאת|ובפועל)\b')
PAST_STATE = re.compile(r'\b(?:כבר|בוצע|בוצעה|עשיתי|הושלם|הושלמה|נעשה|נעשתה)\b|[א-ת]{2,}תי\b')
ALIASES = {
    'לפרוס':('פרוס','פרוסה','פרוסים','פרוסות'),
    'לסנן':('סינון','סונן','סוננה'),
    'לאפות':('נאפה','נאפתה','אפוי','אפויה'),
    'לטגן':('טוגן','טוגנו','מטוגן','מטוגנים'),
    'לבשל':('בושל','התבשל','התבשלה','מבושל','מבושלת','בישול'),
}


def targets(clause, request):
    exact = literal_ids(clause,request)
    if exact:
        return exact,True
    named = grounded_actions(clause,request)
    words = set(WORDS.findall(clause))
    words.update(word[1:] for word in tuple(words) if len(word)>=4 and word.startswith('ש'))
    matched = set()
    for action in request['recipe']['actions']:
        verbs = action['source'].split(maxsplit=1)
        if action['id'] not in named or not verbs:
            continue
        verb = verbs[0]
        known_forms = {verb,VERBS.get(verb),*ALIASES.get(verb,())}
        if words & known_forms:
            matched.add(action['id'])
    return (matched,True) if matched else (named,bool(PAST_STATE.search(clause)))


def guard_doubt(row, raw):
    accepted,path = scoped_report(row,raw)
    result=safe_parse(accepted,row)
    if not result or result['intent'] not in ('report','next','missed','clarify','other'):
        return accepted,path
    request=row['input']
    utterance=request['utterance']
    if QUOTED.search(utterance):
        return accepted,path
    possible, independent = set(), set()
    for match in PARTS.finditer(utterance):
        clause=match.group().strip()
        found, witnessed=targets(clause,request)
        scope=DOUBT.match(clause)
        if scope and not SCENARIO.match(clause) and not RECHECK.search(clause[scope.end():]):
            if len(found)==1 and witnessed:
                possible.update(found)
        else:
            independent.update(found)
    uncertain=possible-independent
    if not uncertain:
        return accepted,path
    actions = {fact['action'] for fact in result['facts']}
    if uncertain<=set(result['clarify']) and not uncertain&actions:
        return accepted,path
    facts=[fact for fact in result['facts'] if fact['action'] not in uncertain]
    clarifications=sorted((set(result['clarify'])-{None})|uncertain)
    intent=result['intent']
    if not facts and (intent=='report' or (intent=='other' and '?' not in utterance)):
        intent='clarify'
    return compact({'intent':intent,'facts':facts,'clarify':clarifications},row),'explicit_named_doubt'
