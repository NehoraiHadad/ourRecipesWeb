"""Validate proposed writes against affirmative clauses and unresolved result predicates."""
import json
import re

from colloquial_evidence_v60 import decision
from cooking_outcome_v77 import END_CONDITION
from coordinated_claims_v62 import action_slots
from grounded_results_v79 import (ATTEMPT, END, GENERIC, HYPOTHESIS, PRED, VERBS,
                                  outcome, process as previous, report_segments)
from ingredient_alternatives_v75 import amounts
from outcome_clauses_v78 import mentions
from turn_evidence_v58 import DOUBT, MENTION, PAST, PRIOR_CONTEXT, simulate

QUESTION_TAIL = re.compile(r'\s+(?:האם (?:את|אפשר)|(?:את[ה]?|אתם) (?:יודע|יודעת|יכולה|יכול)|'
                           r'יש ל[ךי] (?:רעיון|עצה)|מה (?:עושים|ניתן|הסיבה|אפשר)|איך (?:אפשר|מתקנים)|למה[ה]*)\b')
OVEN_PART = re.compile(r'מרכז|אמצע|בחוץ|בפנים|החלק|קיפול|שוליים|למטה|למעלה|תחתית')
ABSENT = re.compile(r'(?:נגמר[הו]? לי|לא הי[הו] לי|לא מצאתי) (.+?)[.,;!…]\s*(.+)', re.S)
REPLACED = re.compile(r'(?:אני )?(?:הוספתי|שמתי) במקום (.+)')
RELATIVE = re.compile(r'(.+) ש(טחנתי|קצצתי|גררתי)(?: בבלנדר| במעבד המזון)?(?: ויצא .+)?')
MEASURE = re.compile(r'(קצצתי|חתכתי|גררתי) (.+?) והוספתי (?:אות[םןוה] )?ל(.+?) במקום(?: יצא .+)?')
COMPLETED = re.compile(r'(?:עכשיו|בסוף|ואז) (?:הוא |היא |הם |הן )?(?:כן |כבר )?(?:התרכ[ךכ][וה]?|'
                       r'מוכ(?:ן|נה|נים|נות)|רך|רכ(?:ה|ים|ות))\b')
# Explicitly current positive result must not be inferred from a negated one.
NO_TRIAL = re.compile(r'עדיין לא (?:התחלתי|הכנסתי)|טרם (?:בישלתי|אפיתי)|לא ניסיתי|לא שמתי ב(?:סיר|תנור)')


def absence(slots, text):
    m = ABSENT.fullmatch(text.removeprefix('קרה לי ש'))
    if not m:
        swap = REPLACED.fullmatch(text)
        if swap:
            # The two halves have no delimiter. Only accept a unique complete
            # partition into a missing ingredient followed by its replacement.
            tokens = re.sub(r'\s*(?:[.!].*)$', '', swap[1]).split()
            pairs = [(amounts(slots, ' '.join(tokens[:i])), amounts(slots, ' '.join(tokens[i:])))
                     for i in range(1,len(tokens))]
            pairs = [(a,b) for a,b in pairs if a and b and not set(a) & set(b)]
            if len(pairs) == 1:
                a,b = pairs[0]
                return {**dict.fromkeys(a,'pending'), **dict.fromkeys(b,'done')}
        return None
    lost, rest = m.groups()
    missing = amounts(slots, lost)
    if not missing:
        return None
    facts = dict.fromkeys(missing, 'pending')
    add = REPLACED.fullmatch(rest)
    measured = MEASURE.fullmatch(rest)
    if add:
        phrase = add[1]
        rel = RELATIVE.fullmatch(phrase)
        if rel:
            phrase = rel[1]
            last_item = re.split(r'\s+ו(?=[א-ת])', phrase)[-1]
            prep = [a for a in slots if PAST.get(a.verb) == rel[2] and mentions(a.obj, last_item)]
            if len(prep) != 1:
                return None
            facts[prep[0].key] = 'done'
        used = amounts(slots, phrase)
        if used and not set(used) & set(missing):
            return {**facts, **dict.fromkeys(used, 'done')}
    if measured:
        prep = [a for a in slots if PAST.get(a.verb) == measured[1] and mentions(a.obj, measured[2])]
        used = [a for a in slots if a.verb == 'להוסיף' and a.key not in missing and
                mentions((measured[3],), ' '.join(a.obj))]
        if len(prep) == len(used) == 1:
            return {**facts, prep[0].key:'done', used[0].key:'done'}
    # Knowing the omission is still informative when the subsequent event
    # cannot be resolved. Keep other accepted, independently grounded writes.
    return facts


def valid_updates(row, prior):
    req = row['input']
    text = req['utterance'].strip().rstrip('.!…')
    if not PRED.search(text) and not ABSENT.search(text) and not REPLACED.search(text):
        return None
    proposed = json.loads(prior['accepted_text'])
    facts = {f['action']:f['status'] for f in proposed['facts']}
    original = dict(facts)
    doubts = list(proposed['clarify'])
    if MENTION.search(text) or PRIOR_CONTEXT.search(text):
        return None
    slots = action_slots([{**a,'source':END.sub('',END_CONDITION.sub('',a['source']))} for a in req['recipe']['actions']])
    # Keep questions separate even when they precede the user's actual report.
    statements = []
    for s in re.findall(r'[^.!?…]+(?:[.!?…]+|$)', text):
        if '?' in s:
            tail = QUESTION_TAIL.search(s)
            if tail:
                s = s[:tail.start()]
        statements.extend(report_segments(s))
    asserted = ' '.join(statements)
    if not HYPOTHESIS.search(text) and not DOUBT.search(text) and '?' not in text:
        stock = absence(slots, text)
        if stock:
            facts.update(stock)
    if not PRED.search(text):
        return decision(facts.items(), doubts=doubts) if facts != original else None
    if '?' in text:
        questions = re.findall(r'[^.!?…]+\?', text)
        observed = outcome(req)
        for slot in slots:
            if slot.key not in facts:
                continue
            named_in_question = any(mentions(slot.obj, s) or slot.verb in s for s in questions)
            verb_reported = slot.verb in asserted or (PAST.get(slot.verb) or '\x00') in asserted
            explicit_question = any(slot.verb in s for s in questions)
            grounded = verb_reported or (not explicit_question and mentions(slot.obj, asserted))
            if named_in_question and not grounded and slot.key not in observed:
                facts.pop(slot.key)
        if not statements:
            return decision(doubts=proposed['clarify'] or [None]) if original else None
    if COMPLETED.search(asserted) or NO_TRIAL.search(asserted) or HYPOTHESIS.search(asserted):
        return decision(facts.items(), doubts=doubts) if facts != original else None
    # Split sentences before scoring so a question, an aside or an earlier
    # reference to success cannot obscure the explicit observation.
    for i, part in enumerate(statements):
        pred = PRED.search(part)
        if not pred or DOUBT.search(part) or re.search(r'חושבת ש|חושב ש| או לא |ספק|אולי', part):
            continue
        local = outcome({**req,'utterance':part})
        if local:
            facts.update(local)
            continue
        compatible = [a for a in slots if a.verb in VERBS[pred.lastgroup]]
        named = [a for a in compatible if mentions(a.obj, part)]
        if not named and len(compatible)==1 and (OVEN_PART.search(part) or GENERIC.fullmatch(part[:pred.start()].strip())):
            named = compatible
        if len(named)==1 and (ATTEMPT.search(' '.join(statements[:i+1])) or
                                pred.lastgroup == 'bake' and OVEN_PART.search(part)):
            facts[named[0].key] = 'partial'
        else:
            # A claim of undercooking can't confirm completion. Preserve known
            # writes on other ingredients and ask only about contested ones.
            for a in (named or compatible):
                if facts.get(a.key)=='done' and not mentions(a.obj, ' '.join(statements[i+1:])):
                    facts.pop(a.key)
                    if a.key not in doubts:
                        doubts.append(a.key)
    doubts = [k for k in doubts if k not in facts]
    if facts == original and doubts == proposed['clarify']:
        return None
    return decision(facts.items(), doubts=doubts)


def process(payload, raw):
    old = previous(payload, raw)
    row = json.loads(payload)
    parsed = json.loads(old)
    value = valid_updates(row, parsed)
    if value is None:
        return old
    encoded = json.dumps(value, ensure_ascii=False)
    return json.dumps({**simulate(row, encoded), 'accepted_text':encoded, 'route':'validated_report'},
                      ensure_ascii=False)
