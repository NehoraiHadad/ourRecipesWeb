"""Resolve an informal ingredient list only if the recipe explains every item uniquely."""
import json
import re

from colloquial_evidence_v60 import decision
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import ingredient
from reader_event_roles_v73 import exact_event, process as previous
from reader_reports_v71 import unique_add
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

ADD = re.compile(r'(?:הוספתי|הוספנו|שמתי|שמנו|הכנתי עם|הכנו עם) (.+)')
MISSING = re.compile(r'לא הי[וה] (?:לי|לנו) (.+?)[, ]+אז (?:שמתי|שמנו|הוספתי|הוספנו) (.+)')
ASIDE = re.compile(r'(?:סלט נהדר|מתכון (?:מעולה|נהדר|מצוין)|אהבתי|תודה(?: רבה)?|'
                   r'יצא (?:ממש )?(?:טעים|מעולה|מטורף|מדהים|מהמם)|'
                   r'(?:(?:וואו|יואו)[, ]+)?איזה טעים)')
BREAK = re.compile(r'\s*[.!…]+\s*')
GUARD = re.compile(r'[?״"“”]|\b(?:אם|אילו|אולי|בלי|טרם|כמעט|במקום|או)\b')
REACTION = re.compile(r'(?:לא ת[יא]אר?תי|לא תארתי|לא ציפיתי|לא האמנתי)'
                      r'(?:, (?:לא תארתי|לא ציפיתי|לא האמנתי))*'
                      r'(?:, [א-ת ,]+ (?:כזה טעם|כזאת תוצאה|כזה מרקם))?')


def list_keys(slots, body):
    body = re.sub(r'^(?:גם |בצד )+', '', body)
    # Preserve token boundaries. A missing comma and a mistyped conjunction can
    # be recovered only when a unique decomposition covers the entire utterance.
    if not re.fullmatch(r'[א-ת0-9׳״\' ,-]+', body):
        return None
    chunks = re.split(r'\s*,\s*', body)
    if any(not chunk for chunk in chunks):
        return None
    candidates = [a for a in slots if a.verb in ('להוסיף', 'לשים') and a.obj]
    result = []
    for chunk in chunks:
        words = chunk.split()
        # Two decompositions are sufficient to establish ambiguity. Store only
        # two per suffix so several overlapping ingredient names stay cheap.
        paths = {len(words): [()]}
        for start in reversed(range(len(words))):
            matches = []
            for a in candidates:
                end = start + len(a.obj)
                if end not in paths:
                    continue
                first, *rest = words[start:end]
                spellings = [first]
                if (start or result) and first.startswith(('ו', 'ן')):
                    spellings.append(first[1:])
                if any(ingredient(' '.join([word, *rest])) == a.obj for word in spellings):
                    matches.extend((a.key,) + path for path in paths[end])
                    if len(matches) >= 2:
                        break
            if matches:
                paths[start] = matches[:2]
        solutions = paths.get(0, [])
        if len(solutions) != 1:
            return None
        result.extend(solutions[0])
    return result if result and len(set(result)) == len(result) else None


def reported(row, text):
    if any(p.search(text) for p in (GUARD, DOUBT, MENTION, PRIOR_CONTEXT)):
        return None
    sentence = text.strip().rstrip('.!…').strip()
    pieces = [p for p in BREAK.split(sentence) if p and not ASIDE.fullmatch(p)]
    if len(pieces) != 1:
        return None
    body = pieces[0]
    intro, comma, rest = body.partition(', ')
    if comma and ASIDE.fullmatch(intro):
        body = rest
    slots = action_slots(row['input']['recipe']['actions'])
    missing = MISSING.fullmatch(body)
    if missing:
        old = unique_add(slots, missing[1])
        new = unique_add(slots, missing[2])
        if old and new and old != new:
            return decision([(new, 'done'), (old, 'pending')])
    add = ADD.fullmatch(body)
    if add and ' לא ' not in body:
        keys = list_keys(slots, add[1])
        if keys:
            return decision([(k, 'done') for k in keys])
    # Negating an expectation in a later reaction does not negate a completed event.
    lead, comma, reaction = body.partition(', ')
    if comma and REACTION.fullmatch(reaction):
        phrase = re.sub(r'^(\S+) (?:השניה|השנייה|הרגע) ', r'\1 ', lead)
        event = exact_event(slots, phrase)
        if event:
            return decision([(event.key, 'done')])
    return None


def process(payload, raw):
    row = json.loads(payload)
    value = reported(row, row['input']['utterance'])
    if value is None:
        return previous(payload, raw)
    accepted = json.dumps(value, ensure_ascii=False)
    return json.dumps({**simulate(row, accepted), 'accepted_text': accepted,
                       'route': 'ingredient_list_report'}, ensure_ascii=False)
