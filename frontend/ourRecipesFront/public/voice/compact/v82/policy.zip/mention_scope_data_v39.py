"""Synthetic training and held-out execution, future, and quotation contrasts."""
from collections import defaultdict
from itertools import chain
import random

from fresh_pairs_data_v15 import canonical
from fresh_pairs_v15 import read, write
from report_scope_data_v38 import FRESH as V38_FRESH, ROOT, TRAIN as V38_TRAIN, V28, V29, V35, signature
from semantic_supervision_data_v12 import read_native
from sparse_recipe_v3 import validate
from targeted_corpus_v16 import fixture, response

TRAIN = ROOT / 'verification/mention-scope-training-v39-20261119.json'
FRESH = ROOT / 'verification/mention-scope-fresh-v39-20261119.json'

# Each action includes its recipe source, first-person past, and first-person future.
TRAIN_RECIPES = (
    ('ברוסקטות קישוא וריקוטה', ('לקלות לחם כפרי', 'קליתי את הלחם הכפרי', 'אקלה את הלחם הכפרי'),
     ('לפרוס קישוא זהוב', 'פרסתי את הקישוא הזהוב', 'אפרוס את הקישוא הזהוב')),
    ('פלאפל סלק וכוסברה', ('לגרר סלק אדום', 'גיררתי את הסלק האדום', 'אגרר את הסלק האדום'),
     ('לקצוץ כוסברה שטופה', 'קצצתי את הכוסברה השטופה', 'אקצוץ את הכוסברה השטופה')),
    ('פאי דובדבנים צהובים', ('לגלען דובדבנים צהובים', 'גילענתי את הדובדבנים הצהובים', 'אגלען את הדובדבנים הצהובים'),
     ('לרדד בצק פריך', 'רידדתי את הבצק הפריך', 'ארדד את הבצק הפריך')),
    ('מיני כיכרות זיתים שחורים', ('לגלען זיתים שחורים', 'גילענתי את הזיתים השחורים', 'אגלען את הזיתים השחורים'),
     ('ללוש בצק שיפון', 'לשתי את בצק השיפון', 'אלוש את בצק השיפון')),
    ('נזיד שעועית לימה ומנגולד', ('להשרות שעועית לימה', 'השריתי את שעועית הלימה', 'אשרה את שעועית הלימה'),
     ('לקצוץ עלי מנגולד', 'קצצתי את עלי המנגולד', 'אקצוץ את עלי המנגולד')),
    ('עוגיות שיבולת שועל ומשמש', ('לשקול שיבולת שועל', 'שקלתי את שיבולת השועל', 'אשקול את שיבולת השועל'),
     ('לקצוץ משמש מיובש', 'קצצתי את המשמש המיובש', 'אקצוץ את המשמש המיובש')),
    ('גראטן לפת וגבינת עיזים', ('לפרוס לפת לבנה', 'פרסתי את הלפת הלבנה', 'אפרוס את הלפת הלבנה'),
     ('לגרר גבינת עיזים', 'גיררתי את גבינת העיזים', 'אגרר את גבינת העיזים')),
    ('גלידת תות מיובש ומייפל', ('לטחון תות מיובש', 'טחנתי את התות המיובש', 'אטחן את התות המיובש'),
     ('למדוד סירופ מייפל', 'מדדתי את סירופ המייפל', 'אמדוד את סירופ המייפל')),
    ('מרק שומר ופלפלת', ('לחתוך את השומר לרבעים', 'חתכתי את השומר לרבעים', 'אחתוך את השומר לרבעים'),
     ('להשרות פלפלת יבשה', 'השריתי את הפלפלת היבשה', 'אשרה את הפלפלת היבשה')),
    ('נודלס כוסמת ופטריות יער', ('לסנן אטריות כוסמת', 'סיננתי את אטריות הכוסמת', 'אסנן את אטריות הכוסמת'),
     ('לשטוף פטריות יער', 'שטפתי את פטריות היער', 'אשטוף את פטריות היער')),
)
FRESH_RECIPES = (
    ('דייסת קינואה וקקאו', ('לשטוף קינואה אדומה', 'שטפתי את הקינואה האדומה', 'אשטוף את הקינואה האדומה'),
     ('לנפות אבקת קקאו', 'ניפיתי את אבקת הקקאו', 'אנפה את אבקת הקקאו')),
    ('צ׳אטני מנגו וג׳ינג׳ר כבוש', ('לקלף מנגו ירוק', 'קילפתי את המנגו הירוק', 'אקלף את המנגו הירוק'),
     ('לגרר ג׳ינג׳ר כבוש', 'גיררתי את הג׳ינג׳ר הכבוש', 'אגרר את הג׳ינג׳ר הכבוש')),
    ('מג׳דרה אורז שחור וכרובית', ('למדוד אורז שחור', 'מדדתי את האורז השחור', 'אמדוד את האורז השחור'),
     ('לפרק כרובית לפרחים', 'פירקתי את הכרובית לפרחים', 'אפרק את הכרובית לפרחים')),
    ('מילפיי בננה וקרם שומשום', ('לפרוס בננה מנומרת', 'פרסתי את הבננה המנומרת', 'אפרוס את הבננה המנומרת'),
     ('לטרוף קרם שומשום', 'טרפתי את קרם השומשום', 'אטרוף את קרם השומשום')),
    ('מרק תפו״א כחול וקולרבי', ('לקלף תפוח אדמה כחול', 'קילפתי את תפוח האדמה הכחול', 'אקלף את תפוח האדמה הכחול'),
     ('לפרוס קולרבי צעיר', 'פרסתי את הקולרבי הצעיר', 'אפרוס את הקולרבי הצעיר')),
    ('קרפ עדשים ובצל שאלוט', ('לטחון עדשים כתומות מושרות', 'טחנתי את העדשים הכתומות המושרות', 'אטחן את העדשים הכתומות המושרות'),
     ('לקצוץ בצל שאלוט', 'קצצתי את בצל השאלוט', 'אקצוץ את בצל השאלוט')),
    ('סוכריות אשכולית וגויאבה', ('לסחוט אשכולית ורודה', 'סחטתי את האשכולית הוורודה', 'אסחט את האשכולית הוורודה'),
     ('לקלף גויאבה צהובה', 'קילפתי את הגויאבה הצהובה', 'אקלף את הגויאבה הצהובה')),
    ('סלט חיטת פארו ועגבנייה ירוקה', ('להשרות חיטת פארו', 'השריתי את חיטת הפארו', 'אשרה את חיטת הפארו'),
     ('לחתוך עגבנייה ירוקה', 'חתכתי את העגבנייה הירוקה', 'אחתוך את העגבנייה הירוקה')),
    ('כיסוני בטטה והל', ('למעוך בטטה סגולה', 'מעכתי את הבטטה הסגולה', 'אמעך את הבטטה הסגולה'),
     ('לכתוש תרמילי הל', 'כתשתי את תרמילי ההל', 'אכתוש את תרמילי ההל')),
    ('אטריות גזר שחור ופשתן', ('לגרר גזר שחור', 'גיררתי את הגזר השחור', 'אגרר את הגזר השחור'),
     ('לשקול זרעי פשתן', 'שקלתי את זרעי הפשתן', 'אשקול את זרעי הפשתן')),
)

# Across a group the action, recipe, state, side fact, and question stay identical.
TRAIN_FORMS = {
    'done': ('אני מעדכנת ש{past} וגמרתי', '{past}, אפשר לסמן שהושלם', 'אצלי כבר {past}',
             'מה שעשיתי בפועל זה כך: {past}', 'באמת {past}, זה כבר מאחוריי'),
    'pending': ('עוד לא ניגשתי {source}', '{source} עדיין ברשימה, בכלל לא התחלתי', 'שום חלק לא עשיתי כשמדובר על {source}',
                'לא אני, אפילו לא פעם אחת {past}', 'על {source} לא התחלתי לעבוד'),
    'partial': ('{past} רק בחלקו, יש עוד עבודה', 'התחלתי {source} ואני עדיין באמצע', '{past} רק כמה חתיכות',
                'חלק מהפעולה מאחוריי, אבל לא גמרתי {source}', 'עוד לא השלמתי, בינתיים {past} רק בחלקו'),
    'plan': ('רשמתי לי משימה להמשך: {future} כשיתפנה זמן', '{future} רק כשאגיע לשם', 'התכנון שלי הוא {source} בהמשך הערב',
             'בשלב מאוחר יותר {future}', 'הכוונה שלי להמשך היא {source}'),
    'quote': ('הדוגמה שהקראתי הייתה ״{past}״, זה הניסוח בלבד', 'מישהו אצלנו אמר לי ״{past}״',
              'בספר הופיע המשפט "{past}", רק הבאתי אותו כלשונו', 'לא דיווחתי על עצמי, רק חזרתי על ״{past}״',
              '״{past}״. זה ציטוט מההודעה שקיבלתי'),
    'scenario': ('אם אגיד ש{past}, זה יהיה להמחשה בלבד', 'נגיד לרגע ש{past} לצורך הדוגמה', 'תחשוב על מצב מדומיין שבו {past}',
                 'התרחיש מתחיל ככה: {past}', 'נניח רק לשם ההסבר ש{past}'),
}
FRESH_FORMS = {
    'done': ('כבר אפשר מבחינתי לסגור את זה, {past}', '{past} בפועל והעניין סגור', 'אפשר לסמן אצלי וי, הרגע {past}',
             '{past} לגמרי, אין עוד מה להשלים פה', 'רק מעדכן מה קרה באמת: {past}'),
    'pending': ('עוד אפילו לא הגעתי לשלב של {source}', 'עד לרגע זה לא התחלתי בכלל {source}', '{source}? עדיין לא עשיתי מזה כלום',
                'אצלי זה עוד ממתין, בכלל לא ניגשתי {source}', 'מבחינתי {source} עוד לא קרה בכלל'),
    'partial': ('כלה לי הזמן באמצע, התחלתי {source} ונשאר להמשיך', '{past} בערך חצי, עוד יש עבודה',
                '{past} רק קצת, השאר עוד מחכה', 'השלמתי רק מקטע ראשון כשניגשתי {source}', 'כבר התחלתי {source} אבל זה חצי עשוי'),
    'plan': ('כשאסיים עם השיחה פה {future}', '{source} מיועד אצלי רק לעוד שעה', 'יותר מאוחר היום {future}, ככה קבעתי מראש',
             'בכוונה השארתי לתור הבא את המשימה {source}', '{future} רק אחרי שתיגמר ההפסקה'),
    'quote': ('״{past}״ ככה היה כתוב בכרטיס, אני מדקלם', 'רק הדגמתי איך כותבים {past}, זאת הייתה דוגמה',
              'חבר בקבוצה כתב לי: "{past}". אני מעביר את המשפט שלו', 'במילים של השפית: ״{past}״. רק הקראתי',
              'זה היה טקסט לתרגול קריאה, היה כתוב ״{past}״'),
    'scenario': ('נדמיין סצנה שבה {past}, לצורך הדיון בלבד', 'אם היינו משחקים בכאילו הייתי אומר ש{past}', 'לצורך השאלה בלבד נגיד ש{past}',
                 'לו הייתי אומר ״{past}״ בתרגיל התיאורטי', 'כדוגמה תאורטית אפשר לומר ש{past}'),
}
STATUS = {'done':'done', 'pending':'pending', 'partial':'partial', 'plan':None, 'quote':None, 'scenario':None}


def examples(recipes, forms, questions, split, seed):
    rng = random.Random(seed)
    output = []
    for index, (name, first, second) in enumerate(recipes):
        sources = [first[0], second[0], 'לסדר כלי הגשה על המשטח', 'להעביר את המנה לכלי ההגשה']
        ids, context = fixture(rng, name, sources, index, f'mentions-v39-{split}')
        for action_index, (source, past, future) in enumerate((first,second)):
            index_in_split = 2 * index + action_index
            focus = ids[action_index]
            side = ids[1-action_index] if (index + action_index) % 2 else None
            neighbor = (first,second)[1-action_index][1]
            progress = {**context['progress'], focus: ('pending','partial','done')[index_in_split % 3]}
            if side:
                progress[side] = 'pending'
            question = questions[index_in_split % len(questions)]
            cluster = f'{context["recipe"]["id"]}-{action_index}'
            for kind, status in STATUS.items():
                pattern = forms[kind][(index + action_index * 2) % len(forms[kind])]
                clause = pattern.format(source=source, past=past, future=future)
                clauses = [clause]
                facts = [(focus, status)] if status else []
                if side:
                    facts.append((side,'done'))
                    side_clause = (f'לגבי הפעולה השנייה, בוודאות {neighbor}' if split=='train'
                                   else f'דבר אחד שכן קרה אצלי: {neighbor}')
                    clauses = [side_clause, clause] if index % 2 else [clause, side_clause]
                request = {**context,'progress':progress,'history':[],
                           'utterance':'. '.join([*clauses, question])}
                output.append({'id':f'{cluster}-{kind}', 'cluster':cluster, 'family':kind,
                               'focus':focus,'side':side,'input':request,
                               'expected':validate(response('next',facts),request),'critical_no_facts':not facts})
    return output


def build():
    native=read_native()
    inherited=read(V38_TRAIN)['contrast']
    new=examples(TRAIN_RECIPES,TRAIN_FORMS,('מה הצעד העדכני שלי?', 'איך כדאי להמשיך מפה?',
                 'מה לעשות עכשיו לפי המתכון?', 'איזה צעד נדרש עכשיו?'),'train',39001)
    fresh=examples(FRESH_RECIPES,FRESH_FORMS,('אפשר להמשיך, מה בא אחר כך?', 'מה נשאר לי כרגע?',
                   'מה בא בתור עכשיו?', 'איך אני מתקדם מכאן?'),'fresh',39002)
    existing=chain.from_iterable([*native.values(),inherited,read(V38_FRESH),read(V28),read(V29),read(V35)])
    names,texts=set(),set()
    for row in existing:
        names.add(canonical(row['input']['recipe']['name']))
        texts.add(canonical(row['input']['utterance']))
    name_set=lambda rows: {canonical(r['input']['recipe']['name']) for r in rows}
    new_names,fresh_names=name_set(new),name_set(fresh)
    all_new_texts=[canonical(r['input']['utterance']) for r in [*new,*fresh]]
    if (len(new)!=120 or len(fresh)!=120 or len(new_names)!=10 or len(fresh_names)!=10
            or names & (new_names|fresh_names) or new_names & fresh_names
            or texts.intersection(all_new_texts) or len(set(all_new_texts))!=len(all_new_texts)):
        raise ValueError('Unexpected size or overlap with prior data')
    pools=defaultdict(list)
    counts=defaultdict(int)
    for row in inherited:
        pools[signature(row)].append(row)
    replay=[]
    for i,row in enumerate(new):
        sig=signature(row)
        candidates=pools[sig]
        original=candidates[counts[sig]%len(candidates)]
        counts[sig]+=1
        replay.append({**original,'id':f'v39-replay-{i:03d}-{original["id"]}'})
    return {'replay':replay,'mentions':new},fresh


if __name__=='__main__':
    training, fresh = build()
    for path, data in ((TRAIN,training),(FRESH,fresh)):
        write(path,data)
