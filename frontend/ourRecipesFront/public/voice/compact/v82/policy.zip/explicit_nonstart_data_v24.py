"""Prospective paired prompts for explicit non-start and nearby utterances."""
from pathlib import Path
import random

from fresh_pairs_data_v15 import DATA as V15, canonical
from fresh_pairs_v15 import read, write
from grounded_scope_data_v18 import DATA as V18
from preserve_reports_data_v20 import DATA as V20
from report_scope_data_v21 import DATA as V21
from semantic_supervision_data_v12 import read_native
from targeted_corpus_v16 import FRESH as V16, audit_new, fixture, pair, response, train_new

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'verification/explicit-nonstart-data-v24-20261119.json'

RECIPES = (
    ('מרק כוסמין ושומר', ('לחתוך את השומר', 'לשטוף את גרגירי הכוסמין', 'להוסיף שמנת', 'לחמם את המרק'),
     ('עוד לא חתכתי את השומר.', 'חתכתי רק חצי מהשומר.'),
     ('את גרגירי הכוסמין טרם שטפתי.', 'אני לא זוכר אם שטפתי את גרגירי הכוסמין.'),
     ('עד הרגע הזה לא הוספתי שמנת.', 'עד הרגע הזה לא הוספתי שמנת, אבל את השומר כבר חתכתי.')),
    ('סלט קולורבי ונקטרינה', ('לקלף את הקולורבי', 'לפרוס נקטרינה', 'לסחוט רימון', 'לערבב את הסלט'),
     ('את הקולורבי עדיין לא קילפתי.', 'קילפתי חלק מהקולורבי ועדיין לא סיימתי.'),
     ('טרם פרסתי את הנקטרינה.', 'יכול להיות שלא פרסתי את הנקטרינה.'),
     ('לא סחטתי את הרימון בכלל.', 'סחטתי את הרימון כולו; את הנקטרינה עוד לא פרסתי.')),
    ('עוגיות טחינה וחמוציות', ('לשקול טחינה גולמית', 'להוסיף חמוציות', 'למדוד קמח שקדים', 'לאפות את העוגיות'),
     ('עד עכשיו לא שקלתי את הטחינה הגולמית.', 'שקלתי מעט מהטחינה הגולמית.'),
     ('עד כה לא הוספתי חמוציות.', 'בהמשך אני מתכוונת להוסיף חמוציות.'),
     ('את קמח השקדים עדיין לא התחלתי למדוד.', 'את קמח השקדים כבר מדדתי ואת החמוציות הוספתי.')),
    ('תבשיל עדשים ובמיה', ('לבשל עדשים כתומות', 'לחתוך את הבמיה', 'להוסיף ציר פטריות', 'לכסות את הסיר'),
     ('עוד לא בישלתי את העדשים הכתומות.', 'בישלתי את העדשים הכתומות רק חלקית.'),
     ('לא חתכתי בכלל את הבמיה.', 'נדמה לי שלא חתכתי את הבמיה.'),
     ('טרם הוספתי את ציר הפטריות.', 'הוספתי רק קצת מציר הפטריות; את הבמיה כבר חתכתי.')),
    ('מחית שזיפים ודומדמניות', ('לשטוף את השזיפים', 'לטחון דומדמניות', 'לשקול סוכר חום', 'לערבב את המחית'),
     ('עדיין לא שטפתי בכלל את השזיפים.', 'לא שטפתי את כל השזיפים, רק כמה מהם.'),
     ('לא טחנתי את הדומדמניות עד עכשיו.', 'אני מתכוונת לטחון את הדומדמניות מאוחר יותר.'),
     ('טרם שקלתי סוכר חום.', 'עד הרגע הזה לא שקלתי סוכר חום, ואת השזיפים כבר שטפתי.')),
    ('קרם קשיו וליצ׳י', ('לטחון את אגוזי הקשיו', 'למדוד מי ורדים', 'לקלף את הליצ׳י', 'לקרר את הקרם'),
     ('עוד לא התחלתי לטחון את אגוזי הקשיו.', 'טחנתי חלק מאגוזי הקשיו.'),
     ('לא מדדתי את מי הוורדים.', 'אולי לא מדדתי את מי הוורדים.'),
     ('את הליצ׳י בכלל לא קילפתי.', 'קילפתי את הליצ׳י רק חלקית; את אגוזי הקשיו כבר טחנתי.')),
)


def build():
    rows = []
    rng = random.Random(241119)
    for i, (name, sources, progress, assertion, context) in enumerate(RECIPES):
        (a, b, c, _), recipe = fixture(rng, name, sources, i, 'fresh-v24')
        # Require a real state transition for each single-action negative report.
        recipe['progress'].update({a: 'done', b: 'partial', c: 'done'})
        pair(rows, recipe, 'progress_0', progress,
             [response('report', [(a, 'pending')]), response('report', [(a, 'partial')])])
        absent = response('other') if i in (2, 4) else response('clarify', clarify=[b])
        pair(rows, recipe, 'assertion_0', assertion, [response('report', [(b, 'pending')]), absent])
        mixed_updates = (
            [(c, 'pending'), (a, 'done')],
            [(c, 'done'), (b, 'pending')],
            [(c, 'done'), (b, 'done')],
            [(c, 'partial'), (b, 'done')],
            [(c, 'pending'), (a, 'done')],
            [(c, 'partial'), (a, 'done')],
        )
        pair(rows, recipe, 'context_0', context,
             [response('report', [(c, 'pending')]), response('report', mixed_updates[i])])

    audit_new(rows, 36)
    past = [row for split in read_native().values() for row in split] + train_new()
    for path in (V15, V16, V18, V20, V21):
        past.extend(read(path))
    names = {r['input']['recipe']['name'] for r in past}
    texts = {canonical(r['input']['utterance']) for r in past}
    if any(r['input']['recipe']['name'] in names or canonical(r['input']['utterance']) in texts for r in rows):
        raise ValueError('The prospective dataset overlaps a known recipe or exact utterance')
    return rows


if __name__ == '__main__':
    if DATA.exists():
        raise FileExistsError(DATA)
    write(DATA, build())
