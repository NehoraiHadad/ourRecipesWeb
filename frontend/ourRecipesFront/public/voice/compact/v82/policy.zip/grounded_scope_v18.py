"""Require independent evidence before keeping a scope correction from V17."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import time

from fresh_pairs_v15 import PLAN as V15_PLAN, decode, digest, measurements, read, write
from grounded_scope_data_v18 import DATA, ROOT, build
from scoped_decode_v17 import apply, model_for, routes, safe_parse
from semantic_supervision_data_v12 import read_native
from sparse_recipe_v3 import aggregate, score
from targeted_corpus_v16 import FRESH as V16_FRESH

PLAN = ROOT/'verification/grounded-scope-plan-v18-20261119.json'
MANIFEST = ROOT/'verification/grounded-scope-freeze-v18-20261119.json'
OLD_RAW = ROOT/'verification/scoped-decode-raw-v17-20261118.jsonl'
WORDS = re.compile(r'[א-ת]+')
FUNCTIONAL = set('את עם על של אל אחרי לפני לגבי כבר עדיין כול כל אחד אחת שני שתי חצי חלק קצת ממש סתם רגע קודם עכשיו בסיר לקערה אחרי במהלך בערך באופן בלבד הכי ומה ולא או אם אני זה זאת שם היום הכל הכול'.split())


def forms(text):
    result=set()
    for token in WORDS.findall(text):
        if token in FUNCTIONAL:
            continue
        bare={token}
        if len(token)>3 and token[0] in 'הובכלמש':
            bare.add(token[1:])
        for word in tuple(bare):
            if len(word)>3 and word[0]=='ה':
                bare.add(word[1:])
        for word in bare:
            if len(word)>=3 and word not in FUNCTIONAL:
                result.add(word)
            for suffix in ('יים','יות','יהם','יהן','ים','ות','ת','י','ה'):
                if word.endswith(suffix) and len(word)-len(suffix)>=3:
                    result.add(word[:-len(suffix)])
    return result


def grounded_actions(text, request):
    utterance = forms(text)
    anchored=set()
    for action in request['recipe']['actions']:
        # The leading infinitive is generic. Ground on the object or qualifying phrase.
        source=WORDS.findall(action['source'])
        objects=forms(' '.join(source[1:]))
        if utterance&objects:
            anchored.add(action['id'])
    return anchored


def restrict(row, record):
    """Conservative intervention: keep V17 or fall back to its unchanged full-turn proposal."""
    if row['id']!=record['id']:
        raise ValueError('Row alignment changed')
    kind=record['path']
    request=row['input']
    text=request['utterance']
    if kind=='history':
        if grounded_actions(text,request) or re.search(r'[:;]\s*[^\s]',text):
            return record['original'],'explicit_evidence'
    elif kind=='split':
        route,parts=routes(row,record['original'])
        if route!='split':
            raise ValueError('V17 split cannot be reproduced')
        left,right=(grounded_actions(part,request) for part in parts)
        if not left or not right or len(left|right)<2:
            return record['original'],'unanchored_split'
    return record['text'],'retained'


def verify():
    for name,checksum in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name)!=checksum:
            raise ValueError(f'Changed V18 frozen input: {name}')
    expect=build()
    if read(DATA)!=expect:
        raise ValueError('Prospective data differs from the authored version')
    return expect


def measure(rows, v17, paired):
    revised=[]
    changes=defaultdict(Counter)
    for row,record in zip(rows,v17,strict=True):
        text,reason=restrict(row,record)
        old,new=score(row,record['text']),score(row,text)
        changes[reason].update(rows=1,fixed=(not old['exact'] and new['exact']),broken=(old['exact'] and not new['exact']))
        revised.append({**record,'v18':text,'restriction':reason})
    candidate=[{'id':v['id'],'text':v['v18']} for v in revised]
    before=measurements(rows,v17) if paired else aggregate(rows,[x['text'] for x in v17])[0]
    after=measurements(rows,candidate) if paired else aggregate(rows,[x['text'] for x in candidate])[0]
    executed=sum(record['path']=='split' for record in v17)*2
    avoided=sum(x['restriction']=='unanchored_split' for x in revised)*2
    return {'v17':before,'v18':after,'by_restriction':dict(changes),
            'extra_clause_calls_v17':executed,'extra_clause_calls_v18':executed-avoided},revised


def decide(results,plan):
    cfg=plan['gate']
    def extract(group,arm):
        data=results[group][arm]
        return data['overall'] if 'overall' in data else data
    deltas={}
    for group in results:
        a,b=(extract(group,arm) for arm in ('v17','v18'))
        deltas[group]={'exact':b['exact']-a['exact'],
                       'critical_wrong_fact_cases':b['critical_wrong_fact_cases']-a['critical_wrong_fact_cases']}
    checks={
        'fresh_exact_gain':deltas['fresh']['exact']>=cfg['min_new_exact_gain'],
        'fresh_wrong_fact_safety':deltas['fresh']['critical_wrong_fact_cases']<=0,
        'regression_recovery':deltas['regression']['exact']>=cfg['min_regression_exact_gain'],
        'regression_wrong_fact_safety':deltas['regression']['critical_wrong_fact_cases']<=0,
        'prior_fresh_retention':deltas['prior_fresh']['exact']>=-cfg['max_prior_fresh_exact_loss'],
        'prior_fresh_wrong_fact_safety':deltas['prior_fresh']['critical_wrong_fact_cases']<=0,
        'known_development_retention':sum(deltas[k]['exact'] for k in ('validation','diagnostic'))>=0,
    }
    return {'noticeable_research_improvement':all(checks.values()),'checks':checks,'changes':deltas,
            'product_promotion':False}


def old_groups():
    cached=defaultdict(list)
    for line in OLD_RAW.read_text().splitlines():
        record=json.loads(line)
        cached[record.pop('group')].append(record)
    native=read_native()
    for name in ('validation','diagnostic','regression'):
        yield name,native[name],cached[name],False
    yield 'prior_fresh',read(V16_FRESH),cached['fresh'],True


def run(model_dir,out):
    rows=verify()
    plan=read(PLAN)
    decoding=read(V15_PLAN)
    results,raw={},{}
    for name,items,cached,paired in old_groups():
        results[name],raw[name]=measure(items,cached,paired)
    output_time=time.monotonic()
    out.mkdir(parents=True,exist_ok=False)
    write(out/'old-replay.json',results)
    model,tokenizer=model_for(model_dir,ROOT/plan['source_archive'],plan['source_archive_sha256'],
                              'frozen_control',out,decoding)
    limit=time.monotonic()+decoding['cpu_budget_seconds']
    print('V18 shared full-turn baseline',flush=True)
    baseline=decode(model,tokenizer,rows,decoding,limit)
    write(out/'shared-baseline.json',baseline)
    print('V17 optional clause decodes',flush=True)
    v17,shares,fragments=apply(rows,baseline,model,tokenizer,decoding)
    results['fresh'],raw['fresh']=measure(rows,v17,True)
    write(out/'raw.json',raw)
    write(out/'fresh-fragments.json',fragments)
    write(out/'study.json',{'study':plan['study'],'groups':results,'decision':decide(results,plan),
                            'fresh_v17_mechanical_calls':shares,
                            'end_to_end_study_seconds':time.monotonic()-output_time})


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('model_dir',type=Path)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    run(a.model_dir,a.output)
