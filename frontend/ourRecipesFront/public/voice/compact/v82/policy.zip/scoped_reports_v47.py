"""Resolve narrow turns with independently attributed reports and mentions."""
import re

from clause_report_verifier_v40 import CLAUSES
from grounded_recipe_source_v27 import apply as grounded
from grounded_scope_v18 import grounded_actions
from quote_report_recovery_v45 import ATTRIBUTION, CERTAINTY, QUOTED, recover
from scoped_decode_v17 import compact, literal_ids, safe_parse

QUESTION = re.compile(r'^(?:מה|איך|איזה|איזו|איפה|לאן)\b')
SCENARIO = re.compile(r'^(?:נדמיין\b|נניח\b|לצורך (?:הדיון|השאלה|ההסבר) בלבד\b|'
                      r'(?:לו|אילו) הייתי אומר(?:ת)?\b|כדוגמ[אה] תאורטית\b)')
QUOTE_CUE = re.compile(r'מדקל[םמ]|היה כתוב|מדגי[םמ]|הנוסח|רק הקראתי')
FUTURE_TIME = re.compile(r'^(?:כש|כאשר)(?:אסיים|אגמור|אתפנה|אוכל)\b')
REVISION = re.compile(r'\b(?:אבל|אולם|בעצם|ובפועל|לעומת זאת|ובאמת)\b')
SELF_REPORT = re.compile(r'^(?:דבר אחד ש(?:כן|באמת) קרה אצלי|מה ש(?:כן|באמת) עשיתי|'
                         r'כך התקדמתי בפועל|העדכון שלי בפועל)\s*:\s*')


def mentioned_only(clause, request):
    if REVISION.search(QUOTED.sub('',clause)):
        return None
    anchors = literal_ids(clause,request) or grounded_actions(clause,request)
    if not anchors:
        return None
    if QUOTED.search(clause):
        outside = QUOTED.sub('',clause)
        if ATTRIBUTION.search(outside) or QUOTE_CUE.search(outside):
            return anchors
    if SCENARIO.search(clause):
        return anchors
    if FUTURE_TIME.search(clause):
        words = set(re.findall(r'[א-ת]+',clause))
        forms = {}
        for item in request['recipe']['actions']:
            if not (source:=item['source'].split(maxsplit=1)):
                continue
            verb = source[0]
            if verb.startswith('ל') and len(verb)>2:
                forms[item['id']] = 'א'+(verb[2:] if verb.startswith('לה') else verb[1:])
        future = {action for action in anchors if forms.get(action) in words}
        if len(future)==1:
            return future
    return None


def scoped_report(row, raw):
    accepted, path = recover(row,raw)
    result = safe_parse(accepted,row)
    if not result or result['intent'] not in ('next','missed') or result['clarify']:
        return accepted,path
    request = row['input']
    utterance = request['utterance'].strip()
    clauses = [m.group().strip() for m in CLAUSES.finditer(utterance)]
    if not utterance.endswith('?') or len(clauses) not in (2,3) or not QUESTION.match(clauses[-1]):
        return accepted,path

    mentions, reports = set(), []
    for clause in clauses[:-1]:
        scoped = mentioned_only(clause,request)
        if scoped:
            mentions.update(scoped)
            continue
        direct = SELF_REPORT.sub('',clause)
        example = {**row,'input':{**request,'history':[],'utterance':CERTAINTY.sub('',direct)}}
        text, used = grounded(example,'{}')
        one = safe_parse(text,example) if used else None
        if (not one or one['intent']!='report' or len(one['facts'])!=1 or one['clarify'] or
                one['facts'][0]['action'] not in grounded_actions(direct,request)):
            return accepted,path
        reports.extend(one['facts'])
    if not mentions or len(reports)>1 or any(f['action'] in mentions for f in reports):
        return accepted,path
    if reports!=result['facts']:
        return compact({**result,'facts':reports},row),'resolved_report_scope'
    return accepted,path
