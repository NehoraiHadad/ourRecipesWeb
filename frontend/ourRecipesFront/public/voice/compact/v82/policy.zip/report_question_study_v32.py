"""Train and evaluate a verifier with balanced continuation-question examples."""
import argparse
import json
from pathlib import Path
from unittest.mock import patch

from broad_text_data_v28 import DATA as BROAD
from fresh_pairs_v15 import digest, read, write
from report_prompt_data_v29 import DATA as SCOPE
from report_question_data_v32 import ROOT, build
from report_verifier_eval_v30 import V28_RAW, compare
import report_verifier_v30 as base

PLAN = ROOT / 'verification/report-question-plan-v32-20261119.json'
FREEZE = ROOT / 'verification/report-question-freeze-v32-20261119.json'


def verify():
    base.verify()
    for name, checksum in read(FREEZE)['sha256'].items():
        if digest(ROOT / name) != checksum:
            raise ValueError(f'Changed V32 input: {name}')
    config = read(PLAN)
    splits = build()
    if any(base.data_digest(rows) != config['split_sha256'][name] for name, rows in splits.items()):
        raise ValueError('V32 training or evaluation split changed')
    return config, splits


def train(source, fitted):
    config, splits = verify()
    with patch.object(base, 'verify', lambda: (config, {k: splits[k] for k in ('training', 'calibration')})):
        base.run(source, fitted)


def fitted_scores(fitted, groups, config):
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    fit = read(fitted / 'fit.json')
    folder = fitted / 'checkpoint'
    for name, sha in fit['checkpoint_sha256'].items():
        if digest(folder / name) != sha:
            raise ValueError(f'Verifier checkpoint changed: {name}')
    model = AutoModelForSequenceClassification.from_pretrained(folder, local_files_only=True, trust_remote_code=False)
    tokenizer = AutoTokenizer.from_pretrained(folder, local_files_only=True, trust_remote_code=False)
    values = {name: base.probabilities(model, tokenizer, base.prepare(tokenizer, rows, config), config)
              for name, rows in groups.items()}
    return fit, values


def audit_flags(rows, scores, calibration):
    threshold = calibration['threshold'] if calibration else None
    result = {'true_reports': 0, 'no_report': 0, 'false_vetoes': 0, 'correct_vetoes': 0}
    decisions = []
    for row, score in zip(rows, scores, strict=True):
        report = bool(row['expected']['facts'])
        flag = threshold is not None and 1 - score[0] >= threshold
        result['true_reports'] += report
        result['no_report'] += not report
        result['false_vetoes'] += flag and report
        result['correct_vetoes'] += flag and not report
        decisions.append({'id': row['id'], 'probabilities': score, 'veto': flag})
    return result, decisions


def decide(groups, audit, calibration):
    primary = groups['scope']
    before, after = (primary[key]['overall']['critical_wrong_fact_cases'] for key in ('control', 'verifier'))
    checks = {
        'calibrated': calibration is not None,
        'no_fresh_true_reports_vetoed': audit['false_vetoes'] == 0,
        'fresh_no_report_detection': audit['correct_vetoes'] >= 6,
        'no_known_true_reports_vetoed': all(group['suppressed_real_reports'] == 0 for group in groups.values()),
        'scope_false_updates_reduced': before - after >= 2 and 3 * after <= 2 * before,
        'broad_false_updates_retained': groups['broad']['verifier']['overall']['critical_wrong_fact_cases'] <=
                                        groups['broad']['control']['overall']['critical_wrong_fact_cases'],
        'full_scores_retained': all(group['verifier']['overall']['exact'] >= group['control']['overall']['exact']
                                    for group in groups.values()),
    }
    return {'checks': checks, 'passed': all(checks.values())}


def evaluation(fitted, earlier, reference, output):
    import torch

    config, splits = verify()
    torch.set_num_threads(config['threads'])
    groups = {'fresh_classifier': splits['fresh'], 'scope': read(SCOPE), 'broad': read(BROAD)}
    for directory, rows in ((fitted, splits['calibration']), (earlier, base.verify()[1]['calibration'])):
        calibration = read(directory / 'calibration-raw.json')
        if [r['id'] for r in rows] != [p['id'] for p in calibration]:
            raise ValueError('Calibration identity mismatch')
        settings = config if directory == fitted else base.verify()[0]
        if base.calibrate(rows, [p['probabilities'] for p in calibration], settings) != read(directory/'fit.json')['calibration']:
            raise ValueError('Calibration decision could not be reproduced')
    fit, current = fitted_scores(fitted, groups, config)
    old_fit, previous = fitted_scores(earlier, {'fresh_classifier': groups['fresh_classifier']}, config)
    chosen = fit['calibration']['chosen']
    audit, audited = audit_flags(groups['fresh_classifier'], current['fresh_classifier'], chosen)
    old_audit, old_audited = audit_flags(groups['fresh_classifier'], previous['fresh_classifier'],
                                        old_fit['calibration']['chosen'])
    with V28_RAW.open() as stream:
        broad = [{'id': item['id'], 'text': item['v27']} for line in stream
                 if (item := json.loads(line))['kind'] == 'comparison']
    scope = [{'id': item['id'], 'text': item['control_v27']} for item in read(reference)]
    metrics, raw = {}, {}
    for name, baseline in (('scope', scope), ('broad', broad)):
        metrics[name], raw[name] = compare(groups[name], baseline, current[name], chosen)
    output.mkdir(parents=True, exist_ok=False)
    write(output / 'raw.json', {**raw, 'fresh_classifier': audited, 'fresh_v30_classifier': old_audited})
    write(output / 'study.json', {'groups': metrics, 'fit': fit, 'fresh_classifier': audit,
                                  'fresh_v30_classifier': old_audit, 'decision': decide(metrics, audit, chosen)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('fitted', type=Path)
    parser.add_argument('earlier', type=Path)
    parser.add_argument('v29_reference', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    train(args.source, args.fitted)
    evaluation(args.fitted, args.earlier, args.v29_reference, args.output)
