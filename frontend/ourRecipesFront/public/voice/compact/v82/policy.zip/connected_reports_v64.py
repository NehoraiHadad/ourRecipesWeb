"""Normalize clause boundaries and retain the referent of an adjacent location report."""
import json
import re

from coordinated_claims_v62 import PLACE, action_slots
from scoped_events_v63 import ATTRIBUTED, event, interpret as previous, pack, decision, simulate

CONTRAST=re.compile(r'\s*,\s*(אבל|ואילו)\s+')
COORDINATED_OBJECT=re.compile(r',\s*ו(?=את\s|ל(?:סיר|קערה|מחבת|תבנית|כוס|בלנדר|צנצנת)\b)')
LOCATION=re.compile(r'(?P<lead>(?:עכשיו |כעת |כבר )?)(?:הוא|היא|הם|הן) (?P<place>.+)')
PIVOT=re.compile(r'\s+(?:אבל\s+(?:אני\s+)?|ואני\s+|בפועל\s+)')
QUOTED=re.compile(r'(?:״[^״]*״|"[^"]*"|“[^”]*”)')
QUOTE_LEAD=re.compile(r'^(?:הוא|היא) (?:אמר[ה]?|סיפר[ה]?|כתב[ה]?)\s*[:–]\s*')
NEUTRAL=json.dumps(decision())
EVIDENCE={'scoped_events','coordinated_evidence','explicit_destination','grounded_result',
          'current_recipe_claim','destination_question','focused_question','unresolved_destination',
          'uncertain_result','mentioned_result','question_about_result'}


def normalize(text,actions):
    text=COORDINATED_OBJECT.sub(', ',CONTRAST.sub(r' \1 ',text))
    parts=re.split(r'([.!?;])',text)
    slots=None
    for i in range(2,len(parts),2):
        loc=LOCATION.fullmatch(parts[i].strip())
        if not loc or not PLACE.fullmatch(loc['place']) or parts[i-1]=='?':
            continue
        if slots is None:
            slots=action_slots(actions)
        prior=event(parts[i-2].strip(),slots,actions,None,None,None)
        if prior and prior[0] and prior[1] in ('done','partial','pending') and prior[2]:
            parts[i]=' '+' '.join(prior[2])+' '+loc['place']
    return ''.join(parts)


def interpret(row,raw):
    req=row['input']
    original=req['utterance']
    text=normalize(original,req['recipe']['actions'])
    local={**row,'input':{**req,'utterance':text}} if text!=original else row
    # Discard an attributed lead before evaluating an explicit first-person contrast.
    if ATTRIBUTED.match(text) or QUOTE_LEAD.match(text):
        # Mask quoted words before finding the speaker change. Keep character offsets.
        mask=QUOTED.sub(lambda m:' '*len(m[0]),text)
        pivot=PIVOT.search(mask)
        if not pivot and QUOTED.search(text) and not mask.rstrip('.!? ').count('.'):
            return pack(decision(),'mentioned_result')
        if pivot:
            own={**row,'input':{**req,'utterance':text[pivot.end():],'history':[]}}
            accepted,route=previous(own,NEUTRAL)
            if route not in EVIDENCE and not json.loads(accepted)['facts']:
                return pack(decision(doubts=[None]),'contrast_clarification')
            return accepted,route
    return previous(local,raw)


def process(payload,raw):
    row=json.loads(payload)
    outside=raw=='null'
    accepted,route=interpret(row,NEUTRAL if outside else raw)
    if outside and route not in EVIDENCE:
        accepted,route=pack(decision(doubts=[None]),'context_clarification')
    result=simulate(row,accepted)
    if route=='context_clarification':
        result['reply']='כדי לדייק בעדכון המתכון, אפשר לכתוב במשפט קצר מה בוצע ובאיזה מרכיב?'
    return json.dumps({**result,'route':route,'accepted_text':accepted},ensure_ascii=False)
