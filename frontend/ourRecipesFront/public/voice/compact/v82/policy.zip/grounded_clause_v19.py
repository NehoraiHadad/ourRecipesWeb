"""Prospective fallback: decode one independently grounded report clause."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import time

from fresh_pairs_v15 import PLAN as V15_PLAN, decode, digest, measurements, read, write
from grounded_scope_v18 import DATA, PLAN as V18_PLAN, ROOT, decide, grounded_actions, old_groups
from scoped_decode_v17 import ANAPHOR, COMPLETED, CUES, NEXT, SPLIT, UNC, clean_part, compact, model_for, routes, safe_parse
from sparse_recipe_v3 import aggregate, score

MANIFEST=ROOT/'verification/grounded-clause-freeze-v19-20261119.json'
OLD_FRAGMENTS=ROOT/'verification/scoped-decode-fragments-v17-20261118.jsonl'
OUTSIDE=re.compile(r'דלת|חלון|טלפון|אינטרקום|שליח|סוללה|שלט|מישהו|רדיו|חשמל|נורה|פעמון|רעש|הודעה')
PARTIAL=re.compile(r'\b(?:חלק|חלקי|חלקית|בחלקו|חצי|באמצע)\b')
INCOMPLETE=re.compile(r'נשאר|לא (?:סיימתי|השלמתי|גמור)|עוד עבודה|התחלתי')
UNC_EXTRA=re.compile(r'אינ(?:י|ני) זוכר|אינ(?:י|ני) יודע')


def verify():
    for name,sha in read(MANIFEST)['sha256'].items():
        if digest(ROOT/name)!=sha:
            raise ValueError('V19 prospective artifact changed: '+name)


def doubt(text):
    return bool(UNC.search(text) or UNC_EXTRA.search(text))


def one_clause(row, prior):
    request=row['input']
    text=request['utterance']
    if request['history'] or '?' in text or NEXT.search(text) or CUES.search(text):
        return None
    result=safe_parse(prior['v18'],row)
    if ':' in text:
        lead, tail=text.split(':',1)
        tail=clean_part(tail)
        ids=grounded_actions(tail,request)
        if (ANAPHOR.search(lead) and COMPLETED.search(lead) and not doubt(lead)
                and not re.search(r'\bלא\b', lead) and not doubt(tail) and ids and len(tail)>=8):
            return job_when_needed(result,tail,ids,[], 'done','explicit')

    parts=[p for p in map(clean_part,SPLIT.split(text)) if p]
    if len(parts)!=2 or min(map(len,parts))<9:
        return None
    left,right=(grounded_actions(part,request) for part in parts)
    missing=[i for i,s in enumerate((left,right)) if not s]
    if len(missing)==1:
        i=missing[0]
        other=1-i
        unsupported,explicit=parts[i],parts[other]
        ids=(left,right)[other]
        if doubt(explicit) or CUES.search(explicit):
            return None
        if doubt(unsupported) and OUTSIDE.search(unsupported):
            return job_when_needed(result,explicit,ids,[],None,'side_doubt')
        if INCOMPLETE.search(unsupported) and PARTIAL.search(explicit):
            return job_when_needed(result,explicit,ids,[],'partial','same_partial')
        return None
    unsure=[i for i,p in enumerate(parts) if doubt(p)]
    if len(unsure)!=1 or len(left|right)<2:
        return None
    i=unsure[0]
    uncertain,certain=(left,right)[i],(left,right)[1-i]
    if len(uncertain)!=1 or not certain or uncertain&certain:
        return None
    return job_when_needed(result,parts[1-i],certain,list(uncertain),None,'mixed')


def job_when_needed(result,text,ids,clarify,status,reason):
    if result and result['intent']=='report' and len(result['facts'])==1 and result['clarify']==clarify:
        fact=result['facts'][0]
        if fact['action'] in ids and len(ids)==1 and (status is None or fact['status']==status):
            return None
    return {'text':text,'possible_ids':ids,'clarify':clarify,'status':status,'route':reason}


def install(row, old, job, prediction):
    credible=safe_parse(prediction,row)
    if not credible or len(credible['facts'])!=1 or credible['clarify']:
        return old
    fact=credible['facts'][0]
    if fact['action'] not in job['possible_ids'] or (job['status'] is not None and fact['status']!=job['status']):
        return old
    return compact({'intent':'report','facts':[fact],'clarify':job['clarify']},row)


def cache(rows, raw, fragment):
    available={}
    index={p['id']:p for p in fragment}
    for row,record in zip(rows,raw,strict=True):
        if record['path']!='split':
            continue
        kind,parts=routes(row,record['original'])
        if kind!='split':
            raise ValueError('Cached split cannot reproduce')
        for i,part in enumerate(parts):
            available[(row['id'],part)]=index[f'{row["id"]}/clause{i}']['text']
    return available


def run(model_dir, previous, out):
    verify()
    old_report=read(previous/'study.json')
    if old_report['decision']['noticeable_research_improvement']:
        raise ValueError('V18 already passed the predeclared goal')
    policy=read(V18_PLAN)
    decoding=read(V15_PLAN)
    raw=read(previous/'raw.json')
    old=defaultdict(list)
    for line in OLD_FRAGMENTS.read_text().splitlines():
        value=json.loads(line)
        group=value.pop('group')
        old['prior_fresh' if group=='fresh' else group].append(value)
    old['fresh']=read(previous/'fresh-fragments.json')
    datasets={n:(rows,paired) for n,rows,_,paired in old_groups()}
    datasets['fresh']=(read(DATA),True)
    out.mkdir(parents=True,exist_ok=False)
    model,tok=model_for(model_dir,ROOT/policy['source_archive'],policy['source_archive_sha256'],
                         'frozen_control',out,decoding)
    results,records={},{}
    for group,(rows,paired) in datasets.items():
        prior=raw[group]
        if [p['id'] for p in prior]!=[r['id'] for r in rows]:
            raise ValueError('Row identity differs from the V18 benchmark')
        cached=cache(rows,prior,old[group])
        jobs,decisions=[],{}
        for row,p in zip(rows,prior,strict=True):
            action=one_clause(row,p)
            if action is None:
                continue
            ident=row['id']
            decisions[ident]=action
            if (ident,action['text']) not in cached:
                jobs.append({**row,'input':{**row['input'],'utterance':action['text']}})
        print(group,len(decisions),'single-clause checks;',len(jobs),'new calls',flush=True)
        fragments=decode(model,tok,jobs,decoding,time.monotonic()+decoding['cpu_budget_seconds'])
        by_id={r['id']:r['text'] for r in fragments}
        corrected=[]
        statuses=defaultdict(Counter)
        for row,p in zip(rows,prior,strict=True):
            ident=row['id']
            action=decisions.get(ident)
            route='unchanged'
            answer=p['v18']
            if action:
                route=action['route']
                reply=cached.get((ident,action['text']))
                if reply is None:
                    reply=by_id[ident]
                answer=install(row,answer,action,reply)
            a,b=score(row,p['text']),score(row,answer)
            statuses[route].update(requests=1,fixed=not a['exact'] and b['exact'],broken=a['exact'] and not b['exact'])
            corrected.append({'id':ident,'text':answer,'v17':p['text'],'v18':p['v18'],'route':route})
        base=[{'id':r['id'],'text':r['v17']} for r in corrected]
        scoring=(lambda pred:measurements(rows,pred)) if paired else (lambda pred:aggregate(rows,[p['text'] for p in pred])[0])
        results[group]={'v17':scoring(base),'v19':scoring(corrected),'by_route':dict(statuses),
                        'new_cpu_clause_calls':len(jobs),'single_clause_checks':len(decisions)}
        records[group]=corrected
        write(out/f'{group}-fragments.json',fragments)
    write(out/'raw.json',records)
    comparison={group:{'v17':value['v17'],'v18':value['v19']} for group,value in results.items()}
    write(out/'study.json',{'study':'grounded-clause-v19','groups':results,'decision':decide(comparison,policy),
                            'comparison':'V19 versus V17 with V18 guard decisions as initial answers'})


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('model_dir',type=Path)
    parser.add_argument('v18_run',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    run(args.model_dir,args.v18_run,args.output)
