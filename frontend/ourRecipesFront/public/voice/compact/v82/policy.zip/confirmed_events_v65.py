"""Require independent clause evidence before committing a model-only batch of writes."""
import json
import re

from connected_reports_v64 import EVIDENCE, NEUTRAL, interpret as previous
from colloquial_evidence_v60 import decision, pack
from destination_evidence_v61 import VESSEL
from scoped_events_v63 import FUTURE
from turn_evidence_v58 import simulate

FRACTION_PRONOUN=re.compile(r'\b(חצי|שליש|רבע|חלק) (?:ממנ[וה]|מהם|מהן)\b')
LATER=re.compile(r'(?P<obj>(?:את )?[א-ת]+(?: [א-ת]+){0,3}?) רק (?P<when>מחר|בהמשך|אחר כך) (?P<verb>[א-ת]+)(?=[.,;?!]|$)')
CONTAINER_CORRECTION=re.compile(r'^(?:לא (?:ה?'+VESSEL+r')[.!]\s*)?(?:טעיתי|התבלבלתי) (?:בין הכלים|בכלי|בשם הכלי)\s*[,.:]\s*(.+)$')
CONTAINER_QUERY=re.compile(r'^ה?('+VESSEL+r') (?:עוד |עדיין )?ריק(?:ה)?\?\s*(.+?)\?$')


def normalize(text):
    if re.search(r'\b(?:מזג|שפכ|העבר|שמ|הוספ|הכנס|יצק)(?:תי|נו)\b',text):
        text=FRACTION_PRONOUN.sub(r'\1 מהכמות',text)
    text=LATER.sub(lambda m:m['obj']+' '+m['verb']+' רק '+m['when'] if m['verb'] in FUTURE.values() else m[0],text)
    # A coordinating vav may start a finite verb even after a comma.
    return re.sub(r',\s*ו(?=[א-ת]+(?:תי|נו)\b)',', ',text)


def interpret(row,raw):
    req=row['input']
    original=req['utterance'].strip()
    text=normalize(original)
    local={**row,'input':{**req,'utterance':text}} if text!=original else row
    correction=CONTAINER_CORRECTION.fullmatch(text)
    if correction:
        target=correction[1].replace(' בכלל ',' ')
        own={**row,'input':{**req,'utterance':target}}
        accepted,route=previous(own,NEUTRAL)
        if route in EVIDENCE:
            return accepted,route
    query=CONTAINER_QUERY.fullmatch(text)
    if query:
        body=re.sub(r' (?:או ש)?אני (?:מתבלבל[ת]?|טועה)$','',query[2])
        body=re.sub(r'\b(?:לתוכ[וה]|אלי[וה]|לשם)\b','ל'+query[1],body)
        own={**row,'input':{**req,'utterance':body+'?'}}
        accepted,route=previous(own,NEUTRAL)
        if route in EVIDENCE and json.loads(accepted)['clarify']:
            return accepted,route
    accepted,route=previous(local,raw)
    if route=='raw':
        facts=json.loads(accepted)['facts']
        if len(facts)>1 or (facts and text.endswith('?') and not re.search(r'[.!;]',text[:-1])):
            # Retry with an empty proposal: every accepted write must now be
            # recoverable from the words and recipe rather than the score vector.
            grounded,source=previous(local,NEUTRAL)
            if source!='raw' and json.loads(grounded)['facts']:
                return grounded,source
            return pack(decision(doubts=[None]),'unconfirmed_model_report')
    return accepted,route


def process(payload,raw):
    row=json.loads(payload)
    outside=raw=='null'
    accepted,route=interpret(row,NEUTRAL if outside else raw)
    if outside and route not in EVIDENCE:
        accepted,route=pack(decision(doubts=[None]),'context_clarification')
    result=simulate(row,accepted)
    if route=='context_clarification':
        result['reply']='כדי לדייק בעדכון המתכון, אפשר לכתוב במשפט קצר מה בוצע ובאיזה מרכיב?'
    return json.dumps({**result,'route':route,'accepted_text':accepted},ensure_ascii=False)
