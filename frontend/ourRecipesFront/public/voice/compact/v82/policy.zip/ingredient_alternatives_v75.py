"""Resolve explicit substitutions and availability notes across complete recipe clauses."""
import json
import re

from colloquial_evidence_v60 import decision
from coordinated_claims_v62 import action_slots
from destination_evidence_v61 import ingredient
from recipe_ingredient_lists_v74 import GUARD, list_keys, process as previous
from turn_evidence_v58 import DOUBT, MENTION, PRIOR_CONTEXT, simulate

FRONT = re.compile(r'במקום (.+?) (?:שמתי |שמנו |הוספתי |הוספנו |השתמשתי ב|השתמשנו ב)(.+)')
BACK = re.compile(r'(?:שמתי |שמנו |הוספתי |הוספנו |השתמשתי ב|השתמשנו ב)(.+?) במקום (.+)')
SWAP = re.compile(r'(?:החלפ|המר)(?:תי|נו) (?:את )?(.+?) ב(.+)')
MISSING = re.compile(r'לא הי[וה] (?:לי|לנו) (.+?)(?: \(רק [א-ת ]+\))?[, ]+אז '
                     r'(?:החלפתי ל|החלפנו ל|השתמשתי ב|השתמשנו ב|שמתי |שמנו |הוספתי |הוספנו )(.+)')
ONLY = re.compile(r'השתמש(?:תי|נו) רק ב(.+?) \(לא הי[וה] (.+?)(?: (?:בסופר|במקרר|בבית|בחנות))?\)')
ALSO = re.compile(r'(?:הוספתי|הוספנו|שמתי|שמנו) (?:לתיבול |לתערובת )?(.+)')
INTENT = re.compile(r'[?״"“”]|\b(?:אם|אילו|אולי|כמעט|נניח|בעתיד|מחר)\b')
CLAUSE = re.compile(r'\s*[.;!]\s*|,?\s+ו(?=(?:החלפ|הוספ|השתמש|שמ)(?:תי|נו)\b)')
OUTCOME = re.compile(r'(?:,?\s+(?:וזה (?:הסמיך|עבד)|ויצא)|,\s*יצא) '
                     r'(?:(?:ויצא |ממש |מאוד |מאד )?(?:טעים|מעולה|משובח|נפלא|נהדר|מושלם)'
                     r'(?: במיוחד)?|מצוין|מצויין)$')


def amounts(slots, phrase):
    keys = list_keys(slots, phrase)
    if not keys:
        keys = list_keys(slots, re.sub(r'^(?:מעט|קצת) ', '', phrase))
    return keys


def replacement(slots, part):
    front = FRONT.fullmatch(part) or SWAP.fullmatch(part) or MISSING.fullmatch(part)
    back = BACK.fullmatch(part) or ONLY.fullmatch(part)
    if not front and not back:
        return None
    old, new = front.groups() if front else tuple(reversed(back.groups()))
    used, skipped = amounts(slots, new), amounts(slots, old)
    if not skipped and back and back.re == BACK and old.startswith('ב'):
        skipped = amounts(slots, old[1:])
    if not skipped and back and back.re == ONLY:
        # A head noun may be shared: "עגבניות (לא היו שרי)" with "עגבניות שרי" in the recipe.
        joint = ingredient(new) + ingredient(old)
        matches = [a.key for a in slots if a.verb in ('להוסיף', 'לשים') and a.obj == joint]
        if len(matches) == 1:
            skipped = matches
    if not used or not skipped or set(used) & set(skipped):
        return None
    return {**dict.fromkeys(used, 'done'), **dict.fromkeys(skipped, 'pending')}


def alternatives(row):
    text = row['input']['utterance'].strip().rstrip('.!…').strip()
    if not any(x in text for x in ('במקום ', 'החלפ', 'המרתי ', 'המרנו ', 'לא היה ', 'לא היו ')):
        return None
    if any(p.search(text) for p in (INTENT, MENTION, PRIOR_CONTEXT, DOUBT)):
        return None
    slots = action_slots(row['input']['recipe']['actions'])
    facts = {}
    has_swap = False
    for part in CLAUSE.split(OUTCOME.sub('', text)):
        part = re.sub(r'^(?:אני|אנחנו) ', '', part)
        change = replacement(slots, part)
        if change:
            has_swap = True
        else:
            add = ALSO.fullmatch(part.removesuffix(' כדי לפצות'))
            if not add or GUARD.search(part):
                return None
            keys = amounts(slots, add[1])
            if not keys:
                return None
            change = dict.fromkeys(keys, 'done')
        if any(k in facts and facts[k] != status for k, status in change.items()):
            return None
        facts.update(change)
    return decision(facts.items()) if has_swap else None


def process(payload, raw):
    row = json.loads(payload)
    value = alternatives(row)
    if value is None:
        return previous(payload, raw)
    accepted = json.dumps(value, ensure_ascii=False)
    return json.dumps({**simulate(row, accepted), 'accepted_text': accepted,
                       'route': 'explicit_ingredient_alternatives'}, ensure_ascii=False)
