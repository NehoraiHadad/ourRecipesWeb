"""Bind an explicit transfer or location question to the matching recipe destination."""
import json
import re

from colloquial_evidence_v60 import decision, interpret as previous, pack, plain
from turn_evidence_v58 import WORDS, simulate

VESSEL = r'(?:סיר|קערה|מחבת|תבנית|קופסה|כוס|צנצנת|בלנדר|תערובת)'
DEST = re.compile(r'(?:^|\s)(?:(?:אל|לתוך|בתוך) ה?|[לב])('+VESSEL+r')(?=\s|$)')
ORIGIN = re.compile(r'(?:^|\s)(?:מתוך ה?|מה)('+VESSEL+r')(?=\s|$)')
VERB = r'(?:מזגתי|שפכתי|הוספתי|העברתי|שמתי|הכנסתי|מזגנו|שפכנו|הוספנו|העברנו|שמנו|הכנסנו)'
SOURCE_VERB = ('להוסיף','למזוג','לשפוך','להעביר','להכניס','לשים')
FRAME = re.compile(r'(?:(עוד לא|עדיין לא|לא) )?(?:כבר )?'+VERB+r' (.+)')
FRACTION = re.compile(r'^(?:רק )?(?:חצי|חלק|רבע|שליש) מ(?:ן )?')
PREFACE = re.compile(r'(?:לפני שממשיכים |רגע[,]? )?(?:אני רוצה|רציתי|אפשר) (?:רק )?(?:לבדוק|לוודא|לברר)(?: משהו| דבר אחד)?[.:,]\s*')
# A distinct storage event cannot license a second ingredient transfer. Match only
# if putting leftovers away is not itself an action in this recipe.
STORAGE = re.compile(r' ואת מה שנשאר (?:בבקבוק|בכד|בקרטון) החזרתי למקרר$')


def ingredient(fragment):
    return tuple(plain(w) for w in WORDS.findall(fragment) if w!='את')


def interpret(row,raw):
    req=row['input']
    text=req['utterance'].strip()
    probe=PREFACE.match(text)
    if probe and text.endswith('?'):
        shorter={**row,'input':{**req,'utterance':text[probe.end():]}}
        answer,route=previous(shorter,raw)
        if route=='grounded_result' and not json.loads(answer)['facts']:
            return answer,'focused_question'

    actions=req['recipe']['actions']
    sentence=text.rstrip('.!? ').strip()
    if not any(a['source'].startswith(('להחזיר','לאחסן','לשמור','להכניס למקרר')) or 'מקרר' in a['source'] for a in actions):
        sentence=STORAGE.sub('',sentence)
    match=FRAME.fullmatch(sentence)
    if not match:
        return previous(row,raw)
    negated,body=match.groups()
    dests=list(DEST.finditer(body))
    if len(dests)!=1:
        return previous(row,raw)
    dest=dests[0]
    origins=ORIGIN.findall(body)
    if len(origins)>1:
        return previous(row,raw)
    rest=ORIGIN.sub(' ',body[:dest.start()]+' '+body[dest.end():]).strip()
    rest=re.sub(r'^את\s+','',rest)
    fraction=FRACTION.match(rest)
    obj=ingredient(rest[fraction.end():] if fraction else rest)
    if not obj:
        return previous(row,raw)

    compatible=[]
    named=False
    for action in actions:
        words=action['source'].split(maxsplit=1)
        if len(words)!=2 or words[0] not in SOURCE_VERB:
            continue
        arguments=words[1]
        targets=list(DEST.finditer(arguments))
        if len(targets)!=1:
            continue
        target=targets[0]
        item=ORIGIN.sub(' ',arguments[:target.start()]+' '+arguments[target.end():])
        if ingredient(item)!=obj:
            continue
        named=True
        if target[1]==dest[1] and (not origins or not ORIGIN.search(arguments) or origins==ORIGIN.findall(arguments)):
            compatible.append(action['id'])
    if not named:
        return previous(row,raw)
    if len(compatible)!=1:
        return pack(decision(doubts=[None]),'unresolved_destination')
    key=compatible[0]
    if text.endswith('?') or (fraction and negated):
        return pack(decision(doubts=[key]),'destination_question')
    status='pending' if negated else 'partial' if fraction else 'done'
    return pack(decision([(key,status)]),'explicit_destination')


def process(payload,raw):
    row=json.loads(payload)
    accepted,route=interpret(row,raw)
    return json.dumps({**simulate(row,accepted),'route':route,'accepted_text':accepted},ensure_ascii=False)
